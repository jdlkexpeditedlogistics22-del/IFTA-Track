// Powered by OnSpace.AI

import { useContext } from 'react';
import { TripContext } from '@/contexts/TripContext';

export function useTrips() {
  const context = useContext(TripContext);
  if (!context) {
    throw new Error('useTrips must be used within TripProvider');
  }
  return context;
}
