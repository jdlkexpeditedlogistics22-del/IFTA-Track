import { useContext } from 'react';
import { TrialContext } from '@/contexts/TrialContext';

export function useTrial() {
  const context = useContext(TrialContext);
  if (!context) {
    throw new Error('useTrial must be used within TrialProvider');
  }
  return context;
}
