// Powered by OnSpace.AI

import { useContext } from 'react';
import { KeepAwakeContext } from '@/contexts/KeepAwakeContext';

export function useKeepAwake() {
  const context = useContext(KeepAwakeContext);
  if (!context) {
    throw new Error('useKeepAwake must be used within KeepAwakeProvider');
  }
  return context;
}
