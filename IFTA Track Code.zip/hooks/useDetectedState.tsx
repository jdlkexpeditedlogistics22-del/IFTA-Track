// Powered by OnSpace.AI
// One-shot GPS detection for the fuel-entry screen. From a SINGLE position fix
// it resolves the purchase jurisdiction (US state code) so the fuel form can
// auto-fill the state. Exposes a manual re-detect action.

import { useCallback, useEffect, useState } from 'react';
import { detectCurrentLocation } from '@/services/locationService';

export function useDetectedState() {
  const [detecting, setDetecting] = useState(true);
  const [detectedCode, setDetectedCode] = useState<string | null>(null);

  const detect = useCallback(
    async (aliveRef?: { alive: boolean }): Promise<string | null> => {
      const alive = () => (aliveRef ? aliveRef.alive : true);
      setDetecting(true);

      const loc = await detectCurrentLocation();
      if (!alive()) return null;

      const code = loc?.stateCode ?? null;
      setDetectedCode(code);
      setDetecting(false);
      return code;
    },
    [],
  );

  const redetect = useCallback(
    (): Promise<string | null> => detect(),
    [detect],
  );

  useEffect(() => {
    const ref = { alive: true };
    void detect(ref);
    return () => {
      ref.alive = false;
    };
  }, [detect]);

  return {
    detecting,
    detectedCode,
    redetect,
  };
}
