// Powered by OnSpace.AI
// Backup & restore flow: creates a shareable data file and re-imports one,
// with confirmation and result feedback via the alert UI. Refreshes global
// state after a restore so every screen updates immediately.

import { useCallback, useEffect, useState } from 'react';
import { AppState } from 'react-native';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import {
  BackupData,
  RestoreMode,
  applyRestore,
  backupFolderStatus,
  createBackup,
  nextAutoBackupAt,
  parseBackup,
  pickBackupText,
  recordBackup,
  saveBackupToFolder,
} from '@/services/backupService';
import { BackupMeta, loadBackupMeta } from '@/services/storageService';

export function useBackup() {
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [meta, setMeta] = useState<BackupMeta>({
    firstBackupAt: null,
    lastBackupAt: null,
    lastMethod: null,
  });
  const { showAlert } = useAlert();
  const { reloadAll } = useTrips();

  // Keep the backup schedule metadata in sync. Reloading on resume also picks
  // up any automatic backup that ran in TripContext while the app was away.
  const refreshMeta = useCallback(async () => {
    const m = await loadBackupMeta();
    setMeta(m);
  }, []);

  useEffect(() => {
    refreshMeta();
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') refreshMeta();
    });
    return () => sub.remove();
  }, [refreshMeta]);

  const runBackup = useCallback(
    async (target: 'share' | 'folder') => {
      setIsBackingUp(true);
      try {
        const result =
          target === 'folder'
            ? await saveBackupToFolder()
            : await createBackup();
        if (result.reason === 'empty') {
          showAlert(
            'Nothing to back up',
            'Record a trip or add a fuel purchase first.',
          );
        } else if (result.reason === 'unavailable') {
          showAlert(
            'Sharing unavailable',
            'Sharing is not supported on this device.',
          );
        } else if (result.reason === 'error' || !result.ok) {
          showAlert(
            'Backup failed',
            result.error
              ? `Could not save the backup: ${result.error}`
              : 'Could not create the backup. Please try again.',
          );
        } else {
          // Success: record it so the schedule + "last backup" date update. The
          // first manual backup arms the automatic 45-day schedule.
          const updated = await recordBackup('manual');
          setMeta(updated);
          if (target === 'folder' && !result.shared) {
            showAlert(
              'Backup saved',
              'Your backup was saved to the "IFTA Backup" folder on this device.',
            );
          }
        }
      } finally {
        setIsBackingUp(false);
      }
    },
    [showAlert],
  );

  // Save to the on-device "IFTA Backup" folder. On the very first folder backup
  // the folder does not exist yet, so prompt the user to create it and save the
  // current backup into it. Once it exists, later saves go straight in.
  const saveToFolder = useCallback(async () => {
    const status = await backupFolderStatus();
    if (!status.exists) {
      showAlert(
        'Create backup folder?',
        'An "IFTA Backup" folder does not exist on this device yet. Create it now and save your backup there? Future backups will be saved to this same folder.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Create & Save', onPress: () => runBackup('folder') },
        ],
      );
      return;
    }
    runBackup('folder');
  }, [runBackup, showAlert]);

  const backup = useCallback(async () => {
    showAlert(
      'Create backup',
      'Would you like to save your backup to an "IFTA Backup" folder on this device, or share it to another location?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Share', onPress: () => runBackup('share') },
        { text: 'Save to Folder', onPress: () => saveToFolder() },
      ],
    );
  }, [runBackup, saveToFolder, showAlert]);

  const doRestore = useCallback(
    async (data: BackupData, mode: RestoreMode) => {
      setIsRestoring(true);
      try {
        const counts = await applyRestore(data, mode);
        await reloadAll();
        showAlert(
          'Restore complete',
          `Your data now has ${counts.trips} ${
            counts.trips === 1 ? 'trip' : 'trips'
          } and ${counts.fuel} fuel ${
            counts.fuel === 1 ? 'entry' : 'entries'
          }.`,
        );
      } catch {
        showAlert(
          'Restore failed',
          'Could not restore this backup. Please try again.',
        );
      } finally {
        setIsRestoring(false);
      }
    },
    [reloadAll, showAlert],
  );

  const restore = useCallback(async () => {
    const picked = await pickBackupText();
    if (picked.status === 'canceled') return;
    if (picked.status === 'error') {
      showAlert(
        'Could not open file',
        'Please choose a valid IFTA-Track backup file.',
      );
      return;
    }

    let data: BackupData;
    try {
      data = parseBackup(picked.text);
    } catch {
      showAlert(
        'Invalid backup',
        'This file is not a recognized IFTA-Track backup.',
      );
      return;
    }

    const tripCount = data.trips.length;
    const fuelCount = data.fuel.length;
    if (tripCount === 0 && fuelCount === 0) {
      showAlert('Empty backup', 'This backup does not contain any data.');
      return;
    }

    showAlert(
      'Restore backup',
      `This backup has ${tripCount} ${
        tripCount === 1 ? 'trip' : 'trips'
      } and ${fuelCount} fuel ${
        fuelCount === 1 ? 'entry' : 'entries'
      }. Replace your current data or merge them in?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Merge', onPress: () => doRestore(data, 'merge') },
        {
          text: 'Replace',
          style: 'destructive',
          onPress: () => doRestore(data, 'replace'),
        },
      ],
    );
  }, [doRestore, showAlert]);

  return {
    isBackingUp,
    isRestoring,
    backup,
    restore,
    lastBackupAt: meta.lastBackupAt,
    lastBackupMethod: meta.lastMethod,
    firstBackupAt: meta.firstBackupAt,
    nextAutoBackupAt: nextAutoBackupAt(meta),
    refreshMeta,
  };
}
