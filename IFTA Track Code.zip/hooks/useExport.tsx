// Powered by OnSpace.AI
// Logic for exporting the IFTA mileage breakdown. Offers email (with a recipient
// dialog), printing (clean HTML table / PDF), CSV, and text, and surfaces errors
// through the alert UI.

import { useCallback, useState } from 'react';
import { useAlert } from '@/template';
import {
  ExportFormat,
  ExportRow,
  FuelExportRow,
  FuelReportMeta,
  ReportMeta,
  emailFuelReport,
  emailReport,
  exportFuelReport,
  exportReport,
  printReport,
  savePdfReport,
  saveFuelPdfReport,
} from '@/services/exportService';

type EmailTarget = { rows: ExportRow[]; meta: ReportMeta };
type FuelTarget = { rows: FuelExportRow[]; meta: FuelReportMeta };

export type ExportChoice = 'email' | 'pdf' | 'print' | 'csv' | 'text';

export function useExport() {
  const [isExporting, setIsExporting] = useState(false);
  const [emailTarget, setEmailTarget] = useState<EmailTarget | null>(null);
  const [exportTarget, setExportTarget] = useState<EmailTarget | null>(null);
  const [fuelExportTarget, setFuelExportTarget] = useState<FuelTarget | null>(
    null,
  );
  const { showAlert } = useAlert();

  const runExport = useCallback(
    async (format: ExportFormat, rows: ExportRow[], meta: ReportMeta) => {
      setIsExporting(true);
      try {
        const result = await exportReport(format, rows, meta);
        if (result.reason === 'unavailable') {
          showAlert(
            'Sharing unavailable',
            'Sharing is not supported on this device.',
          );
        } else if (result.reason === 'error') {
          showAlert(
            'Export failed',
            'Could not create the report. Please try again.',
          );
        }
      } finally {
        setIsExporting(false);
      }
    },
    [showAlert],
  );

  const runPrint = useCallback(
    async (rows: ExportRow[], meta: ReportMeta) => {
      setIsExporting(true);
      try {
        const result = await printReport(rows, meta);
        if (result.reason === 'error') {
          showAlert(
            'Print failed',
            'Could not open the print dialog. Please try again.',
          );
        }
      } finally {
        setIsExporting(false);
      }
    },
    [showAlert],
  );

  const runSavePdf = useCallback(
    async (rows: ExportRow[], meta: ReportMeta) => {
      setIsExporting(true);
      try {
        const result = await savePdfReport(rows, meta);
        if (result.reason === 'unavailable') {
          showAlert(
            'Sharing unavailable',
            'Sharing is not supported on this device.',
          );
        } else if (result.reason === 'error') {
          showAlert(
            'PDF failed',
            'Could not create the PDF report. Please try again.',
          );
        }
      } finally {
        setIsExporting(false);
      }
    },
    [showAlert],
  );

  // Called by the email dialog once a valid recipient has been entered.
  const sendEmail = useCallback(
    async (recipient: string) => {
      const target = emailTarget;
      setEmailTarget(null);
      if (!target) return;
      setIsExporting(true);
      try {
        const result = await emailReport(target.rows, target.meta, recipient);
        if (result.reason === 'unavailable') {
          showAlert(
            'Email unavailable',
            'No mail account is set up on this device.',
          );
        } else if (result.reason === 'error') {
          showAlert(
            'Email failed',
            'Could not open the mail composer. Please try again.',
          );
        }
      } finally {
        setIsExporting(false);
      }
    },
    [emailTarget, showAlert],
  );

  const closeEmailDialog = useCallback(() => setEmailTarget(null), []);

  // Opens the graphical export options sheet (or warns when there is nothing
  // to export). The sheet itself renders the choices; selection is handled by
  // `selectExport` below.
  const promptExport = useCallback(
    (rows: ExportRow[], meta: ReportMeta) => {
      if (rows.length === 0) {
        showAlert(
          'Nothing to export',
          'There are no miles recorded for this period yet.',
        );
        return;
      }
      setExportTarget({ rows, meta });
    },
    [showAlert],
  );

  const closeExportSheet = useCallback(() => setExportTarget(null), []);

  // Routes a graphical option tap to the matching export action, closing the
  // sheet first so only one modal is presented at a time.
  const selectExport = useCallback(
    (choice: ExportChoice) => {
      const target = exportTarget;
      setExportTarget(null);
      if (!target) return;
      const { rows, meta } = target;
      if (choice === 'email') setEmailTarget({ rows, meta });
      else if (choice === 'pdf') runSavePdf(rows, meta);
      else if (choice === 'print') runPrint(rows, meta);
      else if (choice === 'csv') runExport('csv', rows, meta);
      else if (choice === 'text') runExport('text', rows, meta);
    },
    [exportTarget, runExport, runPrint, runSavePdf],
  );

  const runFuelExport = useCallback(
    async (format: ExportFormat, rows: FuelExportRow[], meta: FuelReportMeta) => {
      setIsExporting(true);
      try {
        const result = await exportFuelReport(format, rows, meta);
        if (result.reason === 'unavailable') {
          showAlert(
            'Sharing unavailable',
            'Sharing is not supported on this device.',
          );
        } else if (result.reason === 'error') {
          showAlert(
            'Export failed',
            'Could not create the report. Please try again.',
          );
        }
      } finally {
        setIsExporting(false);
      }
    },
    [showAlert],
  );

  const runFuelEmail = useCallback(
    async (rows: FuelExportRow[], meta: FuelReportMeta) => {
      setIsExporting(true);
      try {
        const result = await emailFuelReport(rows, meta);
        if (result.reason === 'unavailable') {
          showAlert(
            'Email unavailable',
            'No mail account is set up on this device.',
          );
        } else if (result.reason === 'error') {
          showAlert(
            'Email failed',
            'Could not open the mail composer. Please try again.',
          );
        }
      } finally {
        setIsExporting(false);
      }
    },
    [showAlert],
  );

  const runFuelPdf = useCallback(
    async (rows: FuelExportRow[], meta: FuelReportMeta) => {
      setIsExporting(true);
      try {
        const result = await saveFuelPdfReport(rows, meta);
        if (result.reason === 'unavailable') {
          showAlert(
            'Sharing unavailable',
            'Sharing is not supported on this device.',
          );
        } else if (result.reason === 'error') {
          showAlert(
            'PDF failed',
            'Could not create the PDF report. Please try again.',
          );
        }
      } finally {
        setIsExporting(false);
      }
    },
    [showAlert],
  );

  const promptFuelExport = useCallback(
    (rows: FuelExportRow[], meta: FuelReportMeta) => {
      if (rows.length === 0) {
        showAlert(
          'Nothing to export',
          'There are no fuel purchases recorded for this period yet.',
        );
        return;
      }
      setFuelExportTarget({ rows, meta });
    },
    [showAlert],
  );

  const closeFuelExportSheet = useCallback(
    () => setFuelExportTarget(null),
    [],
  );

  // Routes a graphical option tap to the matching fuel export action. The fuel
  // report has no per-jurisdiction print step, so 'print' is not offered.
  const selectFuelExport = useCallback(
    (choice: ExportChoice) => {
      const target = fuelExportTarget;
      setFuelExportTarget(null);
      if (!target) return;
      const { rows, meta } = target;
      if (choice === 'email') runFuelEmail(rows, meta);
      else if (choice === 'pdf') runFuelPdf(rows, meta);
      else if (choice === 'csv') runFuelExport('csv', rows, meta);
      else if (choice === 'text') runFuelExport('text', rows, meta);
    },
    [fuelExportTarget, runFuelEmail, runFuelPdf, runFuelExport],
  );

  return {
    isExporting,
    promptExport,
    promptFuelExport,
    fuelExportSheetVisible: !!fuelExportTarget,
    fuelExportSheetPeriod: fuelExportTarget?.meta.periodLabel,
    selectFuelExport,
    closeFuelExportSheet,
    exportSheetVisible: !!exportTarget,
    exportSheetPeriod: exportTarget?.meta.periodLabel,
    selectExport,
    closeExportSheet,
    emailDialogVisible: !!emailTarget,
    emailDialogPeriod: emailTarget?.meta.periodLabel,
    sendEmail,
    closeEmailDialog,
  };
}
