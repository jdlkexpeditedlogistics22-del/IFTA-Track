// Powered by OnSpace.AI
// Pure formatting helpers

export const formatMiles = (m: number): string => {
  if (m >= 1000) return Math.round(m).toLocaleString();
  return m.toFixed(1);
};

export const formatDate = (ts: number): string =>
  new Date(ts).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

export const formatTime = (ts: number): string =>
  new Date(ts).toLocaleTimeString(undefined, {
    hour: 'numeric',
    minute: '2-digit',
  });

export const formatDuration = (ms: number): string => {
  const min = Math.max(0, Math.round(ms / 60000));
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  return `${h}h ${min % 60}m`;
};

export const formatCurrency = (n: number): string =>
  `$${n.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;

export const formatGallons = (g: number): string => g.toFixed(1);

// Fuel price per gallon - shown to the mil (up to 3 decimals) and NOT rounded
// to whole cents, since pump prices carry a third decimal (e.g. $3.459/gal).
export const formatPricePerGallon = (n: number): string =>
  `$${n.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 3,
  })}`;

export const formatMpg = (mpg: number): string =>
  mpg > 0 ? mpg.toFixed(1) : '\u2014';

export const formatSignedGallons = (g: number): string => {
  const rounded = Math.round(g * 10) / 10;
  if (rounded === 0) return '0.0';
  const sign = rounded > 0 ? '+' : '';
  return `${sign}${rounded.toFixed(1)}`;
};

// Diesel tax rate in $/gal - 3 decimals since rates like 0.205 need precision.
export const formatRate = (n: number): string => `$${n.toFixed(3)}`;

// Relative day count for scheduling copy, e.g. "in 12 days" / "due now".
export const formatDaysUntil = (ts: number, now = Date.now()): string => {
  const days = Math.ceil((ts - now) / (24 * 60 * 60 * 1000));
  if (days <= 0) return 'due now';
  if (days === 1) return 'in 1 day';
  return `in ${days} days`;
};

// Compact "time ago" label for the recording-activity indicator, e.g.
// "Just now" / "3 min ago" / "2 hrs ago" / "Never".
export const formatRelativeTime = (
  ts: number | null,
  now = Date.now(),
): string => {
  if (!ts) return 'Never';
  const diff = Math.max(0, now - ts);
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'Just now';
  if (min < 60) return `${min} min ago`;
  const hrs = Math.floor(min / 60);
  if (hrs < 24) return `${hrs} hr${hrs === 1 ? '' : 's'} ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
};

// Currency with an explicit +/- sign so tax due vs. credit reads clearly.
export const formatSignedCurrency = (n: number): string => {
  const rounded = Math.round(n * 100) / 100;
  const abs = Math.abs(rounded).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  if (rounded > 0) return `+$${abs}`;
  if (rounded < 0) return `-$${abs}`;
  return `$${abs}`;
};
