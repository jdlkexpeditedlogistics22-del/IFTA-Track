// Powered by OnSpace.AI
// Design tokens for the IFTA mileage tracker

export const colors = {
  background: '#0E1621',
  surface: '#16202E',
  surfaceAlt: '#1E2A3A',
  surfaceHigh: '#243140',
  border: '#26344A',
  primary: '#F5A623',
  primaryDark: '#C9821A',
  primarySoft: 'rgba(245,166,35,0.14)',
  success: '#34C759',
  successSoft: 'rgba(52,199,89,0.15)',
  danger: '#FF453A',
  dangerSoft: 'rgba(255,69,58,0.15)',
  info: '#4DA3FF',
  text: '#F2F5F9',
  textSubtle: '#9DACC0',
  textMuted: '#647387',
  white: '#FFFFFF',
  onPrimary: '#1A1206',
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 };

export const radius = { sm: 8, md: 12, lg: 16, xl: 24, pill: 999 };

export const typography = {
  display: { fontSize: 44, fontWeight: '800' as const },
  h1: { fontSize: 24, fontWeight: '700' as const },
  h2: { fontSize: 20, fontWeight: '700' as const },
  h3: { fontSize: 18, fontWeight: '600' as const },
  body: { fontSize: 16, fontWeight: '400' as const },
  bodyStrong: { fontSize: 16, fontWeight: '600' as const },
  small: { fontSize: 14, fontWeight: '500' as const },
  caption: { fontSize: 12, fontWeight: '500' as const },
};

export const shadow = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 6,
  },
};
