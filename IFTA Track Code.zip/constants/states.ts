// Powered by OnSpace.AI
// US state reference and reverse-geocode resolution helpers

export const US_STATES: { code: string; name: string }[] = [
  { code: 'AL', name: 'Alabama' },
  { code: 'AK', name: 'Alaska' },
  { code: 'AZ', name: 'Arizona' },
  { code: 'AR', name: 'Arkansas' },
  { code: 'CA', name: 'California' },
  { code: 'CO', name: 'Colorado' },
  { code: 'CT', name: 'Connecticut' },
  { code: 'DE', name: 'Delaware' },
  { code: 'DC', name: 'District of Columbia' },
  { code: 'FL', name: 'Florida' },
  { code: 'GA', name: 'Georgia' },
  { code: 'HI', name: 'Hawaii' },
  { code: 'ID', name: 'Idaho' },
  { code: 'IL', name: 'Illinois' },
  { code: 'IN', name: 'Indiana' },
  { code: 'IA', name: 'Iowa' },
  { code: 'KS', name: 'Kansas' },
  { code: 'KY', name: 'Kentucky' },
  { code: 'LA', name: 'Louisiana' },
  { code: 'ME', name: 'Maine' },
  { code: 'MD', name: 'Maryland' },
  { code: 'MA', name: 'Massachusetts' },
  { code: 'MI', name: 'Michigan' },
  { code: 'MN', name: 'Minnesota' },
  { code: 'MS', name: 'Mississippi' },
  { code: 'MO', name: 'Missouri' },
  { code: 'MT', name: 'Montana' },
  { code: 'NE', name: 'Nebraska' },
  { code: 'NV', name: 'Nevada' },
  { code: 'NH', name: 'New Hampshire' },
  { code: 'NJ', name: 'New Jersey' },
  { code: 'NM', name: 'New Mexico' },
  { code: 'NY', name: 'New York' },
  { code: 'NC', name: 'North Carolina' },
  { code: 'ND', name: 'North Dakota' },
  { code: 'OH', name: 'Ohio' },
  { code: 'OK', name: 'Oklahoma' },
  { code: 'OR', name: 'Oregon' },
  { code: 'PA', name: 'Pennsylvania' },
  { code: 'RI', name: 'Rhode Island' },
  { code: 'SC', name: 'South Carolina' },
  { code: 'SD', name: 'South Dakota' },
  { code: 'TN', name: 'Tennessee' },
  { code: 'TX', name: 'Texas' },
  { code: 'UT', name: 'Utah' },
  { code: 'VT', name: 'Vermont' },
  { code: 'VA', name: 'Virginia' },
  { code: 'WA', name: 'Washington' },
  { code: 'WV', name: 'West Virginia' },
  { code: 'WI', name: 'Wisconsin' },
  { code: 'WY', name: 'Wyoming' },
];

export const STATE_NAME_BY_CODE: Record<string, string> = US_STATES.reduce(
  (acc, s) => {
    acc[s.code] = s.name;
    return acc;
  },
  {} as Record<string, string>,
);

const STATE_CODE_BY_NAME: Record<string, string> = US_STATES.reduce(
  (acc, s) => {
    acc[s.name.toLowerCase()] = s.code;
    return acc;
  },
  {} as Record<string, string>,
);

export const UNKNOWN_STATE = 'Unknown';

// Resolve a single free-text value (a state name, a 2-letter code, or an ISO
// "US-CA"/"USA-CA" style code) to a 2-letter state code. Returns null when the
// value cannot be matched, so callers can try the next candidate field.
export function resolveStateCode(region?: string | null): string | null {
  if (!region) return null;
  const trimmed = region.trim();
  if (!trimmed) return null;

  // Direct 2-letter code, e.g. "CA".
  const upper = trimmed.toUpperCase();
  if (STATE_NAME_BY_CODE[upper]) return upper;

  // Full state name, e.g. "California".
  const byName = STATE_CODE_BY_NAME[trimmed.toLowerCase()];
  if (byName) return byName;

  // ISO 3166-2 style, e.g. "US-CA" / "USA-CA" — take the trailing segment and
  // re-check it as a 2-letter code.
  const parts = upper.split(/[-_\s]+/);
  const tail = parts[parts.length - 1];
  if (tail && STATE_NAME_BY_CODE[tail]) return tail;

  return null;
}

// Resolve a full reverse-geocode address object to a state code by trying every
// field that commonly carries the state across iOS/Android/web (region is
// frequently null on Android, where the state can land in subregion or be
// embedded in the formatted address).
export function resolveStateFromAddress(
  address?: Record<string, any> | null,
): string | null {
  if (!address) return null;
  const candidates = [
    address.region,
    address.subregion,
    address.district,
    address.city,
    address.name,
    address.formattedAddress,
  ];
  for (const value of candidates) {
    if (typeof value !== 'string') continue;
    const code = resolveStateCode(value);
    if (code) return code;
    // Scan multi-word / comma-separated fields (e.g. a formatted address
    // "123 Main St, Dallas, TX 75201, USA") token-by-token for a state.
    for (const token of value.split(/[,\s]+/)) {
      const t = resolveStateCode(token);
      if (t) return t;
    }
  }
  return null;
}

export function stateLabel(code: string): string {
  if (code === UNKNOWN_STATE) return 'Unknown area';
  return STATE_NAME_BY_CODE[code] || code;
}
