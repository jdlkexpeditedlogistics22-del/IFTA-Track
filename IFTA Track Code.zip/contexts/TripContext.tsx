// Core tracking state. The actual mileage math lives in sessionService and runs
// from BOTH the foreground and the background task against one shared on-disk
// session, so recording continues while the app is minimized.

import React, {
  createContext,
  ReactNode,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import { AppState, Platform } from 'react-native';
import * as LocationSvc from '@/services/locationService';
import {
  createSession,
  finalizeSessionNow,
  getSuspended,
  ingestSamples,
  loadSession,
  recoverSession,
  rolloverIfNewDay,
  saveSession,
  setAutoEnabledFlag,
  setSuspendedFlag,
  updateSessionMiles,
} from '@/services/sessionService';
import {
  loadDef,
  loadFuel,
  loadRecentVendors,
  loadRecordActivity,
  loadTrips,
  mergeRecentVendor,
  saveDef,
  saveFuel,
  saveRecentVendors,
  saveTrips,
} from '@/services/storageService';
import { maybeRunAutoBackup } from '@/services/backupService';
import {
  ActiveSession,
  BorderCrossing,
  DefPurchase,
  FuelPurchase,
  StateMiles,
  Trip,
} from '@/services/types';

const POLL_INTERVAL_MS = 1500;
// While recording in the foreground, a GPS fix should land every 1-2s. If none
// has arrived for this long, the OS has silently dropped the location feed (the
// "records a mile then stops" symptom) — the poll watchdog rebuilds it.
const FEED_STALE_MS = 20000;
const FEED_RESTART_COOLDOWN_MS = 15000;

// expo-location's web build calls LocationEventEmitter.removeSubscription() in
// Subscription#remove(), but that method does not exist on web — so calling
// sub.remove() throws "removeSubscription is not a function" and crashes the
// poll/cleanup. Swallow it: the watch is torn down either way.
function removeSubSafe(sub: any) {
  try {
    sub?.remove?.();
  } catch {
    // ignore — expo-location web incompatibility
  }
}

type TripContextType = {
  trips: Trip[];
  isLoading: boolean;
  isTracking: boolean;
  isSuspended: boolean;
  autoDetect: boolean;
  permissionGranted: boolean;
  backgroundGranted: boolean;
  supportsBackground: boolean;
  currentMiles: number;
  currentStateCode: string | null;
  currentSpeedMph: number;
  currentAccuracy: number | null;
  liveStateMiles: StateMiles;
  currentCrossings: BorderCrossing[];
  lastForegroundRecordAt: number | null;
  lastBackgroundRecordAt: number | null;
  startTracking: () => Promise<boolean>;
  stopTracking: () => Promise<void>;
  endDayNow: () => Promise<boolean>;
  suspendTracking: () => Promise<void>;
  resumeTracking: () => Promise<void>;
  updateCurrentMiles: (stateMiles: StateMiles) => Promise<void>;
  setAutoDetect: (value: boolean) => Promise<boolean>;
  ensureMonitoring: () => Promise<boolean>;
  enableMonitoring: () => Promise<boolean>;
  promptBackgroundPermission: () => Promise<boolean>;
  addManualTrip: (stateMiles: StateMiles, date: number) => void;
  deleteTrip: (id: string) => void;
  updateTrip: (id: string, stateMiles: StateMiles) => void;
  fuel: FuelPurchase[];
  recentVendors: string[];
  addFuelPurchase: (entry: Omit<FuelPurchase, 'id'>) => void;
  updateFuelPurchase: (id: string, entry: Omit<FuelPurchase, 'id'>) => void;
  deleteFuelPurchase: (id: string) => void;
  def: DefPurchase[];
  addDefPurchase: (entry: Omit<DefPurchase, 'id'>) => void;
  updateDefPurchase: (id: string, entry: Omit<DefPurchase, 'id'>) => void;
  deleteDefPurchase: (id: string) => void;
  clearAll: () => void;
  reloadAll: () => Promise<void>;
};

export const TripContext = createContext<TripContextType | undefined>(undefined);

export function TripProvider({ children }: { children: ReactNode }) {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [fuel, setFuel] = useState<FuelPurchase[]>([]);
  const [def, setDef] = useState<DefPurchase[]>([]);
  const [recentVendors, setRecentVendors] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isTracking, setIsTracking] = useState(false);
  const [isSuspended, setIsSuspended] = useState(false);
  const [autoDetect, setAutoDetectState] = useState(false);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [backgroundGranted, setBackgroundGranted] = useState(false);
  const [supportsBackground, setSupportsBackground] = useState(false);
  const [currentMiles, setCurrentMiles] = useState(0);
  const [liveStateMiles, setLiveStateMiles] = useState<StateMiles>({});
  const [currentCrossings, setCurrentCrossings] = useState<BorderCrossing[]>([]);
  const [currentStateCode, setCurrentStateCode] = useState<string | null>(null);
  const [currentSpeedMph, setCurrentSpeedMph] = useState(0);
  const [currentAccuracy, setCurrentAccuracy] = useState<number | null>(null);
  const [lastForegroundRecordAt, setLastForegroundRecordAt] = useState<
    number | null
  >(null);
  const [lastBackgroundRecordAt, setLastBackgroundRecordAt] = useState<
    number | null
  >(null);

  const trackingRef = useRef(false);
  const autoRef = useRef(false);
  const bgGrantedRef = useRef(false);
  const suspendedRef = useRef(false);
  const tripsRef = useRef<Trip[]>([]);
  const fuelRef = useRef<FuelPurchase[]>([]);
  const defRef = useRef<DefPurchase[]>([]);
  // The recorder runs TWO feeds while the app is open: a foreground watch (the
  // reliable real-time source) and, when granted, the OS background-updates
  // service (for screen-off). watchSub holds the foreground subscription; bg
  // tracks whether the background service is running.
  const feedRef = useRef<{ watchSub?: any; bg: boolean }>({ bg: false });
  const startFeedRef = useRef<(() => Promise<void>) | null>(null);
  const lastFeedRestartRef = useRef(0);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const fgRecordRef = useRef<number | null>(null);
  const bgRecordRef = useRef<number | null>(null);
  // Throttle disk reads of the record-activity indicator. The poll below runs
  // every ~1.5s; reading AsyncStorage that often, forever, is pure churn for a
  // Settings-screen indicator and adds steady GC/I-O pressure on long drives.
  const lastActivityReadRef = useRef(0);

  const reloadTrips = useCallback(async () => {
    const fresh = await loadTrips();
    tripsRef.current = fresh;
    setTrips(fresh);
  }, []);

  const reloadFuel = useCallback(async () => {
    const fresh = await loadFuel();
    fuelRef.current = fresh;
    setFuel(fresh);
  }, []);

  const reloadDef = useCallback(async () => {
    const fresh = await loadDef();
    defRef.current = fresh;
    setDef(fresh);
  }, []);

  // Refresh all datasets from disk (used after an in-app data restore).
  const reloadAll = useCallback(async () => {
    await Promise.all([reloadTrips(), reloadFuel(), reloadDef()]);
  }, [reloadTrips, reloadFuel, reloadDef]);

  // Pull the last foreground / background (locked-drive) recorded times from
  // disk so the Settings screen can confirm both feeds are banking miles.
  // Gated by refs so unchanged values never trigger a re-render.
  const refreshRecordActivity = useCallback(async () => {
    // Throttle: this is called from the ~1.5s poll and from launch/resume. A
    // fresh read every few seconds is plenty for a "last recorded" indicator
    // and avoids hammering AsyncStorage on the JS thread while driving.
    const now = Date.now();
    if (now - lastActivityReadRef.current < 8000) return;
    lastActivityReadRef.current = now;
    try {
      const activity = await loadRecordActivity();
      if (activity.foregroundAt !== fgRecordRef.current) {
        fgRecordRef.current = activity.foregroundAt;
        setLastForegroundRecordAt(activity.foregroundAt);
      }
      if (activity.backgroundAt !== bgRecordRef.current) {
        bgRecordRef.current = activity.backgroundAt;
        setLastBackgroundRecordAt(activity.backgroundAt);
      }
    } catch {
      // ignore — the indicator simply keeps its last known value
    }
  }, []);

  // Push a session snapshot into UI state. A null session while we were
  // tracking means the day's trip finalized (manual stop, or the midnight
  // day-rollover applied on relaunch/resume).
  // The poll below calls this every ~1.5s. React bails out of a re-render when a
  // primitive setState value is unchanged (Object.is), but setLiveStateMiles was
  // spreading a BRAND-NEW object every tick, forcing a full list re-render twice
  // a second forever while armed. Over a long drive that steady render + GC
  // churn is a prime suspect for the app being killed after several minutes. Gate
  // the object update behind a cheap signature so it only fires on real change.
  const liveSigRef = useRef('');
  const crossingCountRef = useRef(0);
  const applySessionToState = useCallback(
    (session: ActiveSession | null) => {
      if (session) {
        trackingRef.current = true;
        setIsTracking(true);
        setCurrentMiles(session.miles);
        const sig = JSON.stringify(session.stateMiles);
        if (sig !== liveSigRef.current) {
          liveSigRef.current = sig;
          setLiveStateMiles({ ...session.stateMiles });
        }
        setCurrentStateCode(session.currentStateCode);
        setCurrentSpeedMph(Math.round(session.speedMph || 0));
        setCurrentAccuracy(session.accuracy ?? null);
        // Crossings only ever grow within a day, so length is a reliable, cheap
        // change signature — avoids re-copying the array on every ~1.5s tick.
        const cc = session.crossings ? session.crossings.length : 0;
        if (cc !== crossingCountRef.current) {
          crossingCountRef.current = cc;
          setCurrentCrossings(session.crossings ? [...session.crossings] : []);
        }
      } else if (trackingRef.current) {
        trackingRef.current = false;
        setIsTracking(false);
        setCurrentMiles(0);
        liveSigRef.current = '';
        setLiveStateMiles({});
        setCurrentSpeedMph(0);
        setCurrentStateCode(null);
        setCurrentAccuracy(null);
        crossingCountRef.current = 0;
        setCurrentCrossings([]);
        reloadTrips();
      }
    },
    [reloadTrips],
  );

  const startPoll = useCallback(() => {
    if (pollRef.current) return;
    pollRef.current = setInterval(async () => {
      try {
        const session = await loadSession();
        applySessionToState(session);
        refreshRecordActivity();
      // Feed watchdog: while recording in the foreground the watch delivers a
      // fix every ~1s even when parked, so lastTs stays fresh. If it goes stale
      // the location feed has died — rebuild it so recording resumes on its own
      // (rate-limited so a genuinely unavailable GPS does not thrash).
      if (
        AppState.currentState === 'active' &&
        session &&
        session.lastTs != null &&
        Date.now() - session.lastTs > FEED_STALE_MS &&
        Date.now() - lastFeedRestartRef.current > FEED_RESTART_COOLDOWN_MS
      ) {
        lastFeedRestartRef.current = Date.now();
        if (feedRef.current.watchSub) {
          removeSubSafe(feedRef.current.watchSub);
          feedRef.current.watchSub = undefined;
        }
        startFeedRef.current?.();
        }
      } catch {
        // Never let a transient read/geocode error escape the interval and
        // bubble up as an unhandled rejection that could crash the app.
      }
    }, POLL_INTERVAL_MS);
  }, [applySessionToState, refreshRecordActivity]);

  // Foreground / web fallback: each sample is processed in-context.
  const onWatchSample = useCallback(
    async (sample: LocationSvc.Sample) => {
      // Wrapped so a transient error in the mileage math / state update can
      // NEVER escape this GPS callback as an unhandled promise rejection (which
      // is thrown from a native callback context and can destabilize the JS
      // runtime, tearing down recording). Errors are swallowed; the next fix
      // simply tries again.
      try {
        const { session, finalized } = await ingestSamples(
          [sample],
          'foreground',
        );
        applySessionToState(session);
        if (finalized) await reloadTrips();
      } catch {
        // ignore — recording continues on the next GPS fix
      }
    },
    [applySessionToState, reloadTrips],
  );

  // Live current-location resolver. While monitoring is ARMED but not yet
  // recording (truck parked, or the app just opened) NO session exists, so the
  // Track tab's location chip would otherwise stay stuck on "Locating...". This
  // takes a one-shot fix and reverse-geocodes it so the current jurisdiction
  // shows and refreshes automatically. Skipped while actively recording — the
  // live session already owns the state code from its own GPS stream. Never
  // prompts (silent check), so it is safe to run on launch/resume/interval.
  const refreshCurrentLocation = useCallback(async () => {
    if (trackingRef.current) return;
    try {
      if (!(await LocationSvc.hasForegroundPermission())) return;
      const loc = await LocationSvc.detectCurrentLocation();
      // Recording may have started while the fix was in flight — let the live
      // session own the state code in that case.
      if (!loc || trackingRef.current) return;
      if (loc.stateCode) setCurrentStateCode(loc.stateCode);
    } catch {
      // ignore — the chip simply keeps its last known value
    }
  }, []);

  const startFeed = useCallback(async () => {
    const useBackground =
      LocationSvc.supportsBackgroundLocation() && bgGrantedRef.current;

    // 1) ALWAYS run a foreground watch while the app is open. This is the
    // reliable real-time feed. Relying only on the OS background-updates service
    // in the foreground is what caused the odometer to freeze after ~a mile:
    // iOS/Android can silently throttle or stop that service mid-drive, and
    // nothing was there to keep delivering fixes or to restart it. A foreground
    // watch keeps delivering for as long as the app is visible.
    if (!feedRef.current.watchSub) {
      try {
        feedRef.current.watchSub = await LocationSvc.startWatch(onWatchSample);
      } catch {
        feedRef.current.watchSub = undefined;
      }
    }

    // 2) ADDITIONALLY run the OS background-updates service when supported and
    // granted, so recording survives screen-lock / minimize. Running both feeds
    // at once is safe: every session write is serialized (see sessionService
    // runExclusive) and a duplicate/near-duplicate fix banks ~0 miles (distance
    // from the just-set anchor), so there is no double counting.
    if (useBackground) {
      try {
        if (!(await LocationSvc.hasBackgroundStarted())) {
          await LocationSvc.startBackgroundUpdates();
        }
        feedRef.current.bg = true;
      } catch {
        // Background not available here — the foreground watch above still
        // records while the app is open.
        feedRef.current.bg = false;
      }
    }

    startPoll();
  }, [onWatchSample, startPoll]);

  // Keep a stable ref to the latest startFeed so the poll watchdog can rebuild
  // the feed without a circular useCallback dependency on startPoll.
  startFeedRef.current = startFeed;

  const stopFeed = useCallback(async () => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    if (feedRef.current.watchSub) {
      removeSubSafe(feedRef.current.watchSub);
      feedRef.current.watchSub = undefined;
    }
    if (feedRef.current.bg) {
      await LocationSvc.stopBackgroundUpdates();
      feedRef.current.bg = false;
    }
  }, []);

  const maybeStopFeed = useCallback(async () => {
    if (trackingRef.current || autoRef.current) return;
    await stopFeed();
  }, [stopFeed]);

  // Silent check — never prompts. Used on launch/resume so we do not spam the
  // OS permission dialog (which can bounce the app in and out of foreground).
  const checkPermissions = useCallback(async (): Promise<boolean> => {
    try {
      const supportsBg = LocationSvc.supportsBackgroundLocation();
      setSupportsBackground(supportsBg);
      const fg = await LocationSvc.hasForegroundPermission();
      setPermissionGranted(fg);
      if (!fg) {
        bgGrantedRef.current = false;
        setBackgroundGranted(false);
        return false;
      }
      const bg = supportsBg
        ? await LocationSvc.hasBackgroundPermission()
        : false;
      bgGrantedRef.current = bg;
      setBackgroundGranted(bg);
      return true;
    } catch {
      return false;
    }
  }, []);

  // Interactive request — only call in response to a user action.
  const requestPermissions = useCallback(async (): Promise<boolean> => {
    try {
      const supportsBg = LocationSvc.supportsBackgroundLocation();
      setSupportsBackground(supportsBg);
      const fg = await LocationSvc.requestForegroundPermission();
      setPermissionGranted(fg);
      if (!fg) {
        bgGrantedRef.current = false;
        setBackgroundGranted(false);
        return false;
      }
      if (supportsBg) {
        try {
          const bg = await LocationSvc.requestBackgroundPermission();
          bgGrantedRef.current = bg;
          setBackgroundGranted(bg);
        } catch {
          bgGrantedRef.current = false;
          setBackgroundGranted(false);
        }
      } else {
        bgGrantedRef.current = false;
        setBackgroundGranted(false);
      }
      return true;
    } catch {
      return false;
    }
  }, []);

  const startTracking = useCallback(async (): Promise<boolean> => {
    const ok = await requestPermissions();
    if (!ok) return false;
    let session = await loadSession();
    if (session) session.auto = false;
    else session = createSession(false);
    await saveSession(session);
    trackingRef.current = true;
    setIsTracking(true);
    applySessionToState(session);
    await startFeed();
    return true;
  }, [requestPermissions, applySessionToState, startFeed]);

  const stopTracking = useCallback(async () => {
    trackingRef.current = false;
    await finalizeSessionNow();
    setIsTracking(false);
    setCurrentMiles(0);
    setLiveStateMiles({});
    setCurrentSpeedMph(0);
    setCurrentStateCode(null);
    setCurrentAccuracy(null);
    await reloadTrips();
    await maybeStopFeed();
  }, [reloadTrips, maybeStopFeed]);

  // Finalize TODAY's in-progress day immediately (manual "End day now"). Saves
  // it as a completed trip if it has any distance, resets the live odometer, and
  // — crucially — leaves monitoring running so the next movement opens a fresh
  // day automatically. Returns whether a trip was actually saved.
  const endDayNow = useCallback(async (): Promise<boolean> => {
    const finalized = await finalizeSessionNow();
    trackingRef.current = false;
    setIsTracking(false);
    setCurrentMiles(0);
    setLiveStateMiles({});
    setCurrentSpeedMph(0);
    setCurrentStateCode(null);
    setCurrentAccuracy(null);
    await reloadTrips();
    return finalized;
  }, [reloadTrips]);

  // Temporarily stop recording without ending the day (personal / off-duty
  // driving). The open session — if any — is left intact and its total frozen;
  // the session service skips auto-start and banks no miles while suspended.
  const suspendTracking = useCallback(async () => {
    suspendedRef.current = true;
    setIsSuspended(true);
    await setSuspendedFlag(true);
    setCurrentSpeedMph(0);
  }, []);

  // Resume on-duty recording. Mileage picks up from the current position, so
  // the distance covered while suspended is never counted.
  const resumeTracking = useCallback(async () => {
    suspendedRef.current = false;
    setIsSuspended(false);
    await setSuspendedFlag(false);
  }, []);

  // Correct TODAY's running miles without ending the day. Overwrites the live
  // session's per-state miles and pushes the result straight into UI state so
  // the odometer updates instantly; recording continues from the next fix.
  const updateCurrentMiles = useCallback(
    async (stateMiles: StateMiles) => {
      const session = await updateSessionMiles(stateMiles);
      trackingRef.current = true;
      applySessionToState(session);
    },
    [applySessionToState],
  );

  const setAutoDetect = useCallback(
    async (value: boolean): Promise<boolean> => {
      if (value) {
        const ok = await requestPermissions();
        if (!ok) return false;
        autoRef.current = true;
        setAutoDetectState(true);
        await setAutoEnabledFlag(true);
        await startFeed();
        return true;
      }
      autoRef.current = false;
      setAutoDetectState(false);
      await setAutoEnabledFlag(false);
      await maybeStopFeed();
      return true;
    },
    [requestPermissions, startFeed, maybeStopFeed],
  );

  // Always-on monitoring (silent): arm auto-detect and, IF permission was
  // already granted, keep the location feed running. Never prompts — safe to
  // call on launch and on every resume without spamming the OS dialog.
  const ensureMonitoring = useCallback(async (): Promise<boolean> => {
    autoRef.current = true;
    setAutoDetectState(true);
    await setAutoEnabledFlag(true);
    const ok = await checkPermissions();
    if (!ok) return false;
    await startFeed();
    return true;
  }, [checkPermissions, startFeed]);

  // Interactive enable (from the "Enable" button): request permission, then
  // start monitoring. Requests background only where it is actually supported.
  const enableMonitoring = useCallback(async (): Promise<boolean> => {
    autoRef.current = true;
    setAutoDetectState(true);
    await setAutoEnabledFlag(true);
    const ok = await requestPermissions();
    if (!ok) return false;
    await startFeed();
    return true;
  }, [requestPermissions, startFeed]);

  // Interactive upgrade to "Always"/background location (from the Track tab).
  // Ensures foreground first (required before background can be requested),
  // requests background, then (re)starts the feed so it upgrades from a
  // foreground watch to true background updates. Returns whether background is
  // now granted so the UI can guide the driver to Settings if still denied.
  const promptBackgroundPermission = useCallback(async (): Promise<boolean> => {
    autoRef.current = true;
    setAutoDetectState(true);
    await setAutoEnabledFlag(true);
    const ok = await requestPermissions();
    if (!ok) return false;
    await startFeed();
    return bgGrantedRef.current;
  }, [requestPermissions, startFeed]);

  const addManualTrip = useCallback((stateMiles: StateMiles, date: number) => {
    (async () => {
      const miles = Object.values(stateMiles).reduce((a, b) => a + b, 0);
      const trip: Trip = {
        id: String(Date.now()),
        startedAt: date,
        endedAt: date,
        miles,
        stateMiles,
        auto: false,
        manual: true,
      };
      const fresh = await loadTrips();
      const next = [trip, ...fresh];
      await saveTrips(next);
      tripsRef.current = next;
      setTrips(next);
    })();
  }, []);

  const deleteTrip = useCallback((id: string) => {
    (async () => {
      const fresh = await loadTrips();
      const next = fresh.filter((t) => t.id !== id);
      await saveTrips(next);
      tripsRef.current = next;
      setTrips(next);
    })();
  }, []);

  // Correct a recorded trip's per-state miles (e.g. to match the odometer or a
  // logbook). Values are clamped/rounded, zero-mile states are dropped, the
  // total is recomputed from the sum, and the trip is flagged as edited.
  const updateTrip = useCallback((id: string, stateMiles: StateMiles) => {
    (async () => {
      const cleaned: StateMiles = {};
      for (const [code, value] of Object.entries(stateMiles)) {
        const v = Math.max(0, Math.round((value || 0) * 10) / 10);
        if (v > 0) cleaned[code] = v;
      }
      const miles = Object.values(cleaned).reduce((a, b) => a + b, 0);
      const fresh = await loadTrips();
      const next = fresh.map((t) =>
        t.id === id
          ? { ...t, stateMiles: cleaned, miles, edited: true }
          : t,
      );
      await saveTrips(next);
      tripsRef.current = next;
      setTrips(next);
    })();
  }, []);

  const addFuelPurchase = useCallback((entry: Omit<FuelPurchase, 'id'>) => {
    (async () => {
      const purchase: FuelPurchase = {
        id: String(Date.now()),
        ...entry,
      };
      const fresh = await loadFuel();
      const next = [purchase, ...fresh];
      await saveFuel(next);
      fuelRef.current = next;
      setFuel(next);

      // Remember the vendor/station for the fuel-entry quick-pick chips
      // (most-recently-used, deduped, capped at 5).
      if (entry.vendor && entry.vendor.trim()) {
        const freshVendors = await loadRecentVendors();
        const nextVendors = mergeRecentVendor(freshVendors, entry.vendor);
        await saveRecentVendors(nextVendors);
        setRecentVendors(nextVendors);
      }
    })();
  }, []);

  // Correct an existing fuel purchase in place (date, state, gallons, cost,
  // odometer, vendor) so a mistyped entry can be fixed instead of deleted.
  const updateFuelPurchase = useCallback(
    (id: string, entry: Omit<FuelPurchase, 'id'>) => {
      (async () => {
        const fresh = await loadFuel();
        const next = fresh.map((f) => (f.id === id ? { ...f, ...entry, id } : f));
        await saveFuel(next);
        fuelRef.current = next;
        setFuel(next);

        if (entry.vendor && entry.vendor.trim()) {
          const freshVendors = await loadRecentVendors();
          const nextVendors = mergeRecentVendor(freshVendors, entry.vendor);
          await saveRecentVendors(nextVendors);
          setRecentVendors(nextVendors);
        }
      })();
    },
    [],
  );

  const deleteFuelPurchase = useCallback((id: string) => {
    (async () => {
      const fresh = await loadFuel();
      const next = fresh.filter((f) => f.id !== id);
      await saveFuel(next);
      fuelRef.current = next;
      setFuel(next);
    })();
  }, []);

  // Log a Diesel Exhaust Fluid (DEF) purchase, kept separate from diesel fuel
  // so it never mixes into IFTA fuel-tax gallons.
  const addDefPurchase = useCallback((entry: Omit<DefPurchase, 'id'>) => {
    (async () => {
      const purchase: DefPurchase = { id: String(Date.now()), ...entry };
      const fresh = await loadDef();
      const next = [purchase, ...fresh];
      await saveDef(next);
      defRef.current = next;
      setDef(next);
    })();
  }, []);

  // Correct an existing DEF purchase in place (date, gallons, price per gallon)
  // so a mistyped entry can be fixed instead of deleted and re-added.
  const updateDefPurchase = useCallback(
    (id: string, entry: Omit<DefPurchase, 'id'>) => {
      (async () => {
        const fresh = await loadDef();
        const next = fresh.map((d) => (d.id === id ? { ...d, ...entry, id } : d));
        await saveDef(next);
        defRef.current = next;
        setDef(next);
      })();
    },
    [],
  );

  const deleteDefPurchase = useCallback((id: string) => {
    (async () => {
      const fresh = await loadDef();
      const next = fresh.filter((d) => d.id !== id);
      await saveDef(next);
      defRef.current = next;
      setDef(next);
    })();
  }, []);

  const clearAll = useCallback(() => {
    (async () => {
      await saveTrips([]);
      await saveFuel([]);
      await saveDef([]);
      await saveRecentVendors([]);
      await saveSession(null);
      tripsRef.current = [];
      setTrips([]);
      fuelRef.current = [];
      setFuel([]);
      defRef.current = [];
      setDef([]);
      setRecentVendors([]);
    })();
  }, []);

  // Initial load + restore an in-progress / armed session after relaunch.
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
      // Close out any session left open from a previous day before loading so
      // the finalized trip is included and today starts fresh.
      await rolloverIfNewDay();

      const [loaded, loadedFuel, loadedDef, loadedVendors] =
        await Promise.all([
          loadTrips(),
          loadFuel(),
          loadDef(),
          loadRecentVendors(),
        ]);
      if (!mounted) return;
      tripsRef.current = loaded;
      setTrips(loaded);
      fuelRef.current = loadedFuel;
      setFuel(loadedFuel);
      defRef.current = loadedDef;
      setDef(loadedDef);
      setRecentVendors(loadedVendors);
      setIsLoading(false);

      // Restore a suspend that was active when the app last closed.
      const suspended = await getSuspended();
      suspendedRef.current = suspended;
      setIsSuspended(suspended);

      const session = await recoverSession();
      if (session) applySessionToState(session);
      refreshRecordActivity();

      // Keep background physical-activity monitoring running on every launch.
      await ensureMonitoring();

      // Show the current jurisdiction immediately, even before driving starts.
      refreshCurrentLocation();

      // Run the automatic 45-day backup if it is due (no-op otherwise).
      maybeRunAutoBackup().catch(() => {});
      } catch (err) {
        // Never let initialization throw an unhandled rejection.
        console.error('Trip initialization failed:', err);
        if (mounted) setIsLoading(false);
      }
    })();
    return () => {
      mounted = false;
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [
    applySessionToState,
    ensureMonitoring,
    refreshCurrentLocation,
    refreshRecordActivity,
  ]);
  // On resume, refresh UI and reload trips (background may have finalized one).
  // On leaving the foreground (screen lock / minimize) we proactively (re)start
  // the OS background-updates service so recording survives the screen turning
  // off — see the comment in the 'background' branch.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') {
        (async () => {
          try {
          // If a new day started while backgrounded, close out yesterday first.
          await rolloverIfNewDay();
          const session = await recoverSession();
          applySessionToState(session);
          await reloadTrips();
          await reloadFuel();
          await reloadDef();
          refreshRecordActivity();
          // Re-arm always-on monitoring in case the OS stopped it.
          await ensureMonitoring();
          // Refresh the displayed current location on resume.
          refreshCurrentLocation();
          // Run the automatic 45-day backup if it has come due while away.
          maybeRunAutoBackup().catch(() => {});
          } catch (err) {
            // Never let the resume handler throw an unhandled rejection.
            console.error('Resume refresh failed:', err);
          }
        })();
        return;
      }

      // The app is leaving the foreground (the screen locked / timed out, or the
      // driver switched away). A bare foreground watch is SUSPENDED by the OS as
      // soon as the screen sleeps, so the OS background-updates service — which
      // runs as an Android foreground service and keeps the process alive — must
      // ALREADY be running before this point. It is: startFeed() starts it while
      // the app is active (on launch, resume, and when recording begins).
      if (
        !(
          (autoRef.current || trackingRef.current) &&
          LocationSvc.supportsBackgroundLocation() &&
          bgGrantedRef.current
        )
      ) {
        return;
      }

      if (Platform.OS === 'android') {
        // CRITICAL: Android 12+ FATALLY crashes with
        // ForegroundServiceStartNotAllowedException if a foreground service is
        // STARTED from the background — a native crash that JS .catch() cannot
        // swallow. Calling startFeed() here (which starts the location
        // foreground service) is exactly what closed the app the instant the
        // screen timed out. The service is already running from the foreground,
        // so we do NOTHING on this transition and simply let it keep the process
        // alive with the screen off. It is re-established on the next resume if
        // the OS ever stopped it.
        return;
      }

      // iOS has no foreground-service start restriction and permits
      // (re)starting background location updates during the inactive/background
      // transition. startFeed() is idempotent, so ensure the background feed is
      // running so recording survives screen lock.
      startFeed().catch(() => {});
    });
    return () => sub.remove();
  }, [
    applySessionToState,
    reloadTrips,
    reloadFuel,
    reloadDef,
    ensureMonitoring,
    startFeed,
    refreshCurrentLocation,
    refreshRecordActivity,
  ]);

  // Periodically refresh the displayed current location while parked/armed so
  // the Track tab's state chip stays current without any driver interaction.
  // Only runs in the foreground; recording sessions update the state on their
  // own, and refreshCurrentLocation no-ops while actively tracking.
  useEffect(() => {
    refreshCurrentLocation();
    const id = setInterval(() => {
      if (AppState.currentState === 'active') refreshCurrentLocation();
    }, 30000);
    return () => clearInterval(id);
  }, [refreshCurrentLocation]);

  return (
    <TripContext.Provider
      value={{
        trips,
        isLoading,
        isTracking,
        isSuspended,
        autoDetect,
        permissionGranted,
        backgroundGranted,
        supportsBackground,
        currentMiles,
        currentStateCode,
        currentSpeedMph,
        currentAccuracy,
        liveStateMiles,
        currentCrossings,
        lastForegroundRecordAt,
        lastBackgroundRecordAt,
        startTracking,
        stopTracking,
        endDayNow,
        suspendTracking,
        resumeTracking,
        updateCurrentMiles,
        setAutoDetect,
        ensureMonitoring,
        enableMonitoring,
        promptBackgroundPermission,
        addManualTrip,
        deleteTrip,
        updateTrip,
        fuel,
        recentVendors,
        addFuelPurchase,
        updateFuelPurchase,
        deleteFuelPurchase,
        def,
        addDefPurchase,
        updateDefPurchase,
        deleteDefPurchase,
        clearAll,
        reloadAll,
      }}
    >
      {children}
    </TripContext.Provider>
  );
}
