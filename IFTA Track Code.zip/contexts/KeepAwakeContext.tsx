// Keeps the screen on / prevents the device from auto-locking while enabled.
// The preference is persisted on-device and re-applied on launch. Uses
// expo-keep-awake with a fixed tag so the lock stays active app-wide (across
// every screen) until the driver turns it off — useful for glancing at live
// mileage on a mount while driving without the phone dimming and locking.

import React, {
  createContext,
  ReactNode,
  useCallback,
  useEffect,
  useState,
} from 'react';
import {
  activateKeepAwakeAsync,
  deactivateKeepAwake,
} from 'expo-keep-awake';
import { loadKeepAwake, saveKeepAwake } from '@/services/storageService';

const KEEP_AWAKE_TAG = 'ifta-track-keep-awake';

type KeepAwakeContextType = {
  keepAwake: boolean;
  setKeepAwake: (value: boolean) => Promise<void>;
};

export const KeepAwakeContext = createContext<KeepAwakeContextType | undefined>(
  undefined,
);

async function applyKeepAwake(enabled: boolean) {
  try {
    if (enabled) {
      await activateKeepAwakeAsync(KEEP_AWAKE_TAG);
    } else {
      await deactivateKeepAwake(KEEP_AWAKE_TAG);
    }
  } catch {
    // No-op on platforms where keep-awake is unavailable (e.g. web).
  }
}

export function KeepAwakeProvider({ children }: { children: ReactNode }) {
  const [keepAwake, setKeepAwakeState] = useState(false);

  // Restore the saved preference on launch and apply it.
  useEffect(() => {
    let mounted = true;
    (async () => {
      const saved = await loadKeepAwake();
      if (!mounted) return;
      setKeepAwakeState(saved);
      if (saved) await applyKeepAwake(true);
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const setKeepAwake = useCallback(async (value: boolean) => {
    setKeepAwakeState(value);
    await saveKeepAwake(value);
    await applyKeepAwake(value);
  }, []);

  return (
    <KeepAwakeContext.Provider value={{ keepAwake, setKeepAwake }}>
      {children}
    </KeepAwakeContext.Provider>
  );
}
