// Provider only. Owns the 7-day trial state, re-checks expiry on resume and on a
// slow interval so the lock appears when the trial lapses mid-session, and
// exposes an unlock-code redeem action. Fails OPEN: any error keeps the app
// usable rather than locking the driver out.

import React, {
  createContext,
  useCallback,
  useEffect,
  useState,
  ReactNode,
} from 'react';
import { AppState } from 'react-native';
import {
  TrialStatus,
  getTrialStatus,
  initTrial,
  redeemUnlockCode,
} from '@/services/trialService';

type TrialContextType = {
  loading: boolean;
  status: TrialStatus | null;
  locked: boolean; // trial expired AND not unlocked
  redeem: (code: string) => Promise<boolean>;
  refresh: () => Promise<void>;
};

export const TrialContext = createContext<TrialContextType | undefined>(
  undefined,
);

export function TrialProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<TrialStatus | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (initial: boolean) => {
    try {
      const next = initial ? await initTrial() : await getTrialStatus();
      setStatus(next);
    } catch {
      // Fail open: never lock the user out because of a storage error.
    } finally {
      setLoading(false);
    }
  }, []);

  const refresh = useCallback(async () => {
    await load(false);
  }, [load]);

  const redeem = useCallback(
    async (code: string) => {
      const ok = await redeemUnlockCode(code);
      if (ok) await load(false);
      return ok;
    },
    [load],
  );

  useEffect(() => {
    load(true);
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') load(false);
    });
    const timer = setInterval(() => load(false), 60000);
    return () => {
      sub.remove();
      clearInterval(timer);
    };
  }, [load]);

  const locked = !!status && status.expired && !status.unlocked;

  return (
    <TrialContext.Provider value={{ loading, status, locked, redeem, refresh }}>
      {children}
    </TrialContext.Provider>
  );
}
