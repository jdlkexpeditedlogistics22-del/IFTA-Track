// Powered by OnSpace.AI

import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTrips } from '@/hooks/useTrips';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { SegmentedControl } from '@/components/ui/SegmentedControl';
import { EmptyState } from '@/components/feature/EmptyState';
import { ScreenHeader } from '@/components/layout/ScreenHeader';
import {
  filterTrips,
  PERIOD_OPTIONS,
  Period,
  periodLabel,
  totalMiles,
} from '@/services/aggregation';
import { Trip } from '@/services/types';
import { formatDate, formatMiles, formatTime } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function TripsScreen() {
  const { trips } = useTrips();
  const router = useRouter();
  const [period, setPeriod] = useState<Period>('quarter');

  // Separate trip miles by the selected period (day / month / quarter / year).
  const visibleTrips = useMemo(
    () => filterTrips(trips, period),
    [trips, period],
  );

  const periodMiles = useMemo(() => totalMiles(visibleTrips), [visibleTrips]);

  const renderItem = useCallback(
    ({ item }: { item: Trip }) => (
      <Pressable
        onPress={() => router.push(`/trip/${item.id}`)}
        style={({ pressed }) => [{ opacity: pressed ? 0.9 : 1 }]}
      >
        <Card style={styles.tripCard}>
          <View style={styles.tripIcon}>
            <MaterialIcons
              name={item.manual ? 'edit' : item.auto ? 'auto-mode' : 'navigation'}
              size={22}
              color={colors.primary}
            />
          </View>
          <View style={styles.tripBody}>
            <Text style={styles.tripDate}>{formatDate(item.startedAt)}</Text>
            <Text style={styles.tripMeta}>
              {item.manual ? 'Manual entry' : formatTime(item.startedAt)} ·{' '}
              {Object.keys(item.stateMiles).length}{' '}
              {Object.keys(item.stateMiles).length === 1 ? 'state' : 'states'}
            </Text>
          </View>
          <View style={styles.tripRight}>
            <Text style={styles.tripMiles}>{formatMiles(item.miles)}</Text>
            <Text style={styles.tripUnit}>mi</Text>
          </View>
        </Card>
      </Pressable>
    ),
    [router],
  );

  const header = (
    <View>
      <ScreenHeader
        title="Trip Log"
        subtitle="On-device history"
        right={
          <Button
            label="Add"
            icon="add"
            variant="secondary"
            onPress={() => router.push('/add-trip')}
            style={styles.addBtn}
          />
        }
      />
      <SegmentedControl
        options={PERIOD_OPTIONS}
        value={period}
        onChange={setPeriod}
      />

      <Card style={styles.totalCard}>
        <View style={styles.flex1}>
          <Text style={styles.totalLabel}>{periodLabel(period)}</Text>
          <Text style={styles.totalValue}>{formatMiles(periodMiles)} mi</Text>
          <Text style={styles.totalSub}>
            {visibleTrips.length}{' '}
            {visibleTrips.length === 1 ? 'trip' : 'trips'} this{' '}
            {period === 'year' ? 'year' : period}
          </Text>
        </View>
        <View style={styles.totalIcon}>
          <MaterialIcons name="route" size={28} color={colors.primary} />
        </View>
      </Card>

      <Text style={styles.sectionTitle}>Trips</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <FlatList
        data={visibleTrips}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListHeaderComponent={header}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        ListEmptyComponent={
          <EmptyState
            title="No trips in this period"
            message="No trips recorded for the selected period. Change the period above, or add a manual entry and set its trip date."
          />
        }
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  flex1: {
    flex: 1,
  },
  addBtn: {
    minHeight: 40,
    paddingHorizontal: spacing.md,
  },
  totalCard: {
    marginTop: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.lg,
  },
  totalLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  totalValue: {
    ...typography.display,
    fontSize: 36,
    color: colors.text,
    marginTop: 2,
  },
  totalSub: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 4,
  },
  totalIcon: {
    width: 56,
    height: 56,
    borderRadius: radius.lg,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionTitle: {
    ...typography.h3,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.xs,
  },
  tripCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  tripIcon: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tripBody: {
    flex: 1,
  },
  tripDate: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  tripMeta: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  tripRight: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
  },
  tripMiles: {
    ...typography.h2,
    color: colors.primary,
  },
  tripUnit: {
    ...typography.caption,
    color: colors.textSubtle,
  },
});
