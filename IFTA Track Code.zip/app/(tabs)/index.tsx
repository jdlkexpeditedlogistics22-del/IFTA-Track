import React, { useCallback, useMemo } from 'react';
import {
  FlatList,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { useTrial } from '@/hooks/useTrial';
import { Card } from '@/components/ui/Card';
import { StateRow } from '@/components/feature/StateRow';
import { ScreenHeader } from '@/components/layout/ScreenHeader';
import { formatDate, formatMiles, formatTime } from '@/constants/format';
import { stateLabel } from '@/constants/states';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function TrackScreen() {
  const {
    isTracking,
    permissionGranted,
    backgroundGranted,
    supportsBackground,
    currentStateCode,
    currentSpeedMph,
    currentMiles,
    liveStateMiles,
    currentCrossings,
    enableMonitoring,
    promptBackgroundPermission,
    isSuspended,
    suspendTracking,
    resumeTracking,
  } = useTrips();
  const { showAlert } = useAlert();
  const { status: trialStatus } = useTrial();
  const router = useRouter();

  // Surface a gentle heads-up only in the final stretch of the trial: not yet
  // unlocked, not expired (the gate covers that), and 3 or fewer days left.
  const showTrialBanner =
    !!trialStatus &&
    !trialStatus.unlocked &&
    !trialStatus.expired &&
    trialStatus.expiresAt != null &&
    trialStatus.daysLeft <= 3;

  const goToUnlock = useCallback(() => {
    router.push('/settings');
  }, [router]);

  const breakdown = useMemo(
    () =>
      Object.entries(liveStateMiles)
        .map(([code, miles]) => ({ code, miles }))
        .sort((a, b) => b.miles - a.miles),
    [liveStateMiles],
  );
  const maxMiles = breakdown[0]?.miles || 1;

  const handleEnable = useCallback(async () => {
    const ok = await enableMonitoring();
    if (ok) return;
    const buttons =
      Platform.OS === 'web'
        ? undefined
        : [
            { text: 'Not now', style: 'cancel' as const },
            {
              text: 'Open Settings',
              onPress: () => {
                Linking.openSettings().catch(() => {});
              },
            },
          ];
    showAlert(
      'Location access needed',
      'Allow precise location access, set to "Always", so mileage records while you drive. If no prompt appears, turn on location for this app in Settings.',
      buttons,
    );
  }, [enableMonitoring, showAlert]);

  // Foreground is granted but the driver only allowed "While Using" — mileage
  // records solely while the app is open. Prompt to upgrade to "Always"; if the
  // OS will not re-prompt, guide the driver to Settings.
  const handleAllowAlways = useCallback(async () => {
    const granted = await promptBackgroundPermission();
    if (granted) return;
    const buttons =
      Platform.OS === 'web'
        ? undefined
        : [
            { text: 'Not now', style: 'cancel' as const },
            {
              text: 'Open Settings',
              onPress: () => {
                Linking.openSettings().catch(() => {});
              },
            },
          ];
    showAlert(
      'Allow "Always" location',
      'To keep recording mileage while the app is closed, set location access for this app to "Always" in Settings, then reopen the app.',
      buttons,
    );
  }, [promptBackgroundPermission, showAlert]);

  // Temporarily suspend recording for personal / off-duty driving. Confirm
  // first so the driver knows on-duty mileage stops until they resume.
  const handleSuspend = useCallback(() => {
    showAlert(
      'Suspend tracking?',
      'Mileage stops recording until you resume. Use this for personal or off-duty driving. The day stays open, so on-duty miles continue when you resume.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Suspend', onPress: () => suspendTracking() },
      ],
    );
  }, [showAlert, suspendTracking]);

  const handleResume = useCallback(() => {
    resumeTracking();
  }, [resumeTracking]);

  // Records reliably in the background only when "Always" is granted (or on a
  // platform without a background mode). Otherwise flag that recording is
  // limited to while the app is open.
  const needsBackground =
    permissionGranted && supportsBackground && !backgroundGranted;
  const fullyActive =
    permissionGranted && (!supportsBackground || backgroundGranted);

  // While a trip is active, distinguish real driving from a stop: with no
  // measurable movement show "Idle" (the session stays open, mileage just is
  // not climbing) instead of a misleading status.
  const isMoving = isTracking && currentSpeedMph >= 1;
  const statusText = isSuspended
    ? 'Suspended'
    : isTracking
      ? isMoving
        ? 'Driving'
        : 'Idle'
      : permissionGranted
        ? 'Armed'
        : 'Paused';
  const statusColor = isSuspended
    ? colors.textMuted
    : isTracking
      ? isMoving
        ? colors.success
        : colors.danger
      : permissionGranted
        ? colors.info
        : colors.textMuted;

  const header = (
    <View>
      <ScreenHeader
        logo={require('@/assets/images/app-icon.png')}
        title="IFTA Track"
        subtitle="GPS mileage by Jurisdiction"
      />

      {showTrialBanner ? (
        <Pressable
          onPress={goToUnlock}
          style={({ pressed }) => [
            styles.trialBanner,
            { opacity: pressed ? 0.9 : 1 },
          ]}
        >
          <MaterialIcons name="schedule" size={18} color={colors.primary} />
          <View style={styles.trialBannerBody}>
            <Text style={styles.trialBannerTitle}>
              {`Trial ends in ${trialStatus?.daysLeft} ${
                trialStatus?.daysLeft === 1 ? 'day' : 'days'
              }`}
            </Text>
            <Text style={styles.trialBannerSub}>
              {`Ends ${formatDate(trialStatus!.expiresAt!)} \u00b7 Tap to enter unlock code`}
            </Text>
          </View>
          <MaterialIcons
            name="chevron-right"
            size={20}
            color={colors.textMuted}
          />
        </Pressable>
      ) : null}

      <Card style={styles.heroCard}>
        <View style={styles.heroTop}>
          <View style={styles.stateChip}>
            <MaterialIcons name="place" size={16} color={colors.primary} />
            <Text style={styles.stateChipText}>
              {currentStateCode ? stateLabel(currentStateCode) : 'Locating...'}
            </Text>
          </View>
          <View style={styles.statusWrap}>
            <Text style={[styles.statusText, { color: statusColor }]}>
              {statusText}
            </Text>
          </View>
        </View>

        <View style={styles.metricsRow}>
          <View style={styles.metric}>
            <Text style={styles.metricValue}>{currentSpeedMph}</Text>
            <Text style={styles.metricLabel}>mph</Text>
          </View>
          <View style={styles.metricDivider} />
          <View style={styles.metricPrimary}>
            <Text style={styles.metricValuePrimary}>
              {formatMiles(currentMiles)}
            </Text>
            <Text style={styles.metricLabelPrimary}>miles today</Text>
          </View>
          <View style={styles.metricDivider} />
          <View style={styles.metric}>
            <Text style={styles.metricValue}>{breakdown.length}</Text>
            <Text style={styles.metricLabel}>State(s)</Text>
          </View>
        </View>

      </Card>

      <Card style={styles.autoCard} padded>
        <View style={styles.autoIconWrap}>
          <MaterialIcons
            name={
              fullyActive
                ? 'sensors'
                : needsBackground
                  ? 'error-outline'
                  : 'location-off'
            }
            size={22}
            color={fullyActive ? colors.success : colors.primary}
          />
        </View>
        <View style={styles.autoTextWrap}>
          <Text style={styles.autoTitle}>
            {fullyActive
              ? 'Background monitoring active'
              : needsBackground
                ? 'Background recording is off'
                : 'Monitoring paused'}
          </Text>
          <Text style={styles.autoSub}>
            {fullyActive
              ? 'Auto-detects driving and records mileage at all times, even when the app is closed.'
              : needsBackground
                ? 'Location is set to "While Using", so miles record only while the app is open. Allow "Always" to keep recording in the background.'
                : 'Grant location access to record mileage automatically.'}
          </Text>
        </View>
        {fullyActive ? (
          <View style={styles.livePill}>
            <View style={styles.livePulse} />
            <Text style={styles.livePillText}>ON</Text>
          </View>
        ) : (
          <Pressable
            onPress={needsBackground ? handleAllowAlways : handleEnable}
            hitSlop={8}
            style={({ pressed }) => [
              styles.enableBtn,
              { opacity: pressed ? 0.85 : 1 },
            ]}
          >
            <Text style={styles.enableBtnText}>
              {needsBackground ? 'Allow Always' : 'Enable'}
            </Text>
          </Pressable>
        )}
      </Card>

      {permissionGranted ? (
        <Card
          style={[styles.suspendCard, isSuspended && styles.suspendCardActive]}
        >
          <View style={styles.autoIconWrap}>
            <MaterialIcons
              name={isSuspended ? 'pause-circle-filled' : 'pause-circle-outline'}
              size={22}
              color={isSuspended ? colors.primary : colors.textSubtle}
            />
          </View>
          <View style={styles.autoTextWrap}>
            <Text style={styles.autoTitle}>
              {isSuspended ? 'Tracking suspended' : 'Suspend tracking'}
            </Text>
            <Text style={styles.autoSub}>
              {isSuspended
                ? 'Mileage is paused. Personal / off-duty miles are not recorded. Resume when back on duty.'
                : 'Temporarily pause recording for personal or off-duty driving without ending the day.'}
            </Text>
          </View>
          <Pressable
            onPress={isSuspended ? handleResume : handleSuspend}
            hitSlop={8}
            style={({ pressed }) => [
              isSuspended ? styles.resumeBtn : styles.suspendBtn,
              { opacity: pressed ? 0.85 : 1 },
            ]}
          >
            <Text
              style={
                isSuspended ? styles.resumeBtnText : styles.suspendBtnText
              }
            >
              {isSuspended ? 'Resume' : 'Suspend'}
            </Text>
          </Pressable>
        </Card>
      ) : null}

      {currentCrossings.length > 0 ? (
        <Card style={styles.feedCard}>
          <View style={styles.feedHeaderRow}>
            <MaterialIcons name="swap-horiz" size={18} color={colors.primary} />
            <Text style={styles.feedTitle}>Border crossings today</Text>
          </View>
          {currentCrossings.map((c, idx) => (
            <View
              key={`${c.stateCode}-${c.at}-${idx}`}
              style={[
                styles.feedRow,
                idx === currentCrossings.length - 1 && styles.feedRowLast,
              ]}
            >
              <View style={styles.feedIconWrap}>
                <MaterialIcons name="place" size={18} color={colors.primary} />
              </View>
              <View style={styles.feedTextWrap}>
                <Text style={styles.feedValue}>{stateLabel(c.stateCode)}</Text>
                <Text style={styles.feedLabel}>
                  {`${formatTime(c.at)} \u00b7 at ${formatMiles(c.miles)} mi`}
                </Text>
              </View>
            </View>
          ))}
        </Card>
      ) : null}

      <View style={styles.breakdownHead}>
        <Text style={styles.sectionTitle}>Running state breakdown</Text>
        <Pressable
          onPress={() => router.push('/edit-today')}
          hitSlop={8}
          style={({ pressed }) => [
            styles.editMilesBtn,
            { opacity: pressed ? 0.7 : 1 },
          ]}
          accessibilityLabel="Edit today's miles"
        >
          <MaterialIcons name="edit" size={16} color={colors.primary} />
          <Text style={styles.editMilesText}>Edit miles</Text>
        </Pressable>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <FlatList
        data={breakdown}
        keyExtractor={(item) => item.code}
        renderItem={({ item }) => (
          <StateRow code={item.code} miles={item.miles} max={maxMiles} />
        )}
        ListHeaderComponent={header}
        ListEmptyComponent={
          <View style={styles.placeholder}>
            <MaterialIcons name="route" size={28} color={colors.textMuted} />
            <Text style={styles.placeholderText}>
              {isTracking
                ? 'Drive to start accumulating state miles.'
                : 'Monitoring is on. Miles record automatically once you start driving.'}
            </Text>
          </View>
        }
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  trialBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginBottom: spacing.md,
  },
  trialBannerBody: {
    flex: 1,
  },
  trialBannerTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  trialBannerSub: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 1,
  },
  heroCard: {
    padding: spacing.lg,
    gap: spacing.lg,
  },
  heroTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  stateChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.primarySoft,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
  },
  stateChipText: {
    ...typography.small,
    color: colors.primary,
    fontWeight: '700',
  },
  statusWrap: {
    alignItems: 'flex-end',
    gap: 5,
  },
  statusText: {
    ...typography.caption,
    fontWeight: '700',
  },
  metricsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.lg,
  },
  metric: {
    alignItems: 'center',
  },
  metricValue: {
    ...typography.h2,
    color: colors.text,
  },
  metricLabel: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  metricPrimary: {
    alignItems: 'center',
    paddingHorizontal: spacing.xs,
  },
  metricValuePrimary: {
    fontSize: 36,
    fontWeight: '800',
    color: colors.primary,
    lineHeight: 40,
  },
  metricLabelPrimary: {
    ...typography.small,
    color: colors.primary,
    fontWeight: '700',
    marginTop: 2,
  },
  metricDivider: {
    width: 1,
    height: 32,
    backgroundColor: colors.border,
  },
  autoCard: {
    marginTop: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  autoIconWrap: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  autoTextWrap: {
    flex: 1,
  },
  autoTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  autoSub: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  livePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.successSoft,
    paddingHorizontal: spacing.md,
    height: 32,
    borderRadius: radius.pill,
  },
  livePulse: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.success,
  },
  livePillText: {
    ...typography.caption,
    color: colors.success,
    fontWeight: '800',
  },
  enableBtn: {
    paddingHorizontal: spacing.md,
    height: 36,
    borderRadius: radius.pill,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  enableBtnText: {
    ...typography.small,
    color: colors.onPrimary,
    fontWeight: '800',
  },
  suspendCard: {
    marginTop: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  suspendCardActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primarySoft,
  },
  suspendBtn: {
    paddingHorizontal: spacing.md,
    height: 36,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceHigh,
    alignItems: 'center',
    justifyContent: 'center',
  },
  suspendBtnText: {
    ...typography.small,
    color: colors.text,
    fontWeight: '800',
  },
  resumeBtn: {
    paddingHorizontal: spacing.md,
    height: 36,
    borderRadius: radius.pill,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resumeBtnText: {
    ...typography.small,
    color: colors.onPrimary,
    fontWeight: '800',
  },
  feedCard: {
    marginTop: spacing.md,
    padding: spacing.md,
  },
  feedHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  feedTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  feedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  feedRowLast: {
    paddingBottom: 0,
  },
  feedIconWrap: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  feedTextWrap: {
    flex: 1,
  },
  feedLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  feedValue: {
    ...typography.bodyStrong,
    color: colors.text,
    marginTop: 1,
  },
  feedDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  sectionTitle: {
    ...typography.h3,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.xs,
  },
  breakdownHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  editMilesBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.primarySoft,
    marginTop: spacing.lg,
    marginBottom: spacing.xs,
  },
  editMilesText: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '700',
  },
  placeholder: {
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.xl,
  },
  placeholderText: {
    ...typography.body,
    color: colors.textMuted,
    textAlign: 'center',
  },
});
