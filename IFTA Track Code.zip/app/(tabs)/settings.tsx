// Powered by OnSpace.AI

import React, { useMemo } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTrips } from '@/hooks/useTrips';
import { useBackup } from '@/hooks/useBackup';
import { useKeepAwake } from '@/hooks/useKeepAwake';
import { START_ACCURACY_LIMIT_M } from '@/services/sessionService';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { ToggleField } from '@/components/ui/ToggleField';
import { ScreenHeader } from '@/components/layout/ScreenHeader';
import { formatDate, formatDaysUntil, formatRelativeTime } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function SettingsScreen() {
  const { trips, fuel, permissionGranted, currentAccuracy, lastForegroundRecordAt, lastBackgroundRecordAt } = useTrips();
  const { keepAwake, setKeepAwake } = useKeepAwake();
  const {
    isBackingUp,
    isRestoring,
    backup,
    restore,
    lastBackupAt,
    lastBackupMethod,
    nextAutoBackupAt,
  } = useBackup();

  const appName = 'IFTA Track';
  const appVersion = '1.3.9';
  const buildNumber = '21';
  const buildDate = 'Jul 18, 2026';

  // Live GPS signal quality derived from the last fix accuracy (in meters,
  // lower = better). Lets the driver gauge recording reliability at a glance.
  const gpsSignal = useMemo(() => {
    if (!permissionGranted) {
      return { label: 'No GPS', color: colors.textMuted, level: 0 };
    }
    if (currentAccuracy == null) {
      return { label: 'Searching', color: colors.textMuted, level: 0 };
    }
    if (currentAccuracy <= 20) {
      return { label: 'Strong', color: colors.success, level: 3 };
    }
    if (currentAccuracy <= 50) {
      return { label: 'Fair', color: colors.primary, level: 2 };
    }
    return { label: 'Weak', color: colors.danger, level: 1 };
  }, [permissionGranted, currentAccuracy]);

  // Hidden calibration readout for the GPS-lock start gate: show the live fix
  // accuracy against the lock threshold (START_ACCURACY_LIMIT_M) so the auto-
  // start gate can be validated and tuned against real device behavior.
  const lockGate = useMemo(() => {
    if (!permissionGranted) {
      return { text: 'Location access is off', color: colors.textMuted };
    }
    if (currentAccuracy == null) {
      return { text: 'Waiting for first fix', color: colors.textMuted };
    }
    if (currentAccuracy <= START_ACCURACY_LIMIT_M) {
      return { text: 'Locked \u00b7 trips can auto-start', color: colors.success };
    }
    return { text: 'Not locked \u00b7 auto-start held', color: colors.danger };
  }, [permissionGranted, currentAccuracy]);

  // Color the activity dot by how recently each feed banked miles: green when
  // fresh (< 5 min), amber within the hour, muted when older, and neutral when
  // it has never recorded from that feed yet.
  const activityColor = (ts: number | null): string => {
    if (!ts) return colors.border;
    const diff = Date.now() - ts;
    if (diff < 5 * 60000) return colors.success;
    if (diff < 60 * 60000) return colors.primary;
    return colors.textMuted;
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        style={styles.flex1}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <ScreenHeader title="Settings" subtitle="Backup & app data" />

        <Card style={styles.statsCard}>
          <View style={styles.stat}>
            <MaterialIcons name="route" size={20} color={colors.primary} />
            <Text style={styles.statValue}>{trips.length}</Text>
            <Text style={styles.statLabel}>
              {trips.length === 1 ? 'trip' : 'trips'}
            </Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <MaterialIcons
              name="local-gas-station"
              size={20}
              color={colors.primary}
            />
            <Text style={styles.statValue}>{fuel.length}</Text>
            <Text style={styles.statLabel}>
              {fuel.length === 1 ? 'fuel entry' : 'fuel entries'}
            </Text>
          </View>
        </Card>

        <Card style={styles.privacyCard}>
          <MaterialIcons name="lock-outline" size={20} color={colors.primary} />
          <View style={styles.privacyBody}>
            <Text style={styles.privacyTitle}>Stored on this device only</Text>
            <Text style={styles.privacyText}>
              Every trip and fuel entry is saved locally on your phone. Nothing
              is uploaded to any server or cloud. Back up to a file to keep a
              copy.
            </Text>
          </View>
        </Card>

        <Text style={styles.sectionTitle}>GPS signal</Text>
        <Card style={styles.gpsCard}>
          <View style={styles.gpsIconWrap}>
            <MaterialIcons
              name="my-location"
              size={22}
              color={gpsSignal.color}
            />
          </View>
          <View style={styles.flex1}>
            <Text style={styles.gpsCardTitle}>{gpsSignal.label}</Text>
            <Text style={styles.gpsCardSub}>
              {currentAccuracy != null
                ? `Accuracy \u00b1${Math.round(currentAccuracy)} m`
                : permissionGranted
                  ? 'Acquiring satellites...'
                  : 'Location access is off'}
            </Text>
          </View>
          <View style={styles.gpsBars}>
            {[0, 1, 2].map((i) => (
              <View
                key={i}
                style={[
                  styles.gpsBar,
                  { height: 8 + i * 5 },
                  {
                    backgroundColor:
                      i < gpsSignal.level ? gpsSignal.color : colors.border,
                  },
                ]}
              />
            ))}
          </View>
        </Card>

        <Card style={styles.calCard}>
          <View style={styles.calHeader}>
            <MaterialIcons
              name="tune"
              size={16}
              color={colors.textSubtle}
            />
            <Text style={styles.calHeaderText}>Lock gate calibration</Text>
          </View>
          <View style={styles.calRow}>
            <Text style={styles.calLabel}>Current fix accuracy</Text>
            <Text style={styles.calValue}>
              {currentAccuracy != null
                ? `\u00b1${Math.round(currentAccuracy)} m`
                : '\u2014'}
            </Text>
          </View>
          <View style={styles.calRow}>
            <Text style={styles.calLabel}>Lock threshold</Text>
            <Text style={styles.calValue}>{`\u2264 ${START_ACCURACY_LIMIT_M} m`}</Text>
          </View>
          <View style={styles.calDivider} />
          <View style={styles.calRow}>
            <Text style={styles.calLabel}>Auto-start gate</Text>
            <Text style={[styles.calValue, { color: lockGate.color }]}>
              {lockGate.text}
            </Text>
          </View>
          <Text style={styles.calNote}>
            A trip only auto-starts once the fix is within the lock threshold.
            Compare against your device to tune the gate.
          </Text>
        </Card>

        <Text style={styles.sectionTitle}>Recording activity</Text>
        <Card style={styles.section}>
          <Text style={styles.sectionDesc}>
            Confirms mileage is being banked both while the app is open and while
            your phone is locked. Locked-drive recording needs "Always" location
            access.
          </Text>
          <View style={styles.activityRow}>
            <View style={styles.activityIconWrap}>
              <MaterialIcons
                name="phone-android"
                size={20}
                color={colors.primary}
              />
            </View>
            <View style={styles.flex1}>
              <Text style={styles.activityLabel}>Foreground · app open</Text>
              <Text style={styles.activityValue}>
                {formatRelativeTime(lastForegroundRecordAt)}
              </Text>
            </View>
            <View
              style={[
                styles.activityDot,
                { backgroundColor: activityColor(lastForegroundRecordAt) },
              ]}
            />
          </View>
          <View style={styles.activityDivider} />
          <View style={styles.activityRow}>
            <View style={styles.activityIconWrap}>
              <MaterialIcons name="lock" size={20} color={colors.primary} />
            </View>
            <View style={styles.flex1}>
              <Text style={styles.activityLabel}>Background · screen locked</Text>
              <Text style={styles.activityValue}>
                {formatRelativeTime(lastBackgroundRecordAt)}
              </Text>
            </View>
            <View
              style={[
                styles.activityDot,
                { backgroundColor: activityColor(lastBackgroundRecordAt) },
              ]}
            />
          </View>
        </Card>

        <Text style={styles.sectionTitle}>Display</Text>
        <Card style={styles.section}>
          <Text style={styles.sectionDesc}>
            Keep the screen on so your phone does not dim or auto-lock while the
            app is open. Handy for watching live mileage on a dash mount. Leave
            off to conserve battery.
          </Text>
          <ToggleField
            label="Keep screen awake"
            description="Prevent the device from sleeping while IFTA Track is open"
            value={keepAwake}
            onValueChange={(v) => {
              setKeepAwake(v);
            }}
            icon="brightness-high"
          />
        </Card>

        <Text style={styles.sectionTitle}>Data backup</Text>
        <Card style={styles.section}>
          <Text style={styles.sectionDesc}>
            Save all trips and fuel purchases to a single file you can store or
            move to another device, then restore it anytime.
          </Text>

          <View style={styles.backupStatus}>
            <View style={styles.backupStatusRow}>
              <MaterialIcons
                name={lastBackupAt ? 'check-circle' : 'schedule'}
                size={18}
                color={lastBackupAt ? colors.success : colors.textMuted}
              />
              <View style={styles.flex1}>
                <Text style={styles.backupStatusLabel}>
                  Last successful backup
                </Text>
                <Text style={styles.backupStatusValue}>
                  {lastBackupAt
                    ? `${formatDate(lastBackupAt)}${
                        lastBackupMethod === 'auto' ? ' \u00b7 automatic' : ''
                      }`
                    : 'Never backed up yet'}
                </Text>
              </View>
            </View>
            <View style={styles.backupStatusRow}>
              <MaterialIcons
                name="event-repeat"
                size={18}
                color={colors.primary}
              />
              <View style={styles.flex1}>
                <Text style={styles.backupStatusLabel}>
                  Automatic backup · every 45 days
                </Text>
                <Text style={styles.backupStatusValue}>
                  {nextAutoBackupAt
                    ? `Next ${formatDate(nextAutoBackupAt)} \u00b7 ${formatDaysUntil(
                        nextAutoBackupAt,
                      )}`
                    : 'Starts after your first backup'}
                </Text>
              </View>
            </View>
          </View>

          <Button
            label="Back up data"
            icon="save-alt"
            onPress={backup}
            loading={isBackingUp}
            disabled={isRestoring}
          />
          <Button
            label="Restore from file"
            icon="restore"
            variant="ghost"
            onPress={restore}
            loading={isRestoring}
            disabled={isBackingUp}
          />
          <View style={styles.note}>
            <MaterialIcons
              name="info-outline"
              size={16}
              color={colors.textMuted}
            />
            <Text style={styles.noteText}>
              Restoring lets you replace all data or merge new entries into what
              you already have.
            </Text>
          </View>
        </Card>

        <Text style={styles.sectionTitle}>About</Text>
        <Card style={styles.aboutCard}>
          <View style={styles.aboutHeader}>
            <Image
              source={require('@/assets/images/app-icon.png')}
              style={styles.aboutLogo}
              contentFit="cover"
              transition={200}
            />
            <View style={styles.aboutHeaderText}>
              <Text style={styles.aboutName} numberOfLines={1}>
                {appName}
              </Text>
              <Text style={styles.aboutTagline}>
                {'IFTA mileage & fuel tracker'}
              </Text>
            </View>
          </View>
          <View style={styles.aboutDivider} />
          <View style={styles.aboutRow}>
            <Text style={styles.aboutRowLabel}>Version</Text>
            <Text style={styles.aboutRowValue}>{appVersion}</Text>
          </View>
          <View style={styles.aboutRow}>
            <Text style={styles.aboutRowLabel}>Build</Text>
            <Text style={styles.aboutRowValue}>{buildNumber}</Text>
          </View>
          <View style={styles.aboutRow}>
            <Text style={styles.aboutRowLabel}>Build date</Text>
            <Text style={styles.aboutRowValue}>{buildDate}</Text>
          </View>
          <View style={styles.aboutDivider} />
          <Text style={styles.aboutCopyright}>
            {'\u00a9 2026 JDLK Expedited Logistics'}
          </Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex1: {
    flex: 1,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  statsCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.lg,
  },
  stat: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  statValue: {
    ...typography.h1,
    color: colors.text,
  },
  statLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  statDivider: {
    width: 1,
    height: 44,
    backgroundColor: colors.border,
  },
  privacyCard: {
    flexDirection: 'row',
    gap: spacing.md,
    alignItems: 'flex-start',
    padding: spacing.lg,
    marginTop: spacing.md,
  },
  privacyBody: {
    flex: 1,
    gap: 2,
  },
  privacyTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  privacyText: {
    ...typography.small,
    color: colors.textSubtle,
    lineHeight: 19,
  },
  sectionTitle: {
    ...typography.h3,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  gpsCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.lg,
  },
  gpsIconWrap: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  gpsCardTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  gpsCardSub: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  gpsBars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 3,
    height: 18,
  },
  gpsBar: {
    width: 4,
    borderRadius: 2,
  },
  calCard: {
    padding: spacing.lg,
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  calHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: spacing.xs,
  },
  calHeaderText: {
    ...typography.caption,
    color: colors.textSubtle,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  calRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  calLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  calValue: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  calDivider: {
    height: 1,
    backgroundColor: colors.border,
  },
  calNote: {
    ...typography.caption,
    color: colors.textMuted,
    lineHeight: 17,
    marginTop: spacing.xs,
  },
  section: {
    gap: spacing.md,
    padding: spacing.lg,
  },
  activityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  activityIconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activityLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  activityValue: {
    ...typography.bodyStrong,
    color: colors.text,
    marginTop: 2,
  },
  activityDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  activityDivider: {
    height: 1,
    backgroundColor: colors.border,
  },
  sectionDesc: {
    ...typography.small,
    color: colors.textSubtle,
    lineHeight: 20,
  },
  backupStatus: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.md,
    padding: spacing.md,
    gap: spacing.md,
  },
  backupStatusRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
  },
  backupStatusLabel: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  backupStatusValue: {
    ...typography.bodyStrong,
    color: colors.text,
    marginTop: 2,
  },
  note: {
    flexDirection: 'row',
    gap: spacing.sm,
    alignItems: 'flex-start',
  },
  noteText: {
    ...typography.caption,
    color: colors.textMuted,
    flex: 1,
    lineHeight: 17,
  },
  aboutCard: {
    padding: spacing.lg,
    gap: spacing.md,
  },
  aboutHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  aboutLogo: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceHigh,
  },
  aboutHeaderText: {
    flex: 1,
  },
  aboutName: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  aboutTagline: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  aboutDivider: {
    height: 1,
    backgroundColor: colors.border,
  },
  aboutRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  aboutRowLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  aboutRowValue: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  aboutCopyright: {
    ...typography.caption,
    color: colors.textMuted,
    textAlign: 'center',
  },
});
