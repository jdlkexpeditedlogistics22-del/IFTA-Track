import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTrips } from '@/hooks/useTrips';
import { useExport } from '@/hooks/useExport';
import { Card } from '@/components/ui/Card';
import { SegmentedControl } from '@/components/ui/SegmentedControl';
import { IftaStateRow } from '@/components/feature/IftaStateRow';
import { MpgTrend } from '@/components/feature/MpgTrend';
import { MilesPieChart } from '@/components/feature/MilesPieChart';
import { EmailReportDialog } from '@/components/feature/EmailReportDialog';
import { ExportOptionsSheet } from '@/components/feature/ExportOptionsSheet';
import { EmptyState } from '@/components/feature/EmptyState';
import { ScreenHeader } from '@/components/layout/ScreenHeader';
import {
  aggregateStateFuel,
  computeFillMpgTrend,
  computeIfta,
  filterFuel,
  filterTrips,
  isInPeriod,
  liveTripFromState,
  PERIOD_OPTIONS,
  Period,
  periodLabel,
  totalFuelCost,
} from '@/services/aggregation';
import { stateLabel } from '@/constants/states';
import {
  formatCurrency,
  formatGallons,
  formatMiles,
  formatMpg,
} from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

type SortBy = 'miles' | 'net' | 'name';

export default function SummaryScreen() {
  const { trips, fuel, def, liveStateMiles } = useTrips();
  const {
    isExporting,
    promptExport,
    exportSheetVisible,
    exportSheetPeriod,
    selectExport,
    closeExportSheet,
    emailDialogVisible,
    emailDialogPeriod,
    sendEmail,
    closeEmailDialog,
  } = useExport();
  const [period, setPeriod] = useState<Period>('quarter');
  const [sortBy, setSortBy] = useState<SortBy>('miles');

  // Track orientation so the two charts can sit side by side in landscape
  // (easier to read on a dash mount). SSR-safe: seed with sane defaults and
  // subscribe to dimension changes rather than reading window at render.
  const [dimensions, setDimensions] = useState({ width: 375, height: 667 });
  useEffect(() => {
    const update = () => setDimensions(Dimensions.get('window'));
    update();
    const sub = Dimensions.addEventListener('change', update);
    return () => sub?.remove();
  }, []);
  const isLandscape = dimensions.width > dimensions.height;

  const filtered = useMemo(
    () => filterTrips(trips, period),
    [trips, period],
  );
  const filteredFuel = useMemo(
    () => filterFuel(fuel, period),
    [fuel, period],
  );
  // Include today's not-yet-saved GPS miles so the summary totals and net
  // taxable gallons reflect live driving (trips are saved to history at
  // midnight). Trip COUNT below stays on finalized trips only.
  const tripsForIfta = useMemo(() => {
    const live = liveTripFromState(liveStateMiles);
    return live && isInPeriod(live.startedAt, period)
      ? [live, ...filtered]
      : filtered;
  }, [filtered, liveStateMiles, period]);
  const ifta = useMemo(
    () => computeIfta(tripsForIfta, filteredFuel),
    [tripsForIfta, filteredFuel],
  );

  // Fuel purchases grouped by the state where they were bought, so the export
  // clearly shows miles, fuel, AND the jurisdictions where fuel was purchased.
  const fuelByState = useMemo(
    () => aggregateStateFuel(filteredFuel),
    [filteredFuel],
  );
  const totalCost = useMemo(
    () => totalFuelCost(filteredFuel),
    [filteredFuel],
  );

  // Diesel Exhaust Fluid for the selected period. DEF is tracked separately
  // from IFTA fuel-tax gallons, so it gets its own spend + gallons readout.
  const filteredDef = useMemo(
    () => def.filter((d) => isInPeriod(d.date, period)),
    [def, period],
  );
  const defTotalGal = useMemo(
    () => filteredDef.reduce((s, d) => s + d.gallons, 0),
    [filteredDef],
  );
  const defTotalCost = useMemo(
    () => filteredDef.reduce((s, d) => s + d.gallons * d.pricePerGallon, 0),
    [filteredDef],
  );

  const max = useMemo(
    () => ifta.rows.reduce((m, r) => Math.max(m, r.miles), 1),
    [ifta.rows],
  );

  // Per-fill MPG trend is computed from the FULL fuel history (not the period
  // filter) so each measurement keeps its previous-odometer anchor and the
  // trend reads correctly across period boundaries.
  const fillMpg = useMemo(() => computeFillMpgTrend(fuel), [fuel]);

  // Ranked most-to-least by miles for the mileage distribution pie chart,
  // independent of the row sort selection below.
  const pieData = useMemo(
    () =>
      ifta.rows
        .map((r) => ({ code: r.code, miles: r.miles }))
        .sort((a, b) => b.miles - a.miles),
    [ifta.rows],
  );

  // Sort the state rows so the on-screen order matches the export order.
  const sorted = useMemo(() => {
    const copy = [...ifta.rows];
    if (sortBy === 'name') {
      copy.sort((a, b) => stateLabel(a.code).localeCompare(stateLabel(b.code)));
    } else if (sortBy === 'net') {
      copy.sort((a, b) => b.netTaxableGallons - a.netTaxableGallons);
    } else {
      copy.sort((a, b) => b.miles - a.miles);
    }
    return copy;
  }, [ifta.rows, sortBy]);

  const periodName = useMemo(
    () => PERIOD_OPTIONS.find((o) => o.key === period)?.label ?? 'Period',
    [period],
  );

  const handleExport = useCallback(() => {
    promptExport(
      sorted.map((r) => ({
        code: r.code,
        miles: r.miles,
        taxableGallons: r.taxableGallons,
        taxPaidGallons: r.taxPaidGallons,
        netTaxableGallons: r.netTaxableGallons,
      })),
      {
        periodName,
        periodLabel: periodLabel(period),
        total: ifta.totalMiles,
        tripCount: filtered.length,
        generatedAt: Date.now(),
        totalGallons: ifta.totalGallons,
        totalFuelCost: totalCost,
        mpg: ifta.mpg,
        fuelByState,
      },
    );
  }, [
    promptExport,
    sorted,
    periodName,
    period,
    ifta.totalMiles,
    ifta.totalGallons,
    ifta.mpg,
    filtered.length,
    fuelByState,
    totalCost,
  ]);

  const header = (
    <View>
      <ScreenHeader
        title="IFTA Summary"
        subtitle="Mileage & fuel tax by jurisdiction"
        right={<ExportButton onPress={handleExport} loading={isExporting} />}
      />

      <SegmentedControl
        options={PERIOD_OPTIONS}
        value={period}
        onChange={setPeriod}
      />

      <Card style={styles.totalCard}>
        <View style={styles.flex1}>
          <Text style={styles.totalLabel}>{periodLabel(period)}</Text>
          <Text style={styles.totalValue}>
            {formatMiles(ifta.totalMiles)} mi
          </Text>
          <Text style={styles.totalSub}>
            {ifta.rows.length} {ifta.rows.length === 1 ? 'state' : 'states'} ·{' '}
            {filtered.length} {filtered.length === 1 ? 'trip' : 'trips'}
          </Text>
        </View>
        <View style={styles.totalIcon}>
          <MaterialIcons name="map" size={28} color={colors.primary} />
        </View>
      </Card>

      <View style={styles.metricsRow}>
        <Card style={styles.metricCard}>
          <View style={styles.metricIcon}>
            <MaterialIcons name="speed" size={18} color={colors.primary} />
          </View>
          <Text style={styles.metricValue}>{formatMpg(ifta.mpg)}</Text>
          <Text style={styles.metricLabel}>Vehicle MPG</Text>
          <Text style={styles.metricSub}>miles ÷ gallons</Text>
        </Card>
        <Card style={styles.metricCard}>
          <View style={styles.metricIcon}>
            <MaterialIcons
              name="local-gas-station"
              size={18}
              color={colors.primary}
            />
          </View>
          <Text style={styles.metricValue}>
            {formatGallons(ifta.totalGallons)}
          </Text>
          <Text style={styles.metricLabel}>Fuel gallons</Text>
          <Text style={styles.metricSub}>tax-paid</Text>
        </Card>
      </View>

      <Card style={styles.defCard}>
        <View style={styles.defIcon}>
          <MaterialIcons name="opacity" size={20} color={colors.primary} />
        </View>
        <View style={styles.flex1}>
          <Text style={styles.defLabel}>DEF spending</Text>
          <Text style={styles.defSub}>
            {formatGallons(defTotalGal)} gal · {filteredDef.length}{' '}
            {filteredDef.length === 1 ? 'purchase' : 'purchases'}
          </Text>
        </View>
        <Text style={styles.defValue}>{formatCurrency(defTotalCost)}</Text>
      </Card>

      <View style={isLandscape ? styles.chartsRow : undefined}>
        <View style={isLandscape ? styles.chartCol : undefined}>
          <Text style={[styles.sectionTitle, styles.sectionSpacer]}>
            Mileage distribution
          </Text>
          <Text style={styles.legend}>
            Share of recorded miles by jurisdiction, most to least traveled.
          </Text>
          <MilesPieChart data={pieData} />
        </View>

        <View style={isLandscape ? styles.chartCol : undefined}>
          <Text style={[styles.sectionTitle, styles.sectionSpacer]}>
            Fuel economy trend
          </Text>
          <MpgTrend fills={fillMpg} />
        </View>
      </View>

      <View style={styles.sortRow}>
        <Text style={styles.sectionTitle}>By state</Text>
        <View style={styles.sortButtons}>
          <SortButton
            label="Miles"
            active={sortBy === 'miles'}
            onPress={() => setSortBy('miles')}
          />
          <SortButton
            label="Net"
            active={sortBy === 'net'}
            onPress={() => setSortBy('net')}
          />
          <SortButton
            label="A-Z"
            active={sortBy === 'name'}
            onPress={() => setSortBy('name')}
          />
        </View>
      </View>

      <Text style={styles.legend}>
        Net taxable gal = miles ÷ vehicle MPG - gallons purchased. Positive = owed,
        negative = credit.
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <FlatList
        // In landscape, render two jurisdictions per row so more fit on screen
        // for dash-mount reading. numColumns changes require a fresh key so
        // FlatList re-lays out its cells.
        key={isLandscape ? 'ifta-2col' : 'ifta-1col'}
        numColumns={isLandscape ? 2 : 1}
        columnWrapperStyle={isLandscape ? styles.gridRow : undefined}
        data={sorted}
        keyExtractor={(item) => item.code}
        renderItem={({ item }) => (
          <View style={isLandscape ? styles.gridItem : undefined}>
            <IftaStateRow
              code={item.code}
              miles={item.miles}
              taxableGallons={item.taxableGallons}
              taxPaidGallons={item.taxPaidGallons}
              netTaxableGallons={item.netTaxableGallons}
              computable={item.computable}
              max={max}
            />
          </View>
        )}
        ListHeaderComponent={header}
        ListEmptyComponent={
          <EmptyState
            title="No miles yet"
            message="Record a trip or add a manual entry to see your state-by-state IFTA totals here."
          />
        }
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      />
      <ExportOptionsSheet
        visible={exportSheetVisible}
        periodLabel={exportSheetPeriod}
        onSelect={selectExport}
        onClose={closeExportSheet}
      />
      <EmailReportDialog
        visible={emailDialogVisible}
        periodLabel={emailDialogPeriod}
        loading={isExporting}
        onCancel={closeEmailDialog}
        onSend={sendEmail}
      />
    </SafeAreaView>
  );
}

function SortButton({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.sortBtn,
        active && styles.sortBtnActive,
        { opacity: pressed ? 0.85 : 1 },
      ]}
    >
      <Text style={[styles.sortText, active && styles.sortTextActive]}>
        {label}
      </Text>
    </Pressable>
  );
}

function ExportButton({
  onPress,
  loading,
}: {
  onPress: () => void;
  loading: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={loading}
      hitSlop={8}
      style={({ pressed }) => [
        styles.exportBtn,
        { opacity: loading ? 0.6 : pressed ? 0.85 : 1 },
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={colors.primary} />
      ) : (
        <MaterialIcons name="ios-share" size={18} color={colors.primary} />
      )}
      <Text style={styles.exportText}>Export</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  flex1: {
    flex: 1,
  },
  totalCard: {
    marginTop: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.lg,
  },
  totalLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  totalValue: {
    ...typography.display,
    fontSize: 36,
    color: colors.text,
    marginTop: 2,
  },
  totalSub: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 4,
  },
  totalIcon: {
    width: 56,
    height: 56,
    borderRadius: radius.lg,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  metricsRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  chartsRow: {
    flexDirection: 'row',
    gap: spacing.lg,
    alignItems: 'flex-start',
  },
  chartCol: {
    flex: 1,
  },
  gridRow: {
    gap: spacing.lg,
  },
  gridItem: {
    flex: 1,
  },
  defCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.md,
    padding: spacing.md,
  },
  defIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  defLabel: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  defSub: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  defValue: {
    ...typography.h2,
    color: colors.text,
  },
  metricCard: {
    flex: 1,
    padding: spacing.md,
    gap: 2,
  },
  metricIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  metricValue: {
    ...typography.h1,
    color: colors.text,
  },
  metricLabel: {
    ...typography.small,
    color: colors.text,
    fontWeight: '600',
  },
  metricSub: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  sortRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.lg,
    marginBottom: spacing.xs,
  },
  sectionTitle: {
    ...typography.h3,
    color: colors.text,
  },
  sectionSpacer: {
    marginTop: spacing.lg,
  },
  sortButtons: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  sortBtn: {
    paddingHorizontal: spacing.md,
    height: 32,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sortBtnActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  sortText: {
    ...typography.caption,
    color: colors.textSubtle,
    fontWeight: '700',
  },
  sortTextActive: {
    color: colors.onPrimary,
  },
  legend: {
    ...typography.caption,
    color: colors.textMuted,
    marginBottom: spacing.sm,
    lineHeight: 18,
  },
  exportBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.md,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.primarySoft,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  exportText: {
    ...typography.small,
    color: colors.primary,
    fontWeight: '700',
  },
});
