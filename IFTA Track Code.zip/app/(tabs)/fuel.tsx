// Powered by OnSpace.AI

import React, { useCallback, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { useExport } from '@/hooks/useExport';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { SegmentedControl } from '@/components/ui/SegmentedControl';
import { FuelStateRow } from '@/components/feature/FuelStateRow';
import { ExportOptionsSheet } from '@/components/feature/ExportOptionsSheet';
import { EmptyState } from '@/components/feature/EmptyState';
import { ScreenHeader } from '@/components/layout/ScreenHeader';
import {
  aggregateStateFuel,
  filterFuel,
  isInPeriod,
  PERIOD_OPTIONS,
  Period,
  periodLabel,
} from '@/services/aggregation';
import { FuelPurchase } from '@/services/types';
import { stateLabel } from '@/constants/states';
import {
  formatCurrency,
  formatDate,
  formatGallons,
  formatMiles,
  formatPricePerGallon,
} from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function FuelScreen() {
  const { fuel, deleteFuelPurchase, def, deleteDefPurchase } = useTrips();
  const {
    isExporting,
    promptFuelExport,
    fuelExportSheetVisible,
    fuelExportSheetPeriod,
    selectFuelExport,
    closeFuelExportSheet,
  } = useExport();
  const { showAlert } = useAlert();
  const router = useRouter();
  const [period, setPeriod] = useState<Period>('quarter');

  const filtered = useMemo(
    () => filterFuel(fuel, period),
    [fuel, period],
  );
  const byState = useMemo(() => aggregateStateFuel(filtered), [filtered]);
  const totalGal = useMemo(
    () => filtered.reduce((s, f) => s + f.gallons, 0),
    [filtered],
  );
  const totalCost = useMemo(
    () => filtered.reduce((s, f) => s + f.amount, 0),
    [filtered],
  );

  const filteredDef = useMemo(
    () => def.filter((d) => isInPeriod(d.date, period)),
    [def, period],
  );
  const defTotalGal = useMemo(
    () => filteredDef.reduce((s, d) => s + d.gallons, 0),
    [filteredDef],
  );
  const defTotalCost = useMemo(
    () => filteredDef.reduce((s, d) => s + d.gallons * d.pricePerGallon, 0),
    [filteredDef],
  );

  const handleExport = useCallback(() => {
    const rows = [...filtered]
      .sort((a, b) => a.date - b.date)
      .map((f) => ({
        date: f.date,
        code: f.stateCode,
        gallons: f.gallons,
        amount: f.amount,
        odometer: f.odometer,
        vendor: f.vendor,
      }));
    const defRows = [...filteredDef]
      .sort((a, b) => a.date - b.date)
      .map((d) => ({
        date: d.date,
        gallons: d.gallons,
        pricePerGallon: d.pricePerGallon,
      }));
    promptFuelExport(rows, {
      periodName:
        PERIOD_OPTIONS.find((o) => o.key === period)?.label ?? 'Period',
      periodLabel: periodLabel(period),
      totalGallons: totalGal,
      totalCost,
      purchaseCount: filtered.length,
      generatedAt: Date.now(),
      defRows,
      defTotalGallons: defTotalGal,
      defTotalCost,
    });
  }, [
    promptFuelExport,
    filtered,
    filteredDef,
    period,
    totalGal,
    totalCost,
    defTotalGal,
    defTotalCost,
  ]);

  const confirmDelete = useCallback(
    (id: string) => {
      showAlert('Delete purchase?', 'This fuel entry will be removed.', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => deleteFuelPurchase(id),
        },
      ]);
    },
    [deleteFuelPurchase, showAlert],
  );

  const confirmDeleteDef = useCallback(
    (id: string) => {
      showAlert('Delete DEF entry?', 'This DEF purchase will be removed.', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => deleteDefPurchase(id),
        },
      ]);
    },
    [deleteDefPurchase, showAlert],
  );

  const renderItem = useCallback(
    ({ item }: { item: FuelPurchase }) => (
      <Pressable
        onPress={() => router.push(`/fuel/${item.id}`)}
        style={({ pressed }) => [{ opacity: pressed ? 0.85 : 1 }]}
        accessibilityLabel={`Edit ${stateLabel(item.stateCode)} fuel purchase`}
      >
        <Card style={styles.purchaseCard}>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{item.stateCode}</Text>
          </View>
          <View style={styles.purchaseBody}>
            <Text style={styles.purchaseState} numberOfLines={1}>
              {stateLabel(item.stateCode)}
            </Text>
            <Text style={styles.purchaseMeta} numberOfLines={1}>
              {formatDate(item.date)}
              {item.vendor ? ` \u00b7 ${item.vendor}` : ''}
              {item.odometer ? ` \u00b7 odo ${formatMiles(item.odometer)}` : ''}
              {item.fullTank === false ? ' \u00b7 Partial fill' : ''}
            </Text>
          </View>
          <View style={styles.purchaseRight}>
            <Text style={styles.purchaseAmount}>
              {formatCurrency(item.amount)}
            </Text>
            <Text style={styles.purchaseGal}>
              {formatGallons(item.gallons)} gal
            </Text>
          </View>
          <Pressable
            onPress={() => confirmDelete(item.id)}
            hitSlop={8}
            style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
          >
            <MaterialIcons
              name="delete-outline"
              size={22}
              color={colors.textMuted}
            />
          </Pressable>
        </Card>
      </Pressable>
    ),
    [confirmDelete, router],
  );

  const header = (
    <View>
      <ScreenHeader
        title="Fuel Purchases"
        subtitle="Gallons & cost by jurisdiction"
        right={
          <View style={styles.headerActions}>
            <ExportButton onPress={handleExport} loading={isExporting} />
            <Button
              label="Add"
              icon="add"
              variant="secondary"
              onPress={() => router.push('/add-fuel')}
              style={styles.addBtn}
            />
          </View>
        }
      />

      <SegmentedControl
        options={PERIOD_OPTIONS}
        value={period}
        onChange={setPeriod}
      />

      <Card style={styles.totalCard}>
        <View>
          <Text style={styles.totalLabel}>{periodLabel(period)}</Text>
          <Text style={styles.totalValue}>{formatCurrency(totalCost)}</Text>
          <Text style={styles.totalSub}>
            {formatGallons(totalGal)} gal · {filtered.length}{' '}
            {filtered.length === 1 ? 'purchase' : 'purchases'}
          </Text>
        </View>
        <View style={styles.totalIcon}>
          <MaterialIcons
            name="local-gas-station"
            size={28}
            color={colors.primary}
          />
        </View>
      </Card>

      {byState.length > 0 ? (
        <View>
          <Text style={styles.sectionTitle}>By state</Text>
          <Card>
            {byState.map((s) => (
              <FuelStateRow
                key={s.code}
                code={s.code}
                gallons={s.gallons}
                amount={s.amount}
              />
            ))}
          </Card>
        </View>
      ) : null}

      <View style={styles.defHeaderRow}>
        <Text style={styles.sectionTitle}>Diesel Exhaust Fluid (DEF)</Text>
        <Button
          label="Add DEF"
          icon="add"
          variant="secondary"
          onPress={() => router.push('/add-def')}
          style={styles.addBtn}
        />
      </View>
      {filteredDef.length > 0 ? (
        <Card>
          <View style={styles.defTotalRow}>
            <View style={styles.defTotalIcon}>
              <MaterialIcons name="opacity" size={20} color={colors.primary} />
            </View>
            <Text style={styles.defTotalLabel}>
              {formatGallons(defTotalGal)} gal · {filteredDef.length}{' '}
              {filteredDef.length === 1 ? 'purchase' : 'purchases'}
            </Text>
            <Text style={styles.defTotalValue}>
              {formatCurrency(defTotalCost)}
            </Text>
          </View>
          {filteredDef.map((d) => (
            <Pressable
              key={d.id}
              onPress={() => router.push(`/def/${d.id}`)}
              style={({ pressed }) => [
                styles.defRow,
                { opacity: pressed ? 0.85 : 1 },
              ]}
              accessibilityLabel="Edit DEF entry"
            >
              <View style={styles.defBody}>
                <Text style={styles.defRowDate}>{formatDate(d.date)}</Text>
                <Text style={styles.defRowMeta}>
                  {formatGallons(d.gallons)} gal ·{' '}
                  {formatPricePerGallon(d.pricePerGallon)}/gal
                </Text>
              </View>
              <Text style={styles.defRowTotal}>
                {formatCurrency(d.gallons * d.pricePerGallon)}
              </Text>
              <Pressable
                onPress={() => confirmDeleteDef(d.id)}
                hitSlop={8}
                style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
                accessibilityLabel="Delete DEF entry"
              >
                <MaterialIcons
                  name="delete-outline"
                  size={22}
                  color={colors.textMuted}
                />
              </Pressable>
            </Pressable>
          ))}
        </Card>
      ) : (
        <Card>
          <Text style={styles.defEmpty}>
            No DEF logged for this period. Tap “Add DEF” to record a purchase.
          </Text>
        </Card>
      )}

      <Text style={styles.sectionTitle}>Purchases</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        ListHeaderComponent={header}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        ListEmptyComponent={
          <EmptyState
            title="No fuel logged"
            message="Add a fuel purchase to track gallons and cost per state for your IFTA filing."
          />
        }
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      />
      <ExportOptionsSheet
        visible={fuelExportSheetVisible}
        periodLabel={fuelExportSheetPeriod}
        choices={['email', 'pdf', 'csv', 'text']}
        onSelect={selectFuelExport}
        onClose={closeFuelExportSheet}
      />
    </SafeAreaView>
  );
}

function ExportButton({
  onPress,
  loading,
}: {
  onPress: () => void;
  loading: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={loading}
      hitSlop={8}
      accessibilityLabel="Export fuel report"
      style={({ pressed }) => [
        styles.exportBtn,
        { opacity: loading ? 0.6 : pressed ? 0.85 : 1 },
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={colors.primary} />
      ) : (
        <MaterialIcons name="ios-share" size={20} color={colors.primary} />
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  addBtn: {
    minHeight: 40,
    paddingHorizontal: spacing.md,
  },
  exportBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.primarySoft,
    borderWidth: 1,
    borderColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  totalCard: {
    marginTop: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.lg,
  },
  totalLabel: {
    ...typography.small,
    color: colors.textSubtle,
  },
  totalValue: {
    ...typography.display,
    fontSize: 36,
    color: colors.text,
    marginTop: 2,
  },
  totalSub: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 4,
  },
  totalIcon: {
    width: 56,
    height: 56,
    borderRadius: radius.lg,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionTitle: {
    ...typography.h3,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.xs,
  },
  defHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  defTotalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingBottom: spacing.sm,
    marginBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  defTotalIcon: {
    width: 36,
    height: 36,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  defTotalLabel: {
    flex: 1,
    ...typography.small,
    color: colors.textSubtle,
  },
  defTotalValue: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  defRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm,
  },
  defBody: {
    flex: 1,
  },
  defRowDate: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  defRowMeta: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  defRowTotal: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  defEmpty: {
    ...typography.small,
    color: colors.textSubtle,
    textAlign: 'center',
    paddingVertical: spacing.sm,
  },
  purchaseCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  badge: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '800',
  },
  purchaseBody: {
    flex: 1,
  },
  purchaseState: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  purchaseMeta: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  purchaseRight: {
    alignItems: 'flex-end',
  },
  purchaseAmount: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  purchaseGal: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 2,
  },
});
