// Powered by OnSpace.AI

import React, { useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { Button } from '@/components/ui/Button';
import { DatePickerField } from '@/components/ui/DatePickerField';
import { US_STATES, stateLabel } from '@/constants/states';
import { StateMiles } from '@/services/types';
import { colors, radius, spacing, typography } from '@/constants/theme';

type Row = { code: string; miles: string };

export default function AddTripScreen() {
  const router = useRouter();
  const { addManualTrip } = useTrips();
  const { showAlert } = useAlert();
  const [query, setQuery] = useState('');
  const [rows, setRows] = useState<Row[]>([]);
  const [tripDate, setTripDate] = useState<number>(Date.now());

  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    return US_STATES.filter(
      (s) =>
        !rows.find((r) => r.code === s.code) &&
        (q === '' ||
          s.name.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q)),
    ).slice(0, 6);
  }, [query, rows]);

  const total = useMemo(
    () => rows.reduce((s, r) => s + (parseFloat(r.miles) || 0), 0),
    [rows],
  );

  const addRow = (code: string) => {
    setRows((prev) => [{ code, miles: '' }, ...prev]);
    setQuery('');
  };

  const updateMiles = (code: string, value: string) => {
    setRows((prev) =>
      prev.map((r) =>
        r.code === code ? { ...r, miles: value.replace(/[^0-9.]/g, '') } : r,
      ),
    );
  };

  const removeRow = (code: string) => {
    setRows((prev) => prev.filter((r) => r.code !== code));
  };

  const save = () => {
    const stateMiles: StateMiles = {};
    rows.forEach((r) => {
      const m = parseFloat(r.miles);
      if (m > 0) stateMiles[r.code] = m;
    });
    if (Object.keys(stateMiles).length === 0) {
      showAlert('Add mileage', 'Enter miles for at least one state.');
      return;
    }
    addManualTrip(stateMiles, tripDate);
    router.back();
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <DatePickerField
          label="Trip date"
          value={tripDate}
          onChange={setTripDate}
        />

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Find a state
        </Text>
        <View style={styles.searchBox}>
          <MaterialIcons name="search" size={20} color={colors.textMuted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search state name or code"
            placeholderTextColor={colors.textMuted}
            style={styles.input}
            autoCapitalize="characters"
            accessibilityLabel="Search state"
          />
        </View>

        {suggestions.length > 0 ? (
          <View style={styles.chips}>
            {suggestions.map((s) => (
              <Pressable
                key={s.code}
                onPress={() => addRow(s.code)}
                style={({ pressed }) => [
                  styles.chip,
                  { opacity: pressed ? 0.85 : 1 },
                ]}
              >
                <Text style={styles.chipCode}>{s.code}</Text>
                <Text style={styles.chipName}>{s.name}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Mileage entries
        </Text>
        {rows.length === 0 ? (
          <Text style={styles.empty}>
            Add states above, then enter the miles driven in each.
          </Text>
        ) : (
          rows.map((r) => (
            <View key={r.code} style={styles.row}>
              <View style={styles.rowBadge}>
                <Text style={styles.rowBadgeText}>{r.code}</Text>
              </View>
              <Text style={styles.rowName} numberOfLines={1}>
                {stateLabel(r.code)}
              </Text>
              <TextInput
                value={r.miles}
                onChangeText={(v) => updateMiles(r.code, v)}
                placeholder="0"
                placeholderTextColor={colors.textMuted}
                keyboardType="decimal-pad"
                style={styles.milesInput}
                accessibilityLabel={`Miles for ${stateLabel(r.code)}`}
              />
              <Pressable onPress={() => removeRow(r.code)} hitSlop={8}>
                <MaterialIcons name="close" size={20} color={colors.textMuted} />
              </Pressable>
            </View>
          ))
        )}

        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalValue}>{total.toFixed(1)} mi</Text>
        </View>

        <Button label="Save Entry" icon="check" onPress={save} large />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  label: {
    ...typography.small,
    color: colors.textSubtle,
    marginBottom: spacing.sm,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  input: {
    flex: 1,
    ...typography.body,
    color: colors.text,
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
  },
  chipCode: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '800',
  },
  chipName: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  empty: {
    ...typography.body,
    color: colors.textMuted,
    paddingVertical: spacing.md,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.sm + 2,
    marginBottom: spacing.sm,
  },
  rowBadge: {
    width: 40,
    height: 40,
    borderRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowBadgeText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '800',
  },
  rowName: {
    flex: 1,
    ...typography.body,
    color: colors.text,
  },
  milesInput: {
    width: 80,
    height: 40,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceHigh,
    color: colors.text,
    textAlign: 'right',
    paddingHorizontal: spacing.sm,
    ...typography.bodyStrong,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.lg,
  },
  totalLabel: {
    ...typography.h3,
    color: colors.text,
  },
  totalValue: {
    ...typography.h2,
    color: colors.primary,
  },
});
