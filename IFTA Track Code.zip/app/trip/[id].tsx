// Powered by OnSpace.AI

import React, { useCallback, useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StateRow } from '@/components/feature/StateRow';
import { StateMiles } from '@/services/types';
import { US_STATES, stateLabel } from '@/constants/states';
import {
  formatDate,
  formatDuration,
  formatMiles,
  formatTime,
} from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function TripDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { trips, deleteTrip, updateTrip } = useTrips();
  const router = useRouter();
  const { showAlert } = useAlert();

  const trip = trips.find((t) => t.id === id);

  const breakdown = useMemo(() => {
    if (!trip) return [];
    return Object.entries(trip.stateMiles)
      .map(([code, miles]) => ({ code, miles }))
      .sort((a, b) => b.miles - a.miles);
  }, [trip]);
  const max = breakdown[0]?.miles || 1;

  // --- Editing recorded miles -------------------------------------------
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Record<string, string>>({});
  // Optional odometer target used to scale every state proportionally.
  const [odometer, setOdometer] = useState('');
  // Ordered list of state rows while editing: existing states first (highest
  // miles), then any the driver adds. Held in state so rows do not reshuffle as
  // the driver types.
  const [editOrder, setEditOrder] = useState<string[]>([]);
  const [statePickerOpen, setStatePickerOpen] = useState(false);

  // Live total while editing so the driver sees the sum update as they type.
  const draftTotal = useMemo(
    () =>
      Object.values(draft).reduce((sum, v) => sum + (parseFloat(v) || 0), 0),
    [draft],
  );

  const startEdit = useCallback(() => {
    const next: Record<string, string> = {};
    for (const b of breakdown) next[b.code] = b.miles.toFixed(1);
    setDraft(next);
    setEditOrder(breakdown.map((b) => b.code));
    setStatePickerOpen(false);
    setOdometer('');
    setEditing(true);
  }, [breakdown]);

  const cancelEdit = useCallback(() => {
    setEditing(false);
    setDraft({});
    setEditOrder([]);
    setStatePickerOpen(false);
    setOdometer('');
  }, []);

  const changeDraft = useCallback((code: string, text: string) => {
    const cleaned = text.replace(/[^0-9.]/g, '');
    setDraft((prev) => ({ ...prev, [code]: cleaned }));
  }, []);

  const changeOdometer = useCallback((text: string) => {
    setOdometer(text.replace(/[^0-9.]/g, ''));
  }, []);

  // Add a jurisdiction GPS did not record (e.g. a state briefly passed through)
  // so every state driven can be logged, then edited by miles like the rest.
  const addState = useCallback((code: string) => {
    setDraft((prev) => (code in prev ? prev : { ...prev, [code]: '' }));
    setEditOrder((prev) => (prev.includes(code) ? prev : [...prev, code]));
    setStatePickerOpen(false);
  }, []);

  // States not already in the draft, offered in the "Add a state" picker.
  const availableStates = useMemo(
    () => US_STATES.filter((s) => !(s.code in draft)),
    [draft],
  );

  // Scale every state's draft miles proportionally so the sum equals the
  // entered odometer distance. Any rounding remainder is absorbed by the
  // largest state so the new total matches exactly. Values stay editable so
  // the driver can review and tweak before saving.
  const applyOdometer = useCallback(() => {
    const target = parseFloat(odometer);
    if (isNaN(target) || target <= 0) {
      showAlert(
        'Enter a distance',
        'Type the odometer total distance for this trip before matching.',
      );
      return;
    }
    const codes = Object.keys(draft);
    const current = codes.reduce(
      (sum, c) => sum + (parseFloat(draft[c]) || 0),
      0,
    );
    if (current <= 0) {
      showAlert(
        'Add miles first',
        'Enter miles in at least one state before matching the odometer total.',
      );
      return;
    }
    const factor = target / current;
    const rounded: Record<string, number> = {};
    let running = 0;
    for (const c of codes) {
      const r = Math.round((parseFloat(draft[c]) || 0) * factor * 10) / 10;
      rounded[c] = r;
      running += r;
    }
    // Absorb any rounding remainder into the largest state for an exact total.
    const diff = Math.round((target - running) * 10) / 10;
    if (diff !== 0) {
      const largest = codes.reduce(
        (a, b) => (rounded[b] > rounded[a] ? b : a),
        codes[0],
      );
      rounded[largest] = Math.max(
        0,
        Math.round((rounded[largest] + diff) * 10) / 10,
      );
    }
    const scaled: Record<string, string> = {};
    for (const c of codes) scaled[c] = rounded[c].toFixed(1);
    setDraft(scaled);
  }, [odometer, draft, showAlert]);

  const saveEdit = useCallback(() => {
    if (!trip) return;
    const next: StateMiles = {};
    for (const [code, v] of Object.entries(draft)) {
      const num = parseFloat(v);
      if (!isNaN(num) && num > 0) next[code] = Math.round(num * 10) / 10;
    }
    if (Object.keys(next).length === 0) {
      showAlert(
        'Enter miles',
        'A trip needs miles in at least one state. Add a value before saving.',
      );
      return;
    }
    updateTrip(trip.id, next);
    setEditing(false);
    setDraft({});
    setOdometer('');
  }, [trip, draft, updateTrip, showAlert]);

  const handleDelete = useCallback(() => {
    if (!trip) return;
    showAlert('Delete trip?', 'This record will be permanently removed.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          deleteTrip(trip.id);
          router.back();
        },
      },
    ]);
  }, [trip, showAlert, deleteTrip, router]);

  if (!trip) {
    return (
      <View style={styles.notFound}>
        <MaterialIcons name="error-outline" size={32} color={colors.textMuted} />
        <Text style={styles.notFoundText}>Trip not found.</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.summaryCard}>
          <Text style={styles.miles}>
            {formatMiles(editing ? draftTotal : trip.miles)}
          </Text>
          <Text style={styles.milesUnit}>total miles</Text>
          <View style={styles.tagRow}>
            <View style={styles.tag}>
              <MaterialIcons
                name={
                  trip.manual ? 'edit' : trip.auto ? 'auto-mode' : 'navigation'
                }
                size={14}
                color={colors.primary}
              />
              <Text style={styles.tagText}>
                {trip.manual
                  ? 'Manual'
                  : trip.auto
                    ? 'Auto-recorded'
                    : 'Manual start'}
              </Text>
            </View>
            {trip.edited ? (
              <View style={[styles.tag, styles.editedTag]}>
                <MaterialIcons
                  name="edit-note"
                  size={14}
                  color={colors.success}
                />
                <Text style={[styles.tagText, styles.editedTagText]}>
                  Adjusted
                </Text>
              </View>
            ) : null}
          </View>
        </Card>

        <View style={styles.metaGrid}>
          <MetaItem icon="event" label="Date" value={formatDate(trip.startedAt)} />
          {!trip.manual ? (
            <MetaItem
              icon="schedule"
              label="Time"
              value={`${formatTime(trip.startedAt)} - ${formatTime(trip.endedAt)}`}
            />
          ) : null}
          {!trip.manual ? (
            <MetaItem
              icon="timer"
              label="Duration"
              value={formatDuration(trip.endedAt - trip.startedAt)}
            />
          ) : null}
          <MetaItem icon="map" label="States" value={String(breakdown.length)} />
        </View>

        <View style={styles.sectionHead}>
          <Text style={styles.sectionTitle}>Miles by state</Text>
          {!editing ? (
            <Pressable
              onPress={startEdit}
              hitSlop={8}
              style={({ pressed }) => [
                styles.editBtn,
                { opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <MaterialIcons name="edit" size={16} color={colors.primary} />
              <Text style={styles.editBtnText}>Edit</Text>
            </Pressable>
          ) : null}
        </View>

        {editing ? (
          <Text style={styles.editHint}>
            Adjust the miles for each state, or add a state GPS missed, to match
            your odometer or logbook. The total updates automatically.
          </Text>
        ) : null}

        {editing ? (
          <Card style={styles.odoCard}>
            <View style={styles.odoHead}>
              <MaterialIcons name="speed" size={18} color={colors.primary} />
              <Text style={styles.odoTitle}>Match odometer total</Text>
            </View>
            <Text style={styles.odoHelp}>
              Enter the trip distance from your odometer and every state scales
              proportionally to match it. Review the result below before saving.
            </Text>
            <View style={styles.odoRow}>
              <View style={styles.odoInputWrap}>
                <TextInput
                  value={odometer}
                  onChangeText={changeOdometer}
                  keyboardType="decimal-pad"
                  placeholder={draftTotal.toFixed(1)}
                  placeholderTextColor={colors.textMuted}
                  style={styles.odoInput}
                  accessibilityLabel="Odometer total distance"
                />
                <Text style={styles.odoUnit}>mi</Text>
              </View>
              <Button
                label="Match"
                icon="sync"
                variant="secondary"
                onPress={applyOdometer}
                style={styles.odoBtn}
              />
            </View>
          </Card>
        ) : null}

        <Card>
          {editing
            ? editOrder.map((code) => (
                <StateRow
                  key={code}
                  code={code}
                  miles={parseFloat(draft[code]) || 0}
                  max={1}
                  editable
                  value={draft[code]}
                  onChangeValue={(text) => changeDraft(code, text)}
                />
              ))
            : breakdown.map((b) => (
                <StateRow key={b.code} code={b.code} miles={b.miles} max={max} />
              ))}
        </Card>

        {!editing && trip.crossings && trip.crossings.length > 0 ? (
          <>
            <Text style={styles.sectionTitle}>Border crossings</Text>
            <Card>
              {trip.crossings.map((c, idx) => (
                <View
                  key={`${c.stateCode}-${c.at}-${idx}`}
                  style={styles.crossRow}
                >
                  <View style={styles.crossIcon}>
                    <MaterialIcons
                      name="place"
                      size={16}
                      color={colors.primary}
                    />
                  </View>
                  <Text style={styles.crossState}>
                    {stateLabel(c.stateCode)}
                  </Text>
                  <View style={styles.crossMeta}>
                    <Text style={styles.crossTime}>{formatTime(c.at)}</Text>
                    <Text style={styles.crossMiles}>
                      {`${formatMiles(c.miles)} mi`}
                    </Text>
                  </View>
                </View>
              ))}
            </Card>
          </>
        ) : null}

        {editing ? (
          <View style={styles.addStateWrap}>
            <Pressable
              onPress={() => setStatePickerOpen((o) => !o)}
              hitSlop={6}
              style={({ pressed }) => [
                styles.addStateBtn,
                { opacity: pressed ? 0.8 : 1 },
              ]}
            >
              <MaterialIcons
                name={statePickerOpen ? 'expand-less' : 'add'}
                size={18}
                color={colors.primary}
              />
              <Text style={styles.addStateText}>
                {statePickerOpen ? 'Close state list' : 'Add a state'}
              </Text>
            </Pressable>
            {statePickerOpen ? (
              <View style={styles.stateGrid}>
                {availableStates.map((s) => (
                  <Pressable
                    key={s.code}
                    onPress={() => addState(s.code)}
                    style={({ pressed }) => [
                      styles.stateChip,
                      { opacity: pressed ? 0.7 : 1 },
                    ]}
                    accessibilityLabel={`Add ${s.name}`}
                  >
                    <Text style={styles.stateChipText}>{s.code}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
          </View>
        ) : null}

        {editing ? (
          <View style={styles.editActions}>
            <Button
              label="Cancel"
              variant="secondary"
              onPress={cancelEdit}
              style={styles.actionBtn}
            />
            <Button
              label="Save Miles"
              icon="check"
              onPress={saveEdit}
              style={styles.actionBtn}
            />
          </View>
        ) : (
          <Button
            label="Delete Trip"
            icon="delete-outline"
            variant="danger"
            onPress={handleDelete}
            style={styles.deleteBtn}
          />
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function MetaItem({
  icon,
  label,
  value,
}: {
  icon: keyof typeof MaterialIcons.glyphMap;
  label: string;
  value: string;
}) {
  return (
    <Card style={styles.metaItem}>
      <MaterialIcons name={icon} size={18} color={colors.primary} />
      <Text style={styles.metaLabel}>{label}</Text>
      <Text style={styles.metaValue}>{value}</Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
    gap: spacing.md,
  },
  notFound: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.background,
  },
  notFoundText: {
    ...typography.body,
    color: colors.textMuted,
  },
  summaryCard: {
    alignItems: 'center',
    padding: spacing.lg,
  },
  miles: {
    ...typography.display,
    color: colors.text,
  },
  milesUnit: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  tagRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  tag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.primarySoft,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
  },
  tagText: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '700',
  },
  editedTag: {
    backgroundColor: colors.successSoft,
  },
  editedTagText: {
    color: colors.success,
  },
  metaGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  metaItem: {
    flexGrow: 1,
    flexBasis: '45%',
    gap: 4,
  },
  metaLabel: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 4,
  },
  metaValue: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  sectionHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.sm,
  },
  sectionTitle: {
    ...typography.h3,
    color: colors.text,
  },
  editBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.primarySoft,
  },
  editBtnText: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '700',
  },
  editHint: {
    ...typography.small,
    color: colors.textSubtle,
    lineHeight: 20,
  },
  odoCard: {
    gap: spacing.sm,
  },
  odoHead: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  odoTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  odoHelp: {
    ...typography.small,
    color: colors.textSubtle,
    lineHeight: 20,
  },
  odoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.xs,
  },
  odoInputWrap: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
  },
  odoInput: {
    flex: 1,
    ...typography.bodyStrong,
    color: colors.text,
    paddingVertical: 10,
  },
  odoUnit: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  odoBtn: {
    paddingHorizontal: spacing.lg,
  },
  addStateWrap: {
    gap: spacing.sm,
  },
  addStateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: 44,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceHigh,
  },
  addStateText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '700',
  },
  stateGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  stateChip: {
    minWidth: 46,
    paddingHorizontal: spacing.sm,
    paddingVertical: 8,
    borderRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stateChipText: {
    ...typography.small,
    color: colors.primary,
    fontWeight: '800',
  },
  crossRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  crossIcon: {
    width: 32,
    height: 32,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  crossState: {
    ...typography.bodyStrong,
    color: colors.text,
    flex: 1,
  },
  crossMeta: {
    alignItems: 'flex-end',
  },
  crossTime: {
    ...typography.small,
    color: colors.text,
    fontWeight: '700',
  },
  crossMiles: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  editActions: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  actionBtn: {
    flex: 1,
  },
  deleteBtn: {
    marginTop: spacing.md,
  },
});
