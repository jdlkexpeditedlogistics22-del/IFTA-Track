// Powered by OnSpace.AI

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { useDetectedState } from '@/hooks/useDetectedState';
import { Button } from '@/components/ui/Button';
import { DatePickerField } from '@/components/ui/DatePickerField';
import { ToggleField } from '@/components/ui/ToggleField';
import { US_STATES, stateLabel } from '@/constants/states';
import { formatPricePerGallon } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function AddFuelScreen() {
  const router = useRouter();
  const { addFuelPurchase, recentVendors } = useTrips();
  const { showAlert } = useAlert();
  const { detecting, detectedCode, redetect } = useDetectedState();

  const [query, setQuery] = useState('');
  const [stateCode, setStateCode] = useState<string | null>(null);
  const [autoDetected, setAutoDetected] = useState(false);
  const [userTouched, setUserTouched] = useState(false);
  const [purchaseDate, setPurchaseDate] = useState<number>(Date.now());
  const [gallons, setGallons] = useState('');
  const [amount, setAmount] = useState('');
  const [odometer, setOdometer] = useState('');
  const [vendor, setVendor] = useState('');
  const [fullTank, setFullTank] = useState(false);

  // Auto-fill the purchase state from GPS once, unless the user already chose.
  useEffect(() => {
    if (!userTouched && !stateCode && detectedCode) {
      setStateCode(detectedCode);
      setAutoDetected(true);
    }
  }, [detectedCode, userTouched, stateCode]);

  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    return US_STATES.filter(
      (s) =>
        q === '' ||
        s.name.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q),
    ).slice(0, 6);
  }, [query]);

  // Recent vendor/station names for quick reuse, excluding whatever is already
  // in the field so we never show a chip identical to the current value.
  const vendorSuggestions = useMemo(() => {
    const current = vendor.trim().toLowerCase();
    return recentVendors.filter((v) => v.trim().toLowerCase() !== current);
  }, [recentVendors, vendor]);

  const gallonsNum = parseFloat(gallons) || 0;
  const amountNum = parseFloat(amount) || 0;
  const pricePerGal = gallonsNum > 0 ? amountNum / gallonsNum : 0;

  const sanitize = (v: string) => v.replace(/[^0-9.]/g, '');

  const selectState = useCallback((code: string) => {
    setStateCode(code);
    setAutoDetected(false);
    setUserTouched(true);
    setQuery('');
  }, []);

  const clearState = useCallback(() => {
    setStateCode(null);
    setAutoDetected(false);
    setUserTouched(true);
  }, []);

  const handleUseLocation = useCallback(async () => {
    const code = await redetect();
    if (code) {
      setStateCode(code);
      setAutoDetected(true);
      setUserTouched(false);
      setQuery('');
    } else {
      showAlert(
        'Location unavailable',
        'Could not detect your state from GPS. Search and choose it manually, or allow location access in Settings.',
      );
    }
  }, [redetect, showAlert]);

  const applyRecentVendor = useCallback((name: string) => {
    setVendor(name);
  }, []);

  const save = () => {
    if (!stateCode) {
      showAlert('Select a state', 'Choose the state where you purchased fuel.');
      return;
    }
    if (gallonsNum <= 0) {
      showAlert('Enter gallons', 'Enter how many gallons you purchased.');
      return;
    }
    if (amountNum <= 0) {
      showAlert('Enter amount', 'Enter the total amount you paid.');
      return;
    }
    const odometerNum = parseFloat(odometer) || 0;
    addFuelPurchase({
      stateCode,
      gallons: gallonsNum,
      amount: amountNum,
      date: purchaseDate,
      odometer: odometerNum > 0 ? odometerNum : undefined,
      vendor: vendor.trim() || undefined,
      fullTank,
    });
    router.back();
  };

  // While a GPS fix is resolving (or is about to auto-fill), keep showing the
  // detecting state instead of flashing the manual search view.
  const awaitingAutoFill = !userTouched && detectedCode !== null && !stateCode;

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <DatePickerField
          label="Purchase date"
          value={purchaseDate}
          onChange={setPurchaseDate}
        />

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Purchase state
        </Text>
        {stateCode ? (
          <View style={styles.selected}>
            <View style={styles.selectedBadge}>
              <Text style={styles.selectedBadgeText}>{stateCode}</Text>
            </View>
            <View style={styles.selectedInfo}>
              <Text style={styles.selectedName} numberOfLines={1}>
                {stateLabel(stateCode)}
              </Text>
              {autoDetected ? (
                <View style={styles.gpsRow}>
                  <MaterialIcons
                    name="my-location"
                    size={12}
                    color={colors.success}
                  />
                  <Text style={styles.gpsText}>Auto-detected from GPS</Text>
                </View>
              ) : null}
            </View>
            <Pressable
              onPress={clearState}
              hitSlop={8}
              style={({ pressed }) => [
                styles.changeBtn,
                { opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Text style={styles.changeText}>Change</Text>
            </Pressable>
          </View>
        ) : detecting || awaitingAutoFill ? (
          <View style={styles.detecting}>
            <ActivityIndicator color={colors.primary} />
            <Text style={styles.detectingText}>Detecting your location...</Text>
          </View>
        ) : (
          <>
            <Pressable
              onPress={handleUseLocation}
              style={({ pressed }) => [
                styles.locateBtn,
                { opacity: pressed ? 0.9 : 1 },
              ]}
            >
              <MaterialIcons
                name="my-location"
                size={18}
                color={colors.primary}
              />
              <Text style={styles.locateText}>Use my current location</Text>
            </Pressable>
            <View style={styles.searchBox}>
              <MaterialIcons name="search" size={20} color={colors.textMuted} />
              <TextInput
                value={query}
                onChangeText={setQuery}
                placeholder="Search state name or code"
                placeholderTextColor={colors.textMuted}
                style={styles.input}
                autoCapitalize="characters"
                accessibilityLabel="Search state"
              />
            </View>
            <View style={styles.chips}>
              {suggestions.map((s) => (
                <Pressable
                  key={s.code}
                  onPress={() => selectState(s.code)}
                  style={({ pressed }) => [
                    styles.chip,
                    { opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <Text style={styles.chipCode}>{s.code}</Text>
                  <Text style={styles.chipName}>{s.name}</Text>
                </Pressable>
              ))}
            </View>
          </>
        )}

        <Text style={[styles.label, { marginTop: spacing.lg }]}>Gallons</Text>
        <TextInput
          value={gallons}
          onChangeText={(v) => setGallons(sanitize(v))}
          placeholder="0.0"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="Gallons purchased"
        />

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Total cost ($)
        </Text>
        <TextInput
          value={amount}
          onChangeText={(v) => setAmount(sanitize(v))}
          placeholder="0.00"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="Total amount paid"
        />

        <View style={styles.priceCard}>
          <MaterialIcons name="local-offer" size={18} color={colors.primary} />
          <Text style={styles.priceLabel}>Price per gallon</Text>
          <Text style={styles.priceValue}>
            {pricePerGal > 0 ? formatPricePerGallon(pricePerGal) : '\u2014'}
          </Text>
        </View>

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Odometer (optional)
        </Text>
        <TextInput
          value={odometer}
          onChangeText={(v) => setOdometer(sanitize(v))}
          placeholder="Current mileage"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="Odometer reading"
        />

        <View style={{ marginTop: spacing.lg }}>
          <ToggleField
            icon="local-gas-station"
            label="Filled to full tank"
            description="Only full-tank fills are used to calculate MPG. Turn off for a partial fill — its gallons roll into your next full fill."
            value={fullTank}
            onValueChange={setFullTank}
          />
        </View>

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Vendor / station (optional)
        </Text>
        <TextInput
          value={vendor}
          onChangeText={setVendor}
          placeholder="e.g. Pilot, Loves, TA"
          placeholderTextColor={colors.textMuted}
          style={styles.fieldInput}
          accessibilityLabel="Vendor or station"
        />

        {vendorSuggestions.length > 0 ? (
          <View style={styles.recentWrap}>
            <Text style={styles.recentLabel}>Recent</Text>
            <View style={styles.recentChips}>
              {vendorSuggestions.map((v) => (
                <Pressable
                  key={v}
                  onPress={() => applyRecentVendor(v)}
                  style={({ pressed }) => [
                    styles.recentChip,
                    { opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <MaterialIcons
                    name="history"
                    size={12}
                    color={colors.textSubtle}
                  />
                  <Text style={styles.recentChipText} numberOfLines={1}>
                    {v}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : null}

        <Button
          label="Save Fuel Entry"
          icon="check"
          onPress={save}
          large
          style={{ marginTop: spacing.xl }}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  label: {
    ...typography.small,
    color: colors.textSubtle,
    marginBottom: spacing.sm,
  },
  detecting: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  detectingText: {
    ...typography.body,
    color: colors.textSubtle,
  },
  locateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.md,
    height: 48,
    marginBottom: spacing.md,
  },
  locateText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '700',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  input: {
    flex: 1,
    ...typography.body,
    color: colors.text,
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
  },
  chipCode: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '800',
  },
  chipName: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  selected: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.sm + 2,
  },
  selectedBadge: {
    width: 44,
    height: 44,
    borderRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedBadgeText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '800',
  },
  selectedInfo: {
    flex: 1,
  },
  selectedName: {
    ...typography.body,
    color: colors.text,
  },
  gpsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  gpsText: {
    ...typography.caption,
    color: colors.success,
    fontWeight: '600',
  },
  changeBtn: {
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceHigh,
  },
  changeText: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '700',
  },
  fieldInput: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
    ...typography.bodyStrong,
    color: colors.text,
  },
  priceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.md,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  priceLabel: {
    flex: 1,
    ...typography.small,
    color: colors.text,
    fontWeight: '600',
  },
  priceValue: {
    ...typography.h3,
    color: colors.primary,
  },
  vendorHintRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: spacing.sm,
  },
  vendorHintText: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  suggestChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    marginTop: spacing.sm,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
  },
  suggestText: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '700',
    flexShrink: 1,
  },
  recentWrap: {
    marginTop: spacing.md,
  },
  recentLabel: {
    ...typography.caption,
    color: colors.textMuted,
    marginBottom: spacing.sm,
    fontWeight: '600',
  },
  recentChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  recentChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
  },
  recentChipText: {
    ...typography.caption,
    color: colors.text,
    fontWeight: '600',
    maxWidth: 180,
  },
});
