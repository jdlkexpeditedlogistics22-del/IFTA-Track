// Powered by OnSpace.AI
// Detail/edit screen for a saved Diesel Exhaust Fluid (DEF) purchase. Lets the
// driver correct the date, gallons and price per gallon after saving, so a
// mistyped entry can be fixed in place instead of deleted and re-added. Mirrors
// the fuel edit screen.

import React, { useCallback, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { Button } from '@/components/ui/Button';
import { DatePickerField } from '@/components/ui/DatePickerField';
import { formatCurrency, formatPricePerGallon } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function DefDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { def, updateDefPurchase, deleteDefPurchase } = useTrips();
  const router = useRouter();
  const { showAlert } = useAlert();

  const purchase = def.find((d) => d.id === id);

  const [purchaseDate, setPurchaseDate] = useState<number>(
    purchase?.date ?? Date.now(),
  );
  const [gallons, setGallons] = useState(
    purchase ? String(purchase.gallons) : '',
  );
  const [price, setPrice] = useState(
    purchase ? String(purchase.pricePerGallon) : '',
  );

  const gallonsNum = parseFloat(gallons) || 0;
  const priceNum = parseFloat(price) || 0;
  const total = gallonsNum * priceNum;

  const sanitize = (v: string) => v.replace(/[^0-9.]/g, '');

  const save = useCallback(() => {
    if (!purchase) return;
    if (gallonsNum <= 0) {
      showAlert('Enter gallons', 'Enter how many gallons of DEF you purchased.');
      return;
    }
    if (priceNum <= 0) {
      showAlert('Enter price', 'Enter the price per gallon you paid.');
      return;
    }
    updateDefPurchase(purchase.id, {
      date: purchaseDate,
      gallons: gallonsNum,
      pricePerGallon: priceNum,
    });
    router.back();
  }, [
    purchase,
    gallonsNum,
    priceNum,
    purchaseDate,
    updateDefPurchase,
    router,
    showAlert,
  ]);

  const handleDelete = useCallback(() => {
    if (!purchase) return;
    showAlert('Delete DEF entry?', 'This DEF purchase will be removed.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          deleteDefPurchase(purchase.id);
          router.back();
        },
      },
    ]);
  }, [purchase, showAlert, deleteDefPurchase, router]);

  if (!purchase) {
    return (
      <View style={styles.notFound}>
        <MaterialIcons name="error-outline" size={32} color={colors.textMuted} />
        <Text style={styles.notFoundText}>DEF purchase not found.</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.intro}>
          <View style={styles.introIcon}>
            <MaterialIcons name="opacity" size={22} color={colors.primary} />
          </View>
          <Text style={styles.introText}>
            Diesel Exhaust Fluid is logged separately from diesel fuel and is not
            included in your IFTA fuel-tax gallons.
          </Text>
        </View>

        <DatePickerField
          label="Purchase date"
          value={purchaseDate}
          onChange={setPurchaseDate}
        />

        <Text style={[styles.label, { marginTop: spacing.lg }]}>Gallons</Text>
        <TextInput
          value={gallons}
          onChangeText={(v) => setGallons(sanitize(v))}
          placeholder="0.0"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="DEF gallons purchased"
        />

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Price per gallon ($)
        </Text>
        <TextInput
          value={price}
          onChangeText={(v) => setPrice(sanitize(v))}
          placeholder="0.000"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="DEF price per gallon"
        />

        <View style={styles.priceCard}>
          <MaterialIcons name="receipt-long" size={18} color={colors.primary} />
          <Text style={styles.priceLabel}>Total cost</Text>
          <Text style={styles.priceValue}>
            {total > 0 ? formatCurrency(total) : '\u2014'}
          </Text>
        </View>
        {priceNum > 0 ? (
          <Text style={styles.perGalHint}>
            {formatPricePerGallon(priceNum)} / gal
          </Text>
        ) : null}

        <Button
          label="Save Changes"
          icon="check"
          onPress={save}
          large
          style={{ marginTop: spacing.xl }}
        />
        <Button
          label="Delete Entry"
          icon="delete-outline"
          variant="danger"
          onPress={handleDelete}
          style={{ marginTop: spacing.md }}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  notFound: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.background,
  },
  notFoundText: {
    ...typography.body,
    color: colors.textMuted,
  },
  intro: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  introIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  introText: {
    flex: 1,
    ...typography.caption,
    color: colors.textSubtle,
  },
  label: {
    ...typography.small,
    color: colors.textSubtle,
    marginBottom: spacing.sm,
  },
  fieldInput: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
    ...typography.bodyStrong,
    color: colors.text,
  },
  priceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.lg,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  priceLabel: {
    flex: 1,
    ...typography.small,
    color: colors.text,
    fontWeight: '600',
  },
  priceValue: {
    ...typography.h3,
    color: colors.primary,
  },
  perGalHint: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: spacing.sm,
    textAlign: 'right',
  },
});
