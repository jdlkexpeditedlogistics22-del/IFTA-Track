
// Powered by OnSpace.AI
//
// Edit TODAY's in-progress miles WITHOUT ending the day. Mirrors the recorded-
// trip editor, but writes to the live session via updateCurrentMiles so the
// running odometer is corrected and recording simply continues afterward.

import React, { useCallback, useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StateRow } from '@/components/feature/StateRow';
import { StateMiles } from '@/services/types';
import { US_STATES } from '@/constants/states';
import { formatMiles } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function EditTodayScreen() {
  const { liveStateMiles, updateCurrentMiles } = useTrips();
  const router = useRouter();
  const { showAlert } = useAlert();

  // Snapshot the current live breakdown once, so rows do not reshuffle while
  // the driver types (the live session may keep banking miles in the meantime).
  const initial = useMemo(
    () =>
      Object.entries(liveStateMiles)
        .map(([code, miles]) => ({ code, miles }))
        .sort((a, b) => b.miles - a.miles),
    [liveStateMiles], // Add liveStateMiles to the dependency array
  );

  const [draft, setDraft] = useState<Record<string, string>>(() => {
    const next: Record<string, string> = {};
    for (const b of initial) next[b.code] = b.miles.toFixed(1);
    return next;
  });
  const [editOrder, setEditOrder] = useState<string[]>(
    initial.map((b) => b.code),
  );
  const [odometer, setOdometer] = useState('');
  const [statePickerOpen, setStatePickerOpen] = useState(false);

  const draftTotal = useMemo(
    () =>
      Object.values(draft).reduce((sum, v) => sum + (parseFloat(v) || 0), 0),
    [draft],
  );

  const changeDraft = useCallback((code: string, text: string) => {
    const cleaned = text.replace(/[^0-9.]/g, '');
    setDraft((prev) => ({ ...prev, [code]: cleaned }));
  }, []);

  const changeOdometer = useCallback((text: string) => {
    setOdometer(text.replace(/[^0-9.]/g, ''));
  }, []);

  const addState = useCallback((code: string) => {
    setDraft((prev) => (code in prev ? prev : { ...prev, [code]: '' }));
    setEditOrder((prev) => (prev.includes(code) ? prev : [...prev, code]));
    setStatePickerOpen(false);
  }, []);

  const availableStates = useMemo(
    () => US_STATES.filter((s) => !(s.code in draft)),
    [draft],
  );

  // Scale every state proportionally so the sum matches the entered odometer
  // distance; any rounding remainder is absorbed by the largest state.
  const applyOdometer = useCallback(() => {
    const target = parseFloat(odometer);
    if (isNaN(target) || target <= 0) {
      showAlert(
        'Enter a distance',
        'Type today\u2019s odometer distance before matching.',
      );
      return;
    }
    const codes = Object.keys(draft);
    const current = codes.reduce(
      (sum, c) => sum + (parseFloat(draft[c]) || 0),
      0,
    );
    if (current <= 0) {
      showAlert(
        'Add miles first',
        'Enter miles in at least one state before matching the odometer total.',
      );
      return;
    }
    const factor = target / current;
    const rounded: Record<string, number> = {};
    let running = 0;
    for (const c of codes) {
      const r = Math.round((parseFloat(draft[c]) || 0) * factor * 10) / 10;
      rounded[c] = r;
      running += r;
    }
    const diff = Math.round((target - running) * 10) / 10;
    if (diff !== 0) {
      const largest = codes.reduce(
        (a, b) => (rounded[b] > rounded[a] ? b : a),
        codes[0],
      );
      rounded[largest] = Math.max(
        0,
        Math.round((rounded[largest] + diff) * 10) / 10,
      );
    }
    const scaled: Record<string, string> = {};
    for (const c of codes) scaled[c] = rounded[c].toFixed(1);
    setDraft(scaled);
  }, [odometer, draft, showAlert]);

  const saveEdit = useCallback(async () => {
    const next: StateMiles = {};
    for (const [code, v] of Object.entries(draft)) {
      const num = parseFloat(v);
      if (!isNaN(num) && num > 0) next[code] = Math.round(num * 10) / 10;
    }
    await updateCurrentMiles(next);
    router.back();
  }, [draft, updateCurrentMiles, router]);

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.summaryCard}>
          <Text style={styles.miles}>{formatMiles(draftTotal)}</Text>
          <Text style={styles.milesUnit}>miles today</Text>
        </Card>

        <Text style={styles.editHint}>
          Adjust the miles for each state, or add a state GPS missed, to match
          your odometer. Saving corrects the running total for today and keeps
          recording. The day is not ended.
        </Text>

        <Card style={styles.odoCard}>
          <View style={styles.odoHead}>
            <MaterialIcons name="speed" size={18} color={colors.primary} />
            <Text style={styles.odoTitle}>Match odometer total</Text>
          </View>
          <Text style={styles.odoHelp}>
            Enter the distance from your odometer for today and every state
            scales proportionally to match it. Review below before saving.
          </Text>
          <View style={styles.odoRow}>
            <View style={styles.odoInputWrap}>
              <TextInput
                value={odometer}
                onChangeText={changeOdometer}
                keyboardType="decimal-pad"
                placeholder={draftTotal.toFixed(1)}
                placeholderTextColor={colors.textMuted}
                style={styles.odoInput}
                accessibilityLabel="Odometer total distance"
              />
              <Text style={styles.odoUnit}>mi</Text>
            </View>
            <Button
              label="Match"
              icon="sync"
              variant="secondary"
              onPress={applyOdometer}
              style={styles.odoBtn}
            />
          </View>
        </Card>

        <Text style={styles.sectionTitle}>Miles by state</Text>
        <Card>
          {editOrder.length > 0 ? (
            editOrder.map((code) => (
              <StateRow
                key={code}
                code={code}
                miles={parseFloat(draft[code]) || 0}
                max={1}
                editable
                value={draft[code]}
                onChangeValue={(text) => changeDraft(code, text)}
              />
            ))
          ) : (
            <Text style={styles.emptyText}>
              No miles yet today. Add a state below to log miles manually.
            </Text>
          )}
        </Card>

        <View style={styles.addStateWrap}>
          <Pressable
            onPress={() => setStatePickerOpen((o) => !o)}
            hitSlop={6}
            style={({ pressed }) => [
              styles.addStateBtn,
              { opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <MaterialIcons
              name={statePickerOpen ? 'expand-less' : 'add'}
              size={18}
              color={colors.primary}
            />
            <Text style={styles.addStateText}>
              {statePickerOpen ? 'Close state list' : 'Add a state'}
            </Text>
          </Pressable>
          {statePickerOpen ? (
            <View style={styles.stateGrid}>
              {availableStates.map((s) => (
                <Pressable
                  key={s.code}
                  onPress={() => addState(s.code)}
                  style={({ pressed }) => [
                    styles.stateChip,
                    { opacity: pressed ? 0.7 : 1 },
                  ]}
                  accessibilityLabel={`Add ${s.name}`}
                >
                  <Text style={styles.stateChipText}>{s.code}</Text>
                </Pressable>
              ))}
            </View>
          ) : null}
        </View>

        <View style={styles.editActions}>
          <Button
            label="Cancel"
            variant="secondary"
            onPress={() => router.back()}
            style={styles.actionBtn}
          />
          <Button
            label="Save Miles"
            icon="check"
            onPress={saveEdit}
            style={styles.actionBtn}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
    gap: spacing.md,
  },
  summaryCard: {
    alignItems: 'center',
    padding: spacing.lg,
  },
  miles: {
    ...typography.display,
    color: colors.text,
  },
  milesUnit: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  editHint: {
    ...typography.small,
    color: colors.textSubtle,
    lineHeight: 20,
  },
  odoCard: {
    gap: spacing.sm,
  },
  odoHead: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  odoTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  odoHelp: {
    ...typography.small,
    color: colors.textSubtle,
    lineHeight: 20,
  },
  odoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.xs,
  },
  odoInputWrap: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
  },
  odoInput: {
    flex: 1,
    ...typography.bodyStrong,
    color: colors.text,
    paddingVertical: 10,
  },
  odoUnit: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  odoBtn: {
    paddingHorizontal: spacing.lg,
  },
  sectionTitle: {
    ...typography.h3,
    color: colors.text,
  },
  emptyText: {
    ...typography.small,
    color: colors.textSubtle,
    textAlign: 'center',
    paddingVertical: spacing.sm,
  },
  addStateWrap: {
    gap: spacing.sm,
  },
  addStateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: 44,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceHigh,
  },
  addStateText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '700',
  },
  stateGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  stateChip: {
    minWidth: 46,
    paddingHorizontal: spacing.sm,
    paddingVertical: 8,
    borderRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stateChipText: {
    ...typography.small,
    color: colors.primary,
    fontWeight: '800',
  },
  editActions: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  actionBtn: {
    flex: 1,
  },
});
