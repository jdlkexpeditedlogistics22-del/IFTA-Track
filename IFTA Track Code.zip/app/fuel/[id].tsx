// Powered by OnSpace.AI
// Detail/edit screen for a saved fuel purchase. Lets the driver correct the
// date, state, gallons, cost, odometer and vendor after saving, so a mistyped
// entry can be fixed in place instead of being deleted and re-added.

import React, { useCallback, useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useAlert } from '@/template';
import { useTrips } from '@/hooks/useTrips';
import { Button } from '@/components/ui/Button';
import { DatePickerField } from '@/components/ui/DatePickerField';
import { ToggleField } from '@/components/ui/ToggleField';
import { US_STATES, stateLabel } from '@/constants/states';
import { formatPricePerGallon } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export default function FuelDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { fuel, recentVendors, updateFuelPurchase, deleteFuelPurchase } =
    useTrips();
  const router = useRouter();
  const { showAlert } = useAlert();

  const purchase = fuel.find((f) => f.id === id);

  const [purchaseDate, setPurchaseDate] = useState<number>(
    purchase?.date ?? Date.now(),
  );
  const [stateCode, setStateCode] = useState<string | null>(
    purchase?.stateCode ?? null,
  );
  const [changingState, setChangingState] = useState(false);
  const [query, setQuery] = useState('');
  const [gallons, setGallons] = useState(
    purchase ? String(purchase.gallons) : '',
  );
  const [amount, setAmount] = useState(purchase ? String(purchase.amount) : '');
  const [odometer, setOdometer] = useState(
    purchase?.odometer ? String(purchase.odometer) : '',
  );
  const [vendor, setVendor] = useState(purchase?.vendor ?? '');
  const [fullTank, setFullTank] = useState(purchase?.fullTank !== false);

  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    return US_STATES.filter(
      (s) =>
        q === '' ||
        s.name.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q),
    ).slice(0, 6);
  }, [query]);

  const vendorSuggestions = useMemo(() => {
    const current = vendor.trim().toLowerCase();
    return recentVendors.filter((v) => v.trim().toLowerCase() !== current);
  }, [recentVendors, vendor]);

  const gallonsNum = parseFloat(gallons) || 0;
  const amountNum = parseFloat(amount) || 0;
  const pricePerGal = gallonsNum > 0 ? amountNum / gallonsNum : 0;

  const sanitize = (v: string) => v.replace(/[^0-9.]/g, '');

  const selectState = useCallback((code: string) => {
    setStateCode(code);
    setChangingState(false);
    setQuery('');
  }, []);

  const save = useCallback(() => {
    if (!purchase) return;
    if (!stateCode) {
      showAlert('Select a state', 'Choose the state where you purchased fuel.');
      return;
    }
    if (gallonsNum <= 0) {
      showAlert('Enter gallons', 'Enter how many gallons you purchased.');
      return;
    }
    if (amountNum <= 0) {
      showAlert('Enter amount', 'Enter the total amount you paid.');
      return;
    }
    const odometerNum = parseFloat(odometer) || 0;
    updateFuelPurchase(purchase.id, {
      stateCode,
      gallons: gallonsNum,
      amount: amountNum,
      date: purchaseDate,
      odometer: odometerNum > 0 ? odometerNum : undefined,
      vendor: vendor.trim() || undefined,
      fullTank,
    });
    router.back();
  }, [
    purchase,
    stateCode,
    gallonsNum,
    amountNum,
    odometer,
    purchaseDate,
    vendor,
    fullTank,
    updateFuelPurchase,
    router,
    showAlert,
  ]);

  const handleDelete = useCallback(() => {
    if (!purchase) return;
    showAlert('Delete purchase?', 'This fuel entry will be removed.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          deleteFuelPurchase(purchase.id);
          router.back();
        },
      },
    ]);
  }, [purchase, showAlert, deleteFuelPurchase, router]);

  if (!purchase) {
    return (
      <View style={styles.notFound}>
        <MaterialIcons name="error-outline" size={32} color={colors.textMuted} />
        <Text style={styles.notFoundText}>Fuel purchase not found.</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <DatePickerField
          label="Purchase date"
          value={purchaseDate}
          onChange={setPurchaseDate}
        />

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Purchase state
        </Text>
        {stateCode && !changingState ? (
          <View style={styles.selected}>
            <View style={styles.selectedBadge}>
              <Text style={styles.selectedBadgeText}>{stateCode}</Text>
            </View>
            <View style={styles.selectedInfo}>
              <Text style={styles.selectedName} numberOfLines={1}>
                {stateLabel(stateCode)}
              </Text>
            </View>
            <Pressable
              onPress={() => setChangingState(true)}
              hitSlop={8}
              style={({ pressed }) => [
                styles.changeBtn,
                { opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Text style={styles.changeText}>Change</Text>
            </Pressable>
          </View>
        ) : (
          <>
            <View style={styles.searchBox}>
              <MaterialIcons name="search" size={20} color={colors.textMuted} />
              <TextInput
                value={query}
                onChangeText={setQuery}
                placeholder="Search state name or code"
                placeholderTextColor={colors.textMuted}
                style={styles.input}
                autoCapitalize="characters"
                accessibilityLabel="Search state"
              />
            </View>
            <View style={styles.chips}>
              {suggestions.map((s) => (
                <Pressable
                  key={s.code}
                  onPress={() => selectState(s.code)}
                  style={({ pressed }) => [
                    styles.chip,
                    { opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <Text style={styles.chipCode}>{s.code}</Text>
                  <Text style={styles.chipName}>{s.name}</Text>
                </Pressable>
              ))}
            </View>
          </>
        )}

        <Text style={[styles.label, { marginTop: spacing.lg }]}>Gallons</Text>
        <TextInput
          value={gallons}
          onChangeText={(v) => setGallons(sanitize(v))}
          placeholder="0.0"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="Gallons purchased"
        />

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Total cost ($)
        </Text>
        <TextInput
          value={amount}
          onChangeText={(v) => setAmount(sanitize(v))}
          placeholder="0.00"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="Total amount paid"
        />

        <View style={styles.priceCard}>
          <MaterialIcons name="local-offer" size={18} color={colors.primary} />
          <Text style={styles.priceLabel}>Price per gallon</Text>
          <Text style={styles.priceValue}>
            {pricePerGal > 0 ? formatPricePerGallon(pricePerGal) : '\u2014'}
          </Text>
        </View>

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Odometer (optional)
        </Text>
        <TextInput
          value={odometer}
          onChangeText={(v) => setOdometer(sanitize(v))}
          placeholder="Current mileage"
          placeholderTextColor={colors.textMuted}
          keyboardType="decimal-pad"
          style={styles.fieldInput}
          accessibilityLabel="Odometer reading"
        />

        <View style={{ marginTop: spacing.lg }}>
          <ToggleField
            icon="local-gas-station"
            label="Filled to full tank"
            description="Only full-tank fills are used to calculate MPG. Turn off for a partial fill — its gallons roll into your next full fill."
            value={fullTank}
            onValueChange={setFullTank}
          />
        </View>

        <Text style={[styles.label, { marginTop: spacing.lg }]}>
          Vendor / station (optional)
        </Text>
        <TextInput
          value={vendor}
          onChangeText={setVendor}
          placeholder="e.g. Pilot, Loves, TA"
          placeholderTextColor={colors.textMuted}
          style={styles.fieldInput}
          accessibilityLabel="Vendor or station"
        />

        {vendorSuggestions.length > 0 ? (
          <View style={styles.recentWrap}>
            <Text style={styles.recentLabel}>Recent</Text>
            <View style={styles.recentChips}>
              {vendorSuggestions.map((v) => (
                <Pressable
                  key={v}
                  onPress={() => setVendor(v)}
                  style={({ pressed }) => [
                    styles.recentChip,
                    { opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <MaterialIcons
                    name="history"
                    size={12}
                    color={colors.textSubtle}
                  />
                  <Text style={styles.recentChipText} numberOfLines={1}>
                    {v}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : null}

        <Button
          label="Save Changes"
          icon="check"
          onPress={save}
          large
          style={{ marginTop: spacing.xl }}
        />
        <Button
          label="Delete Purchase"
          icon="delete-outline"
          variant="danger"
          onPress={handleDelete}
          style={{ marginTop: spacing.md }}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  notFound: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.background,
  },
  notFoundText: {
    ...typography.body,
    color: colors.textMuted,
  },
  label: {
    ...typography.small,
    color: colors.textSubtle,
    marginBottom: spacing.sm,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  input: {
    flex: 1,
    ...typography.body,
    color: colors.text,
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
  },
  chipCode: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '800',
  },
  chipName: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  selected: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.sm + 2,
  },
  selectedBadge: {
    width: 44,
    height: 44,
    borderRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedBadgeText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '800',
  },
  selectedInfo: {
    flex: 1,
  },
  selectedName: {
    ...typography.body,
    color: colors.text,
  },
  changeBtn: {
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceHigh,
  },
  changeText: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: '700',
  },
  fieldInput: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
    ...typography.bodyStrong,
    color: colors.text,
  },
  priceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.md,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  priceLabel: {
    flex: 1,
    ...typography.small,
    color: colors.text,
    fontWeight: '600',
  },
  priceValue: {
    ...typography.h3,
    color: colors.primary,
  },
  recentWrap: {
    marginTop: spacing.md,
  },
  recentLabel: {
    ...typography.caption,
    color: colors.textMuted,
    marginBottom: spacing.sm,
    fontWeight: '600',
  },
  recentChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  recentChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
  },
  recentChipText: {
    ...typography.caption,
    color: colors.text,
    fontWeight: '600',
    maxWidth: 180,
  },
});
