import { AlertProvider } from '@/template';
import { AppErrorBoundary } from '@/components/AppErrorBoundary';
import { TripProvider } from '@/contexts/TripContext';
import { TrialProvider } from '@/contexts/TrialContext';
import { KeepAwakeProvider } from '@/contexts/KeepAwakeContext';
import { TrialGate } from '@/components/feature/TrialGate';
import { hardenIconFonts, preloadIconFonts } from '@/services/fontLoader';
import { colors } from '@/constants/theme';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import * as ScreenOrientation from 'expo-screen-orientation';
import { useEffect } from 'react';
import {
  SafeAreaProvider,
  initialWindowMetrics,
} from 'react-native-safe-area-context';

// Make Font.isLoaded()/getLoadedFonts() safe to call during render BEFORE any
// <Icon> (the tab bar) mounts. Synchronous, never throws, no-op on web.
hardenIconFonts();

// Install a GLOBAL JS error guard as early as possible.
//
// WHY: this app's whole job is to keep recording mileage for hours in the
// background. A single UNCAUGHT error anywhere on the JS thread — a stray timer,
// a GPS-callback rejection, a rotation-triggered render path, a native-module
// hiccup — would otherwise tear down the entire process, which the driver sees
// as "the app randomly crashed and stopped recording". React's error boundary
// only catches RENDER errors; it cannot catch errors thrown from async
// callbacks / timers. This guard does.
//
// Non-fatal errors are logged and SWALLOWED so recording keeps running. Fatal
// errors are logged too; we deliberately keep the process alive rather than
// letting it hard-crash, because for a single-purpose driving tool staying up
// and continuing to bank miles is strictly better than dying mid-drive. All
// errors still surface in logcat / Xcode / OnSpace logs for diagnosis.
function installGlobalErrorGuard(): void {
  try {
    const g: any = globalThis as any;
    if (g.__iftaErrorGuardInstalled) return;
    const errorUtils = g.ErrorUtils;
    if (!errorUtils || typeof errorUtils.setGlobalHandler !== 'function') return;
    const previous =
      typeof errorUtils.getGlobalHandler === 'function'
        ? errorUtils.getGlobalHandler()
        : null;
    errorUtils.setGlobalHandler((error: any, isFatal?: boolean) => {
      try {
        console.error(
          'Global JS error caught',
          isFatal ? '(marked fatal)' : '(non-fatal)',
          error?.message,
          error?.stack,
        );
      } catch {
        // never let logging itself throw
      }
      // In development, still let genuinely fatal errors reach the platform
      // handler so they are loud and get fixed. In production, keep the app
      // (and mileage recording) alive through the error.
      if (isFatal && __DEV__ && previous) {
        try {
          previous(error, isFatal);
        } catch {
          // ignore
        }
      }
    });
    g.__iftaErrorGuardInstalled = true;
  } catch {
    // Never let installing the guard itself throw during boot.
  }
}

installGlobalErrorGuard();

export default function RootLayout() {
  useEffect(() => {
    // Allow the screen to follow the device's physical orientation (rotate
    // between portrait and landscape) rather than staying locked. Runs once on
    // launch; no-ops on platforms without orientation control (e.g. web).
    ScreenOrientation.unlockAsync().catch(() => {});
    // Load the real glyphs in the background - icons pop in when ready. This
    // never blocks first paint, so it can never pin the app on the splash.
    preloadIconFonts().catch(() => {});
    // The navigator has mounted - reveal the app.
    SplashScreen.hideAsync().catch(() => {});
  }, []);

  return (
    <AlertProvider>
      <AppErrorBoundary>
        {/* initialWindowMetrics lets SafeAreaProvider render its children
            immediately using metrics captured at launch, instead of waiting on
            the native onInsetsChange event. */}
        <SafeAreaProvider initialMetrics={initialWindowMetrics}>
          <TrialProvider>
            <TripProvider>
            <KeepAwakeProvider>
            <StatusBar style="light" />
            <TrialGate>
            <Stack
              screenOptions={{
                headerShown: false,
                contentStyle: { backgroundColor: colors.background },
              }}
            >
              <Stack.Screen name="(tabs)" />
              <Stack.Screen
                name="edit-today"
                options={{
                  presentation: 'modal',
                  headerShown: true,
                  title: "Edit Today's Miles",
                  headerStyle: { backgroundColor: colors.surface },
                  headerTintColor: colors.text,
                }}
              />
              <Stack.Screen
                name="add-trip"
                options={{
                  presentation: 'modal',
                  headerShown: true,
                  title: 'Add Manual Entry',
                  headerStyle: { backgroundColor: colors.surface },
                  headerTintColor: colors.text,
                }}
              />
              <Stack.Screen
                name="add-fuel"
                options={{
                  presentation: 'modal',
                  headerShown: true,
                  title: 'Add Fuel Purchase',
                  headerStyle: { backgroundColor: colors.surface },
                  headerTintColor: colors.text,
                }}
              />
              <Stack.Screen
                name="add-def"
                options={{
                  presentation: 'modal',
                  headerShown: true,
                  title: 'Add DEF Purchase',
                  headerStyle: { backgroundColor: colors.surface },
                  headerTintColor: colors.text,
                }}
              />
              <Stack.Screen
                name="trip/[id]"
                options={{
                  headerShown: true,
                  title: 'Trip Detail',
                  headerStyle: { backgroundColor: colors.surface },
                  headerTintColor: colors.text,
                }}
              />
              <Stack.Screen
                name="fuel/[id]"
                options={{
                  headerShown: true,
                  title: 'Edit Fuel Purchase',
                  headerStyle: { backgroundColor: colors.surface },
                  headerTintColor: colors.text,
                }}
              />
              <Stack.Screen
                name="def/[id]"
                options={{
                  headerShown: true,
                  title: 'Edit DEF Purchase',
                  headerStyle: { backgroundColor: colors.surface },
                  headerTintColor: colors.text,
                }}
              />
            </Stack>
            </TrialGate>
            </KeepAwakeProvider>
            </TripProvider>
          </TrialProvider>
        </SafeAreaProvider>
      </AppErrorBoundary>
    </AlertProvider>
  );
}
