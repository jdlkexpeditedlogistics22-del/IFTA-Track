// Powered by OnSpace.AI
// Top-level React error boundary.
//
// WHY THIS EXISTS:
// A JS error thrown while rendering ANY provider or screen (e.g. the expo-font
// isLoadedNative TypeError on first <Icon>, or an incompatible native view
// config) unmounts the whole React tree and leaves a BLANK screen — which is
// indistinguishable from "the app fails to load after build". This boundary
// catches those render errors, logs them (so they surface in logcat / Xcode /
// OnSpace logs) AND shows the message on-screen, so a startup failure is visible
// and diagnosable instead of silent.
//
// It is deliberately self-contained — only core react-native primitives, no
// theme / feature imports — so it can still render even when other modules are
// the thing that is broken. Brand color (#F5A623) matches app.json primaryColor.

import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';

type Props = { children: React.ReactNode };
type State = { error: Error | null };

export class AppErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: { componentStack?: string }) {
    // Surface to the JS console so it lands in device / OnSpace logs.
    console.error(
      'App render crashed:',
      error?.message,
      error?.stack,
      info?.componentStack,
    );
  }

  handleRetry = () => {
    this.setState({ error: null });
  };

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;

    return (
      <View style={styles.container}>
        <ScrollView
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.title}>Something went wrong</Text>
          <Text style={styles.subtitle}>
            The app hit an error while starting up.
          </Text>

          <Text style={styles.label}>Error</Text>
          <Text style={styles.message}>{String(error.message || error)}</Text>

          {error.stack ? (
            <View>
              <Text style={styles.label}>Details</Text>
              <Text style={styles.stack}>{error.stack}</Text>
            </View>
          ) : null}

          <Text style={styles.retry} onPress={this.handleRetry}>
            Tap to retry
          </Text>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0E1621',
  },
  content: {
    padding: 24,
    paddingTop: 72,
    gap: 10,
  },
  title: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: '700',
  },
  subtitle: {
    color: '#AEB8C4',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 8,
  },
  label: {
    color: '#F5A623',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 14,
    letterSpacing: 0.5,
  },
  message: {
    color: '#FFFFFF',
    fontSize: 15,
    lineHeight: 22,
  },
  stack: {
    color: '#8894A4',
    fontSize: 12,
    lineHeight: 18,
    marginTop: 4,
  },
  retry: {
    color: '#F5A623',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 28,
  },
});
