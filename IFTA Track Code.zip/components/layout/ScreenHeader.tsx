import React, { ReactNode } from 'react';
import { ImageSourcePropType, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { colors, radius, spacing, typography } from '@/constants/theme';

interface ScreenHeaderProps {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  logo?: ImageSourcePropType;
}

export function ScreenHeader({
  title,
  subtitle,
  right,
  logo,
}: ScreenHeaderProps) {
  return (
    <View style={styles.container}>
      {logo ? (
        <View style={styles.logoWrap}>
          <Image
            source={logo}
            style={styles.logo}
            contentFit="contain"
            transition={200}
          />
        </View>
      ) : null}
      <View style={styles.textWrap}>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {right ? <View>{right}</View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: spacing.md,
  },
  logoWrap: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 6,
    marginRight: spacing.md,
  },
  logo: {
    width: '100%',
    height: '100%',
  },
  textWrap: {
    flex: 1,
  },
  title: {
    ...typography.h1,
    color: colors.text,
  },
  subtitle: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
});
