// Powered by OnSpace.AI

import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing, typography } from '@/constants/theme';
import { stateLabel } from '@/constants/states';
import {
  formatGallons,
  formatMiles,
  formatSignedGallons,
} from '@/constants/format';

interface IftaStateRowProps {
  code: string;
  miles: number;
  taxableGallons: number;
  taxPaidGallons: number;
  netTaxableGallons: number;
  computable: boolean;
  max: number;
}

export function IftaStateRow({
  code,
  miles,
  taxableGallons,
  taxPaidGallons,
  netTaxableGallons,
  computable,
  max,
}: IftaStateRowProps) {
  const pct = Math.max(4, Math.min(100, (miles / max) * 100));
  const netColor = !computable
    ? colors.textMuted
    : netTaxableGallons > 0.05
      ? colors.primary
      : netTaxableGallons < -0.05
        ? colors.success
        : colors.textSubtle;

  return (
    <View style={styles.row}>
      <View style={styles.badge}>
        <Text style={styles.badgeText}>{code}</Text>
      </View>
      <View style={styles.mid}>
        <View style={styles.line}>
          <Text style={styles.name} numberOfLines={1}>
            {stateLabel(code)}
          </Text>
          <Text style={[styles.net, { color: netColor }]}>
            {computable
              ? `${formatSignedGallons(netTaxableGallons)} gal`
              : '\u2014'}
          </Text>
        </View>
        <View style={styles.track}>
          <View style={[styles.fill, { width: `${pct}%` }]} />
        </View>
        <Text style={styles.meta} numberOfLines={1}>
          {formatMiles(miles)} mi · used{' '}
          {computable ? formatGallons(taxableGallons) : '\u2014'} · paid{' '}
          {formatGallons(taxPaidGallons)} gal
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm + 2,
  },
  badge: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '800',
  },
  mid: {
    flex: 1,
    gap: 6,
  },
  line: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  name: {
    ...typography.body,
    color: colors.text,
    flex: 1,
    marginRight: spacing.sm,
  },
  net: {
    ...typography.bodyStrong,
  },
  track: {
    height: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceHigh,
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
    borderRadius: radius.pill,
    backgroundColor: colors.primary,
  },
  meta: {
    ...typography.caption,
    color: colors.textSubtle,
  },
});
