// Full-screen lock shown when the 7-day trial has ended and the device is not
// unlocked. Renders children unchanged in every other case (loading, active
// trial, or unlocked). Provides an unlock-code entry for the master code.

import React, { useCallback, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTrial } from '@/hooks/useTrial';
import { colors, radius, spacing, typography } from '@/constants/theme';

export function TrialGate({ children }: { children: React.ReactNode }) {
  const { loading, locked, redeem } = useTrial();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [checking, setChecking] = useState(false);

  const onUnlock = useCallback(async () => {
    if (!code.trim() || checking) return;
    setChecking(true);
    setError('');
    const ok = await redeem(code);
    setChecking(false);
    if (!ok) setError('That unlock code is not valid. Please try again.');
  }, [code, checking, redeem]);

  if (loading || !locked) return <>{children}</>;

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <View style={styles.content}>
          <View style={styles.iconWrap}>
            <MaterialIcons name="lock-clock" size={40} color={colors.primary} />
          </View>
          <Text style={styles.title}>Trial ended</Text>
          <Text style={styles.subtitle}>
            Your 7-day free trial of IFTA Track has finished. Enter an unlock
            code to keep recording mileage and fuel on this device.
          </Text>

          <TextInput
            style={styles.input}
            value={code}
            onChangeText={(t) => {
              setCode(t);
              setError('');
            }}
            placeholder="Enter unlock code"
            placeholderTextColor={colors.textMuted}
            autoCapitalize="characters"
            autoCorrect={false}
            returnKeyType="done"
            onSubmitEditing={onUnlock}
          />

          {error ? (
            <View style={styles.errorRow}>
              <MaterialIcons
                name="error-outline"
                size={16}
                color={colors.danger}
              />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <Pressable
            onPress={onUnlock}
            disabled={checking}
            style={({ pressed }) => [
              styles.button,
              { opacity: pressed || checking ? 0.85 : 1 },
            ]}
          >
            <Text style={styles.buttonText}>
              {checking ? 'Checking...' : 'Unlock app'}
            </Text>
          </Pressable>

          <Text style={styles.note}>
            Contact the app author to request an unlock code.
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: {
    flex: 1,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
  },
  iconWrap: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  title: {
    ...typography.h1,
    color: colors.text,
    textAlign: 'center',
  },
  subtitle: {
    ...typography.body,
    color: colors.textSubtle,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: spacing.sm,
  },
  input: {
    width: '100%',
    height: 52,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    color: colors.text,
    ...typography.bodyStrong,
    textAlign: 'center',
    letterSpacing: 2,
  },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  errorText: {
    ...typography.small,
    color: colors.danger,
  },
  button: {
    width: '100%',
    height: 52,
    borderRadius: radius.md,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.xs,
  },
  buttonText: {
    ...typography.bodyStrong,
    color: colors.onPrimary,
    fontWeight: '800',
  },
  note: {
    ...typography.caption,
    color: colors.textMuted,
    textAlign: 'center',
    marginTop: spacing.sm,
  },
});
