// Powered by OnSpace.AI

import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing, typography } from '@/constants/theme';
import { stateLabel } from '@/constants/states';
import { formatCurrency, formatGallons } from '@/constants/format';

interface FuelStateRowProps {
  code: string;
  gallons: number;
  amount: number;
}

export function FuelStateRow({ code, gallons, amount }: FuelStateRowProps) {
  return (
    <View style={styles.row}>
      <View style={styles.badge}>
        <Text style={styles.badgeText}>{code}</Text>
      </View>
      <Text style={styles.name} numberOfLines={1}>
        {stateLabel(code)}
      </Text>
      <View style={styles.right}>
        <Text style={styles.amount}>{formatCurrency(amount)}</Text>
        <Text style={styles.gallons}>{formatGallons(gallons)} gal</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm + 2,
  },
  badge: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '800',
  },
  name: {
    flex: 1,
    ...typography.body,
    color: colors.text,
  },
  right: {
    alignItems: 'flex-end',
  },
  amount: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  gallons: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 2,
  },
});
