// Modal that collects a recipient email address before sending the IFTA report.
// Validates the address, shows an inline error, and keeps the field usable above
// the keyboard on both platforms.

import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors, radius, spacing, typography } from '@/constants/theme';

type Props = {
  visible: boolean;
  periodLabel?: string;
  loading?: boolean;
  onCancel: () => void;
  onSend: (email: string) => void;
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function EmailReportDialog({
  visible,
  periodLabel,
  loading,
  onCancel,
  onSend,
}: Props) {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  // Start clean each time the dialog opens.
  useEffect(() => {
    if (visible) {
      setEmail('');
      setError('');
    }
  }, [visible]);

  const handleSend = () => {
    const trimmed = email.trim();
    if (!EMAIL_RE.test(trimmed)) {
      setError('Enter a valid email address.');
      return;
    }
    setError('');
    onSend(trimmed);
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onCancel}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.backdrop}
      >
        <View style={styles.card}>
          <View style={styles.iconWrap}>
            <MaterialIcons name="mail-outline" size={24} color={colors.primary} />
          </View>
          <Text style={styles.title}>Email report</Text>
          <Text style={styles.subtitle}>
            {periodLabel
              ? `Send the ${periodLabel} IFTA mileage report to:`
              : 'Send the IFTA mileage report to:'}
          </Text>

          <TextInput
            value={email}
            onChangeText={(t) => {
              setEmail(t);
              if (error) setError('');
            }}
            placeholder="name@company.com"
            placeholderTextColor={colors.textMuted}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoFocus
            editable={!loading}
            onSubmitEditing={handleSend}
            returnKeyType="send"
            accessibilityLabel="Recipient email address"
            style={[styles.input, error ? styles.inputError : null]}
          />
          {error ? (
            <View style={styles.errorRow}>
              <MaterialIcons name="error-outline" size={14} color={colors.danger} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <Text style={styles.hint}>
            A formatted PDF and a CSV are attached to the message.
          </Text>

          <View style={styles.actions}>
            <Pressable
              onPress={onCancel}
              disabled={loading}
              style={({ pressed }) => [
                styles.btn,
                styles.btnGhost,
                { opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <Text style={styles.btnGhostText}>Cancel</Text>
            </Pressable>
            <Pressable
              onPress={handleSend}
              disabled={loading}
              style={({ pressed }) => [
                styles.btn,
                styles.btnPrimary,
                { opacity: loading ? 0.6 : pressed ? 0.85 : 1 },
              ]}
            >
              {loading ? (
                <ActivityIndicator size="small" color={colors.onPrimary} />
              ) : (
                <Text style={styles.btnPrimaryText}>Send</Text>
              )}
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  card: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  title: {
    ...typography.h2,
    color: colors.text,
  },
  subtitle: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 4,
    marginBottom: spacing.md,
    lineHeight: 20,
  },
  input: {
    ...typography.body,
    color: colors.text,
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 48,
  },
  inputError: {
    borderColor: colors.danger,
  },
  errorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: spacing.xs,
  },
  errorText: {
    ...typography.caption,
    color: colors.danger,
  },
  hint: {
    ...typography.caption,
    color: colors.textMuted,
    marginTop: spacing.sm,
    lineHeight: 17,
  },
  actions: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  btn: {
    flex: 1,
    height: 48,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnGhost: {
    backgroundColor: colors.surfaceAlt,
    borderWidth: 1,
    borderColor: colors.border,
  },
  btnGhostText: {
    ...typography.body,
    color: colors.textSubtle,
    fontWeight: '700',
  },
  btnPrimary: {
    backgroundColor: colors.primary,
  },
  btnPrimaryText: {
    ...typography.body,
    color: colors.onPrimary,
    fontWeight: '700',
  },
});
