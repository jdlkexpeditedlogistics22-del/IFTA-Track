// Graphical export chooser. Replaces the plain text alert with a bottom sheet
// of tappable, icon-led options (Email, PDF, Print, CSV, Text). Each row shows
// an icon, a title, and a short description of what the option does.

import React from 'react';
import {
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography } from '@/constants/theme';

export type ExportChoice = 'email' | 'pdf' | 'print' | 'csv' | 'text';

type Props = {
  visible: boolean;
  periodLabel?: string;
  // Optional subset of choices to show (in the given order). Defaults to all.
  choices?: ExportChoice[];
  onSelect: (choice: ExportChoice) => void;
  onClose: () => void;
};

type Option = {
  key: ExportChoice;
  icon: keyof typeof MaterialIcons.glyphMap;
  title: string;
  desc: string;
};

const OPTIONS: Option[] = [
  {
    key: 'email',
    icon: 'mail-outline',
    title: 'Email report',
    desc: 'Send to an address with PDF + CSV attached',
  },
  {
    key: 'pdf',
    icon: 'picture-as-pdf',
    title: 'Save PDF',
    desc: 'Formatted report to save or share',
  },
  {
    key: 'print',
    icon: 'print',
    title: 'Print report',
    desc: 'Open the print dialog',
  },
  {
    key: 'csv',
    icon: 'grid-on',
    title: 'CSV spreadsheet',
    desc: 'Open in Excel, Sheets or Numbers',
  },
  {
    key: 'text',
    icon: 'description',
    title: 'Text report',
    desc: 'Plain-text aligned table',
  },
];

export function ExportOptionsSheet({
  visible,
  periodLabel,
  choices,
  onSelect,
  onClose,
}: Props) {
  const insets = useSafeAreaInsets();

  const options = choices
    ? choices
        .map((key) => OPTIONS.find((o) => o.key === key))
        .filter((o): o is Option => !!o)
    : OPTIONS;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable
          style={[styles.sheet, { paddingBottom: insets.bottom + spacing.md }]}
          onPress={(e) => e.stopPropagation()}
        >
          <View style={styles.grabber} />
          <View style={styles.header}>
            <View style={styles.flex1}>
              <Text style={styles.title}>Export report</Text>
              <Text style={styles.subtitle}>
                {periodLabel
                  ? `Choose how to share ${periodLabel}`
                  : 'Choose how to share the selected period'}
              </Text>
            </View>
            <Pressable
              onPress={onClose}
              hitSlop={10}
              style={({ pressed }) => [
                styles.closeBtn,
                { opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <MaterialIcons name="close" size={20} color={colors.textSubtle} />
            </Pressable>
          </View>

          {options.map((opt, i) => (
            <Pressable
              key={opt.key}
              onPress={() => onSelect(opt.key)}
              style={({ pressed }) => [
                styles.row,
                i === 0 && styles.rowFirst,
                { opacity: pressed ? 0.85 : 1 },
                pressed && styles.rowPressed,
              ]}
            >
              <View style={styles.iconWrap}>
                <MaterialIcons name={opt.icon} size={22} color={colors.primary} />
              </View>
              <View style={styles.flex1}>
                <Text style={styles.rowTitle}>{opt.title}</Text>
                <Text style={styles.rowDesc}>{opt.desc}</Text>
              </View>
              <MaterialIcons
                name="chevron-right"
                size={22}
                color={colors.textMuted}
              />
            </Pressable>
          ))}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderColor: colors.border,
  },
  grabber: {
    alignSelf: 'center',
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.border,
    marginBottom: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: spacing.md,
    paddingHorizontal: spacing.xs,
  },
  flex1: {
    flex: 1,
  },
  title: {
    ...typography.h2,
    color: colors.text,
  },
  subtitle: {
    ...typography.small,
    color: colors.textSubtle,
    marginTop: 2,
  },
  closeBtn: {
    width: 32,
    height: 32,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  rowFirst: {
    borderTopWidth: 0,
  },
  rowPressed: {
    backgroundColor: colors.surfaceAlt,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  rowDesc: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 2,
  },
});
