// Donut/pie chart of recorded miles by jurisdiction, ranked most to least
// traveled. Renders with react-native-svg. The top states are drawn as their
// own slices; any remaining long tail is grouped into a single "Other" slice so
// the chart stays readable. A ranked legend lists each slice with its share.

import React, { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, G } from 'react-native-svg';
import { Card } from '@/components/ui/Card';
import { stateLabel } from '@/constants/states';
import { formatMiles } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

export type PieDatum = { code: string; miles: number };

// Distinct, high-contrast slice colors. The final entry is reserved for the
// grouped "Other" slice.
const SLICE_COLORS = [
  '#F5A623', // amber (brand)
  '#4DA3FF', // blue
  '#34C759', // green
  '#FF453A', // red
  '#AF52DE', // purple
  '#5AC8FA', // sky
  '#FFD60A', // yellow
  '#FF7A45', // coral
];
const OTHER_COLOR = '#647387';

// Show at most this many individual states; the rest fold into "Other".
const MAX_SLICES = 8;

type Slice = {
  key: string;
  label: string;
  miles: number;
  fraction: number;
  color: string;
};

export function MilesPieChart({ data }: { data: PieDatum[] }) {
  const { slices, total } = useMemo(() => {
    const ranked = data
      .filter((d) => d.miles > 0)
      .sort((a, b) => b.miles - a.miles);
    const sum = ranked.reduce((acc, d) => acc + d.miles, 0);

    if (sum <= 0) return { slices: [] as Slice[], total: 0 };

    const head = ranked.slice(0, MAX_SLICES);
    const tail = ranked.slice(MAX_SLICES);
    const result: Slice[] = head.map((d, i) => ({
      key: d.code,
      label: stateLabel(d.code),
      miles: d.miles,
      fraction: d.miles / sum,
      color: SLICE_COLORS[i % SLICE_COLORS.length],
    }));

    if (tail.length > 0) {
      const otherMiles = tail.reduce((acc, d) => acc + d.miles, 0);
      result.push({
        key: '__other__',
        label: `Other (${tail.length})`,
        miles: otherMiles,
        fraction: otherMiles / sum,
        color: OTHER_COLOR,
      });
    }
    return { slices: result, total: sum };
  }, [data]);

  if (slices.length === 0) {
    return (
      <Card style={styles.emptyCard}>
        <Text style={styles.emptyText}>
          No miles recorded yet for this period.
        </Text>
      </Card>
    );
  }

  const size = 200;
  const strokeWidth = 30;
  const r = (size - strokeWidth) / 2;
  const cx = size / 2;
  const cy = size / 2;
  const circumference = 2 * Math.PI * r;

  // Accumulate slice offsets around the ring. Rotated -90deg so slices begin at
  // the 12 o'clock position and run clockwise from most to least traveled.
  let offset = 0;

  return (
    <Card style={styles.card}>
      <View style={styles.chartRow}>
        <View style={styles.chartWrap}>
          <Svg width={size} height={size}>
            <G rotation={-90} origin={`${cx}, ${cy}`}>
              {slices.map((slice) => {
                const dash = slice.fraction * circumference;
                const el = (
                  <Circle
                    key={slice.key}
                    cx={cx}
                    cy={cy}
                    r={r}
                    fill="none"
                    stroke={slice.color}
                    strokeWidth={strokeWidth}
                    strokeDasharray={`${dash} ${circumference - dash}`}
                    strokeDashoffset={-offset}
                    strokeLinecap="butt"
                  />
                );
                offset += dash;
                return el;
              })}
            </G>
          </Svg>
          <View style={styles.centerLabel} pointerEvents="none">
            <Text style={styles.centerValue}>{formatMiles(total)}</Text>
            <Text style={styles.centerCaption}>total miles</Text>
          </View>
        </View>
      </View>

      <View style={styles.legend}>
        {slices.map((slice, i) => (
          <View key={slice.key} style={styles.legendRow}>
            <View style={styles.legendLeft}>
              <View style={styles.rankWrap}>
                <Text style={styles.rankText}>{i + 1}</Text>
              </View>
              <View
                style={[styles.dot, { backgroundColor: slice.color }]}
              />
              <Text style={styles.legendLabel} numberOfLines={1}>
                {slice.label}
              </Text>
            </View>
            <View style={styles.legendRight}>
              <Text style={styles.legendMiles}>
                {formatMiles(slice.miles)} mi
              </Text>
              <Text style={styles.legendPct}>
                {(slice.fraction * 100).toFixed(1)}%
              </Text>
            </View>
          </View>
        ))}
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: spacing.lg,
    gap: spacing.md,
  },
  emptyCard: {
    padding: spacing.lg,
    alignItems: 'center',
  },
  emptyText: {
    ...typography.small,
    color: colors.textMuted,
    textAlign: 'center',
  },
  chartRow: {
    alignItems: 'center',
  },
  chartWrap: {
    width: 200,
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerLabel: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerValue: {
    ...typography.h1,
    color: colors.text,
  },
  centerCaption: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 2,
  },
  legend: {
    gap: spacing.sm,
  },
  legendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.sm,
  },
  legendLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    flex: 1,
  },
  rankWrap: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.surfaceHigh,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankText: {
    ...typography.caption,
    color: colors.textSubtle,
    fontWeight: '700',
  },
  dot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  legendLabel: {
    ...typography.small,
    color: colors.text,
    fontWeight: '600',
    flex: 1,
  },
  legendRight: {
    alignItems: 'flex-end',
  },
  legendMiles: {
    ...typography.small,
    color: colors.text,
    fontWeight: '700',
  },
  legendPct: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 1,
  },
});
