// Powered by OnSpace.AI

import React from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius, spacing, typography } from '@/constants/theme';
import { stateLabel } from '@/constants/states';
import { formatMiles } from '@/constants/format';

interface StateRowProps {
  code: string;
  miles: number;
  max: number;
  // When editable, the right side becomes a numeric input instead of a label +
  // progress bar, so recorded miles can be corrected in place.
  editable?: boolean;
  value?: string;
  onChangeValue?: (text: string) => void;
}

export function StateRow({
  code,
  miles,
  max,
  editable,
  value,
  onChangeValue,
}: StateRowProps) {
  const pct = Math.max(4, Math.min(100, (miles / max) * 100));
  return (
    <View style={styles.row}>
      <View style={styles.badge}>
        <Text style={styles.badgeText}>{code}</Text>
      </View>
      <View style={styles.mid}>
        <View style={styles.line}>
          <Text style={styles.name} numberOfLines={1}>
            {stateLabel(code)}
          </Text>
          {editable ? (
            <View style={styles.editWrap}>
              <TextInput
                value={value}
                onChangeText={onChangeValue}
                keyboardType="decimal-pad"
                placeholder="0.0"
                placeholderTextColor={colors.textMuted}
                style={styles.input}
                selectTextOnFocus
                accessibilityLabel={`Miles in ${stateLabel(code)}`}
              />
              <Text style={styles.unit}>mi</Text>
            </View>
          ) : (
            <Text style={styles.miles}>{formatMiles(miles)} mi</Text>
          )}
        </View>
        {editable ? null : (
          <View style={styles.track}>
            <View style={[styles.fill, { width: `${pct}%` }]} />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm + 2,
  },
  badge: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    ...typography.bodyStrong,
    color: colors.primary,
    fontWeight: '800',
  },
  mid: {
    flex: 1,
    gap: 6,
  },
  line: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  name: {
    ...typography.body,
    color: colors.text,
    flex: 1,
    marginRight: spacing.sm,
  },
  miles: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  editWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  input: {
    minWidth: 84,
    textAlign: 'right',
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.sm,
    paddingVertical: 6,
    ...typography.bodyStrong,
    color: colors.text,
  },
  unit: {
    ...typography.caption,
    color: colors.textSubtle,
  },
  track: {
    height: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceHigh,
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
    borderRadius: radius.pill,
    backgroundColor: colors.primary,
  },
});
