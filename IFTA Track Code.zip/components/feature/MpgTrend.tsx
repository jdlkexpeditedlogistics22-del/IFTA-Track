// Powered by OnSpace.AI
// Per-fill fuel-economy trend for the Summary tab. Each bar is the MPG of one
// tank fill, computed from the distance between consecutive fuel-purchase
// odometer readings divided by the gallons of the later fill, so efficiency
// changes are visible over time.

import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Card } from '@/components/ui/Card';
import { FillMpg } from '@/services/aggregation';
import { formatMpg } from '@/constants/format';
import { colors, radius, spacing, typography } from '@/constants/theme';

const BAR_MAX_HEIGHT = 92;
const BAR_MIN_HEIGHT = 6;
const MAX_BARS = 10;

function shortDate(ts: number): string {
  return new Date(ts).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
  });
}

export function MpgTrend({ fills }: { fills: FillMpg[] }) {
  if (fills.length < 1) {
    return (
      <Card>
        <View style={styles.emptyRow}>
          <MaterialIcons name="show-chart" size={18} color={colors.textMuted} />
          <Text style={styles.emptyText}>
            Add two or more full-tank fuel fills with odometer readings to see
            your per-fill MPG trend. Partial fills roll into the next full fill.
          </Text>
        </View>
      </Card>
    );
  }

  const recent = fills.slice(-MAX_BARS);
  const maxMpg = recent.reduce((m, f) => Math.max(m, f.mpg), 1);
  const avg = fills.reduce((s, f) => s + f.mpg, 0) / fills.length;
  const latest = fills[fills.length - 1];
  const prev = fills.length > 1 ? fills[fills.length - 2] : null;
  const delta = prev ? latest.mpg - prev.mpg : 0;
  const up = delta >= 0;

  return (
    <Card>
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.latestValue}>{formatMpg(latest.mpg)}</Text>
          <Text style={styles.latestLabel}>latest fill MPG</Text>
        </View>
        <View style={styles.headerRight}>
          {prev ? (
            <View
              style={[
                styles.deltaChip,
                { backgroundColor: up ? colors.successSoft : colors.dangerSoft },
              ]}
            >
              <MaterialIcons
                name={up ? 'trending-up' : 'trending-down'}
                size={14}
                color={up ? colors.success : colors.danger}
              />
              <Text
                style={[
                  styles.deltaText,
                  { color: up ? colors.success : colors.danger },
                ]}
              >
                {`${up ? '+' : ''}${delta.toFixed(1)}`}
              </Text>
            </View>
          ) : null}
          <Text style={styles.avgText}>avg {formatMpg(avg)}</Text>
        </View>
      </View>

      <View style={styles.chart}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.chartContent}
        >
          {recent.map((f) => {
            const h = Math.max(BAR_MIN_HEIGHT, (f.mpg / maxMpg) * BAR_MAX_HEIGHT);
            const isBest = f.mpg === maxMpg;
            return (
              <View key={f.id} style={styles.barCol}>
                <Text style={styles.barValue}>{f.mpg.toFixed(1)}</Text>
                <View style={[styles.bar, { height: h }, isBest && styles.barBest]} />
                <Text style={styles.barDate} numberOfLines={1}>
                  {shortDate(f.date)}
                </Text>
              </View>
            );
          })}
        </ScrollView>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  emptyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  emptyText: {
    flex: 1,
    ...typography.caption,
    color: colors.textSubtle,
    lineHeight: 18,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  latestValue: {
    ...typography.h1,
    color: colors.text,
  },
  latestLabel: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 2,
  },
  headerRight: {
    alignItems: 'flex-end',
    gap: spacing.xs,
  },
  deltaChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: spacing.sm,
    height: 24,
    borderRadius: radius.pill,
  },
  deltaText: {
    ...typography.caption,
    fontWeight: '700',
  },
  avgText: {
    ...typography.caption,
    color: colors.textSubtle,
    fontWeight: '600',
  },
  chart: {
    height: BAR_MAX_HEIGHT + 44,
  },
  chartContent: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: spacing.md,
    paddingHorizontal: spacing.xs,
  },
  barCol: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    width: 40,
  },
  barValue: {
    ...typography.caption,
    color: colors.textSubtle,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  bar: {
    width: 22,
    borderTopLeftRadius: radius.sm,
    borderTopRightRadius: radius.sm,
    backgroundColor: colors.primarySoft,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  barBest: {
    backgroundColor: colors.primary,
  },
  barDate: {
    ...typography.caption,
    color: colors.textMuted,
    marginTop: spacing.xs,
  },
});
