// Powered by OnSpace.AI
// A labeled on/off toggle row used on the fuel and DEF entry/edit screens for
// the "Full tank" switch that drives precise tank-to-tank MPG.

import React from 'react';
import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors, radius, spacing, typography } from '@/constants/theme';

type Props = {
  label: string;
  description?: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  icon?: keyof typeof MaterialIcons.glyphMap;
};

export function ToggleField({
  label,
  description,
  value,
  onValueChange,
  icon,
}: Props) {
  return (
    <Pressable
      onPress={() => onValueChange(!value)}
      accessibilityRole="switch"
      accessibilityState={{ checked: value }}
      accessibilityLabel={label}
      style={({ pressed }) => [styles.row, { opacity: pressed ? 0.9 : 1 }]}
    >
      {icon ? (
        <View style={[styles.iconWrap, value && styles.iconWrapOn]}>
          <MaterialIcons
            name={icon}
            size={20}
            color={value ? colors.primary : colors.textMuted}
          />
        </View>
      ) : null}
      <View style={styles.textWrap}>
        <Text style={styles.label}>{label}</Text>
        {description ? (
          <Text style={styles.description}>{description}</Text>
        ) : null}
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: colors.border, true: colors.primary }}
        thumbColor={colors.surface}
        ios_backgroundColor={colors.border}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrapOn: {
    backgroundColor: colors.primarySoft,
  },
  textWrap: {
    flex: 1,
  },
  label: {
    ...typography.bodyStrong,
    color: colors.text,
    fontWeight: '700',
  },
  description: {
    ...typography.caption,
    color: colors.textSubtle,
    marginTop: 2,
    lineHeight: 16,
  },
});
