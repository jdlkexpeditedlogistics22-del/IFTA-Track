// Powered by OnSpace.AI
// Compact, dependency-free calendar date picker (works on web + native) so
// trips can be dated to any past day and land in the correct IFTA period.

import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors, radius, spacing, typography } from '@/constants/theme';

interface DatePickerFieldProps {
  label?: string;
  value: number; // timestamp
  onChange: (ts: number) => void;
  maxDate?: number; // disallow dates after this (defaults to today)
}

const WEEKDAYS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function isSameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

export function DatePickerField({
  label,
  value,
  onChange,
  maxDate,
}: DatePickerFieldProps) {
  const [open, setOpen] = useState(false);
  const selected = useMemo(() => new Date(value), [value]);
  const [view, setView] = useState(() => new Date(value));

  const today = startOfDay(new Date());
  const max = maxDate != null ? startOfDay(new Date(maxDate)) : today;

  const grid = useMemo(() => {
    const year = view.getFullYear();
    const month = view.getMonth();
    const startWeekday = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: (Date | null)[] = [];
    for (let i = 0; i < startWeekday; i++) cells.push(null);
    for (let day = 1; day <= daysInMonth; day++) {
      cells.push(new Date(year, month, day));
    }
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }, [view]);

  const canGoNext = useMemo(() => {
    const nextMonthFirst = new Date(view.getFullYear(), view.getMonth() + 1, 1);
    return nextMonthFirst <= max;
  }, [view, max]);

  const changeMonth = (delta: number) => {
    setView((v) => new Date(v.getFullYear(), v.getMonth() + delta, 1));
  };

  const selectDay = (d: Date) => {
    onChange(startOfDay(d).getTime());
    setOpen(false);
  };

  const selectToday = () => {
    const t = new Date();
    setView(t);
    onChange(startOfDay(t).getTime());
    setOpen(false);
  };

  const formatted = selected.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <View>
      {label ? <Text style={styles.label}>{label}</Text> : null}
      <Pressable
        onPress={() => setOpen((o) => !o)}
        style={({ pressed }) => [styles.field, { opacity: pressed ? 0.9 : 1 }]}
        accessibilityLabel="Select trip date"
      >
        <MaterialIcons name="event" size={20} color={colors.primary} />
        <Text style={styles.fieldText}>{formatted}</Text>
        <MaterialIcons
          name={open ? 'expand-less' : 'expand-more'}
          size={22}
          color={colors.textMuted}
        />
      </Pressable>

      {open ? (
        <View style={styles.calendar}>
          <View style={styles.calHeader}>
            <Pressable
              onPress={() => changeMonth(-1)}
              hitSlop={8}
              style={styles.navBtn}
            >
              <MaterialIcons name="chevron-left" size={24} color={colors.text} />
            </Pressable>
            <Text style={styles.calTitle}>
              {MONTHS[view.getMonth()]} {view.getFullYear()}
            </Text>
            <Pressable
              onPress={() => canGoNext && changeMonth(1)}
              hitSlop={8}
              disabled={!canGoNext}
              style={styles.navBtn}
            >
              <MaterialIcons
                name="chevron-right"
                size={24}
                color={canGoNext ? colors.text : colors.textMuted}
              />
            </Pressable>
          </View>

          <View style={styles.weekRow}>
            {WEEKDAYS.map((w, i) => (
              <Text key={`${w}-${i}`} style={styles.weekday}>
                {w}
              </Text>
            ))}
          </View>

          <View style={styles.daysGrid}>
            {grid.map((d, i) => {
              if (!d) return <View key={`empty-${i}`} style={styles.dayCell} />;
              const disabled = startOfDay(d) > max;
              const isSel = isSameDay(d, selected);
              const isToday = isSameDay(d, today);
              return (
                <Pressable
                  key={d.toISOString()}
                  onPress={() => !disabled && selectDay(d)}
                  disabled={disabled}
                  style={styles.dayCell}
                >
                  <View
                    style={[
                      styles.dayInner,
                      isSel && styles.daySelected,
                      !isSel && isToday ? styles.dayToday : null,
                    ]}
                  >
                    <Text
                      style={[
                        styles.dayText,
                        disabled && styles.dayTextDisabled,
                        isSel && styles.dayTextSelected,
                      ]}
                    >
                      {d.getDate()}
                    </Text>
                  </View>
                </Pressable>
              );
            })}
          </View>

          <Pressable onPress={selectToday} style={styles.todayBtn}>
            <Text style={styles.todayText}>Today</Text>
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  label: {
    ...typography.small,
    color: colors.textSubtle,
    marginBottom: spacing.sm,
  },
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
  },
  fieldText: {
    flex: 1,
    ...typography.body,
    color: colors.text,
    fontWeight: '600',
  },
  calendar: {
    marginTop: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  calHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  navBtn: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  calTitle: {
    ...typography.bodyStrong,
    color: colors.text,
  },
  weekRow: {
    flexDirection: 'row',
  },
  weekday: {
    width: '14.2857%',
    textAlign: 'center',
    ...typography.caption,
    color: colors.textMuted,
    fontWeight: '700',
  },
  daysGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  dayCell: {
    width: '14.2857%',
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dayInner: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  daySelected: {
    backgroundColor: colors.primary,
  },
  dayToday: {
    borderWidth: 1,
    borderColor: colors.primary,
  },
  dayText: {
    ...typography.small,
    color: colors.text,
  },
  dayTextSelected: {
    color: colors.onPrimary,
    fontWeight: '800',
  },
  dayTextDisabled: {
    color: colors.textMuted,
    opacity: 0.4,
  },
  todayBtn: {
    marginTop: spacing.sm,
    alignSelf: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    backgroundColor: colors.primarySoft,
  },
  todayText: {
    ...typography.small,
    color: colors.primary,
    fontWeight: '700',
  },
});
