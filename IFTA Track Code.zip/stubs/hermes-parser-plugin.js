// Powered by OnSpace.AI
//
// Support module for OnSpace's patched Hermes/Babel parsing pipeline.
//
// WHY THIS FILE EXISTS (each failure mode below has been observed and defines
// the contract this stub must satisfy):
//   1) File MISSING ->
//        "Cannot find module '<project>/stubs/hermes-parser-plugin.js'"
//      OnSpace patches @expo/metro-config's transformSync (and/or
//      babel-plugin-syntax-hermes-parser) to require() this file, so it MUST
//      exist.
//   2) File present but NO global `parseWithBabel` ->
//        "parseWithBabel is not defined" (bundling e.g. expo-router/entry.js)
//      The patched code references `parseWithBabel` (and `parseWithHermes`) as
//      FREE identifiers, which only resolve via global scope. Requiring THIS
//      module must install `globalThis.parseWithBabel` / `parseWithHermes`.
//   3) Global present but returning the WRONG SHAPE ->
//        "path missing or not a program node" (web bundling entry.js)
//      This is the important one. `parseWithBabel` is NOT a bare parser: in
//      @expo/metro-config/src/transformSync.ts it is:
//          parseWithBabel(src, babelConfig)  => babel.transformSync(src, cfg)
//          parseWithHermes(src, babelConfig) =>
//              babel.transformFromAstSync(hermesParse(src), src, cfg)
//      i.e. they return a FULL Babel transform result `{ ast, code, map,
//      metadata }`. babel-transformer.ts then does `assert(result.ast)`. A bare
//      `@babel/parser` File node has no `.ast`, so downstream code feeds an
//      undefined/File where a Program is expected -> "path missing or not a
//      program node". This stub therefore mirrors Expo's implementations EXACTLY.
//
// EXPORTS: the fallback plugin (module export + `.default`) AND named
//   `parseWithBabel` / `parseWithHermes`, so every consumption pattern the patch
//   might use is satisfied — not only the global side effect.

'use strict';

const path = require('path');

function resolveFrom(request, fromDirs) {
  for (const dir of fromDirs) {
    if (!dir) continue;
    try {
      return require.resolve(request, { paths: [dir] });
    } catch {
      // try the next anchor
    }
  }
  return null;
}

// Anchor directories used to resolve babel/hermes packages under pnpm's nested
// node_modules (a plain require from this file can miss them).
function anchorDirs() {
  const anchors = [__dirname, process.cwd()];
  try {
    anchors.push(
      path.dirname(
        require.resolve('babel-preset-expo/package.json', { paths: anchors }),
      ),
    );
  } catch {
    // babel-preset-expo not reachable — other anchors still apply
  }
  return anchors;
}

// --- @babel/core (the engine behind parseWithBabel / parseWithHermes) --------
let _babelCore;
function loadBabelCore() {
  if (_babelCore !== undefined) return _babelCore;
  try {
    _babelCore = require('@babel/core');
    return _babelCore;
  } catch {
    // fall through to anchored resolution
  }
  const entry = resolveFrom('@babel/core', anchorDirs());
  try {
    _babelCore = entry ? require(entry) : null;
  } catch {
    _babelCore = null;
  }
  return _babelCore;
}

// --- @babel/parser (only for the recursion-safe fallback below) --------------
let _babelParser;
function loadBabelParser() {
  if (_babelParser !== undefined) return _babelParser;
  try {
    _babelParser = require('@babel/parser');
    return _babelParser;
  } catch {
    // fall through to anchored resolution
  }
  // Prefer the copy that ships with @babel/core so the AST matches @babel/traverse.
  const anchors = anchorDirs();
  const coreEntry = resolveFrom('@babel/core/package.json', anchors);
  if (coreEntry) anchors.unshift(path.dirname(coreEntry));
  const entry = resolveFrom('@babel/parser', anchors);
  try {
    _babelParser = entry ? require(entry) : null;
  } catch {
    _babelParser = null;
  }
  return _babelParser;
}

// --- hermes-parser (pnpm-safe, lazy) -----------------------------------------
let _hermes;
let _hermesResolved = false;
function loadHermesParser() {
  if (_hermesResolved) return _hermes;
  _hermesResolved = true;
  try {
    _hermes = require('hermes-parser');
    return _hermes;
  } catch {
    // fall through to anchored resolution
  }
  const anchors = anchorDirs();
  const pluginPkg = resolveFrom(
    'babel-plugin-syntax-hermes-parser/package.json',
    anchors,
  );
  if (pluginPkg) anchors.unshift(path.dirname(pluginPkg));
  const hermesEntry = resolveFrom('hermes-parser', anchors);
  try {
    _hermes = hermesEntry ? require(hermesEntry) : null;
  } catch {
    _hermes = null;
  }
  return _hermes;
}

// Recursion-safe fallback: a plain Babel File AST (a valid parserOverride
// return). Used only when @babel/core is unavailable or when parseWithBabel is
// re-entered from a parserOverride while the transform below is running (calling
// babel.transformSync again there would recurse forever).
function rawParse(src, babelConfig) {
  const parser = loadBabelParser();
  if (!parser || typeof parser.parse !== 'function') {
    throw new Error('hermes-parser-plugin stub: @babel/parser is unavailable');
  }
  const sourceType = (babelConfig && babelConfig.sourceType) || 'unambiguous';
  const attempts = [
    { sourceType, plugins: ['typescript', 'jsx'] },
    { sourceType, plugins: ['flow', 'jsx'] },
    { sourceType, plugins: ['jsx'] },
  ];
  let lastErr;
  for (const opts of attempts) {
    try {
      return parser.parse(src, opts);
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error('hermes-parser-plugin stub: rawParse failed');
}

// Mirrors @expo/metro-config/src/transformSync.ts `parseWithBabel`:
//   return babel.transformSync(src, babelConfig)   // -> { ast, code, map, ... }
let _depth = 0;
function parseWithBabel(src, babelConfig) {
  const babel = loadBabelCore();
  if (!babel || typeof babel.transformSync !== 'function') {
    return rawParse(src, babelConfig);
  }
  if (_depth > 0) {
    // Re-entrant (a parserOverride called us during the transform below).
    return rawParse(src, babelConfig);
  }
  _depth++;
  try {
    return babel.transformSync(
      src,
      babelConfig || { ast: true, code: false, sourceType: 'unambiguous' },
    );
  } finally {
    _depth--;
  }
}

// Mirrors @expo/metro-config/src/transformSync.ts `parseWithHermes`:
//   const ast = hermesParser.parse(src, { babel: true, reactRuntimeTarget: '19', sourceType });
//   return babel.transformFromAstSync(ast, src, babelConfig);
function parseWithHermes(src, babelConfig) {
  const babel = loadBabelCore();
  const Hermes = loadHermesParser();
  if (!babel || !Hermes || typeof Hermes.parse !== 'function') {
    return parseWithBabel(src, babelConfig);
  }
  let sourceAst;
  try {
    sourceAst = Hermes.parse(src, {
      babel: true,
      reactRuntimeTarget: '19',
      sourceType: babelConfig && babelConfig.sourceType,
    });
  } catch {
    // Hermes cannot parse some ecosystem syntax (comments, export-default-from);
    // fall back to Babel just like a normal non-flow file.
    return parseWithBabel(src, babelConfig);
  }
  return babel.transformFromAstSync(
    sourceAst,
    src,
    babelConfig || { ast: true, code: false, sourceType: 'unambiguous' },
  );
}

// CRITICAL SIDE EFFECT: install the globals the patched pipeline references as
// free identifiers. Requiring this module is what makes `parseWithBabel(...)` /
// `parseWithHermes(...)` resolve with the correct Expo-compatible return shape.
try {
  const g =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof global !== 'undefined'
        ? global
        : null;
  if (g) {
    g.parseWithBabel = parseWithBabel;
    g.parseWithHermes = parseWithHermes;
  }
} catch {
  // never let installing the globals throw
}

// Faithful fallback reimplementation of babel-plugin-syntax-hermes-parser, only
// used if the patch consumes this module as a WHOLE-PLUGIN redirect. It defaults
// to parseLangTypes: 'flow' (NOT 'all') so ONLY files carrying an `@flow` pragma
// are routed through hermes-parser; everything else (e.g. expo-router/entry.js)
// falls through to Babel's own parser. Running hermes-parser on non-flow files
// is what produced "path missing or not a program node".
function BabelPluginSyntaxHermesParser(api, options) {
  if (api && typeof api.assertVersion === 'function') {
    try {
      api.assertVersion('^7.0.0 || ^8.0.0-alpha.6');
    } catch {
      // best-effort; never crash the preset over a version assertion
    }
  }

  const opts = options || {};
  const parseLangTypes = opts.parseLangTypes || 'flow';

  let curParserOpts = {};
  let curFilename = null;

  return {
    name: 'syntax-hermes-parser',

    manipulateOptions(o) {
      curParserOpts = (o && o.parserOpts) || {};
      curFilename = o ? o.filename : null;
    },

    // Return an AST to override Babel's parser, or undefined to let Babel parse.
    parserOverride(code) {
      const filename = curFilename;
      if (
        filename != null &&
        (filename.endsWith('.ts') || filename.endsWith('.tsx'))
      ) {
        return undefined;
      }
      if (parseLangTypes === 'flow' && !/@flow/.test(code)) {
        return undefined;
      }

      const Hermes = loadHermesParser();
      if (!Hermes || typeof Hermes.parse !== 'function') {
        return undefined;
      }

      const parserOpts = {};
      const keys = Hermes.ParserOptionsKeys;
      for (const key of Object.keys(curParserOpts)) {
        if (!keys || keys.has(key)) parserOpts[key] = curParserOpts[key];
      }

      try {
        return Hermes.parse(code, Object.assign({}, parserOpts, { babel: true }));
      } catch {
        return undefined;
      }
    },

    pre() {
      curParserOpts = {};
    },
  };
}

// Export the fallback plugin (module export + `.default` for ESM interop) plus
// the named parse helpers, covering every way the patch might consume this file.
module.exports = BabelPluginSyntaxHermesParser;
module.exports.default = BabelPluginSyntaxHermesParser;
module.exports.parseWithBabel = parseWithBabel;
module.exports.parseWithHermes = parseWithHermes;
Object.defineProperty(module.exports, '__esModule', { value: true });
