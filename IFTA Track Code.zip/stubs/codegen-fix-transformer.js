// Powered by OnSpace.AI
//
// Custom Metro Babel transformer that fixes the Android/iOS bundling failure:
//
//     SyntaxError: .../react-native-safe-area-context/src/specs/NativeSafeAreaView.ts:
//       Could not find component config for native component
//         at throwIfConfigNotfound (@react-native/codegen@0.79.0-rc.4/.../error-utils.js)
//         at findComponentConfig   (@react-native/codegen@0.79.0-rc.4/.../parsers-commons.js)
//
// ROOT CAUSE
// ----------
// `@react-native/babel-plugin-codegen` (loaded by babel-preset-expo -> @react-
// native/babel-preset, and run by Metro during bundling) resolved its OWN nested
// copy of `@react-native/codegen` to the PRERELEASE 0.79.0-rc.4. That release
// candidate's parser throws on perfectly valid `codegenNativeComponent<Props>()`
// specs (react-native-safe-area-context / react-native-screens), so the bundle
// aborts. react-native@0.79.6 pins the matching STABLE @react-native/codegen,
// whose parser reads those same specs correctly.
//
// WHY A TRANSFORMER (and not a pnpm override / .pnpmfile.cjs / workspace override)
// -------------------------------------------------------------------------------
// The build server does NOT honor the repo-level pnpm version pins for this
// transitive package: there is no committed lockfile (so it re-resolves every
// build), react-native@0.79.6 proves a stable @react-native/codegen exists, yet
// the override to that stable line never changed the resolved rc.4. The only
// reliably-honored version pin is package.json's `pnpm.overrides`, and that file
// is protected. So the fix is applied where the build server DOES execute our
// code: the Metro Babel transform step.
//
// WHAT IT DOES
// ------------
// Before delegating to Expo's real Babel transformer, it patches Node module
// resolution so every `require('@react-native/codegen')` (the require made by
// @react-native/babel-plugin-codegen while Metro transforms the spec files)
// resolves to the copy `react-native` itself depends on — the STABLE version
// that matches react-native@0.79.6 — instead of the stray broken rc.4.
//
// SAFETY: if react-native's copy cannot be located for any reason, resolution
// falls through to the default behavior unchanged, so this can only fix the
// build or be a no-op — it never makes bundling worse.

'use strict';

const Module = require('module');
const path = require('path');

const CODEGEN = '@react-native/codegen';

(function patchCodegenResolution() {
  const original = Module._resolveFilename;
  // Guard against double-patching if this module is required more than once.
  if (original.__onspaceCodegenPatched) return;

  let rnDir = null;
  try {
    // react-native pins @react-native/codegen to the stable matching version,
    // so resolving the request from react-native's directory yields the correct
    // parser rather than the rc.4 nested under babel-plugin-codegen.
    rnDir = path.dirname(require.resolve('react-native/package.json'));
  } catch {
    rnDir = null; // fall back to default resolution everywhere
  }

  function patched(request, parent, isMain, options) {
    if (rnDir && (request === CODEGEN || request.startsWith(CODEGEN + '/'))) {
      try {
        return original.call(this, request, parent, isMain, {
          ...(options || {}),
          paths: [rnDir, ...((options && options.paths) || [])],
        });
      } catch {
        // Could not resolve from react-native — use the normal resolution.
      }
    }
    return original.call(this, request, parent, isMain, options);
  }

  patched.__onspaceCodegenPatched = true;
  Module._resolveFilename = patched;
})();

// Delegate to Expo's real Babel transformer (the one getDefaultConfig wires up).
// Multiple require targets cover Expo SDK version differences; the SDK 53 path
// is the first.
let upstream;
try {
  upstream = require('@expo/metro-config/build/babel-transformer');
} catch (e1) {
  try {
    upstream = require('@expo/metro-config/babel-transformer');
  } catch (e2) {
    upstream = require('metro-react-native-babel-transformer');
  }
}

module.exports = upstream;
