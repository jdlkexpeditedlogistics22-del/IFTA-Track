// Thin wrapper around expo-location for precise GPS tracking,
// including background location updates via expo-task-manager.
//
// IMPORTANT: expo-location is loaded LAZILY and is NEVER evaluated at module /
// boot time. A top-level `import * as Location from 'expo-location'` pulls
// expo-modules-core into the boot + web/node (SSR) render graph, which can
// crash the render when the bundler resolves a mismatched expo-modules-core
// ("requireOptionalNativeModule is not a function"). Requiring it on first use
// keeps the boot path free of native modules and lets Metro resolve the correct
// build on demand.

import { Platform } from 'react-native';
import type * as LocationNS from 'expo-location';
import { resolveStateFromAddress } from '@/constants/states';

// Registered in services/backgroundLocationTask.ts via TaskManager.defineTask.
export const BG_LOCATION_TASK = 'miletrack-background-location';

export type Sample = {
  latitude: number;
  longitude: number;
  speed: number | null; // meters/second
  accuracy: number | null; // meters
  timestamp: number;
};

// Lazy expo-location accessor — the native module is required only when a
// location API is actually invoked, never during app boot or SSR render.
let _location: typeof LocationNS | null = null;
function getLocation(): typeof LocationNS {
  if (!_location) {
    _location = require('expo-location');
  }
  return _location;
}

// Detect the Expo Go / preview client WITHOUT a static expo-constants import.
// A top-level `import ... from 'expo-constants'` can fail to bundle when a
// mismatched expo-modules-core is resolved ("requireOptionalNativeModule is
// not a function"), so we require it lazily, only on native, and default
// safely if it is unavailable.
let expoGoResolved = false;
let expoGoCached = false;

function isExpoGoClient(): boolean {
  if (Platform.OS === 'web') return false;
  if (expoGoResolved) return expoGoCached;
  expoGoResolved = true;
  try {
    const mod = require('expo-constants');
    const ConstantsMod = mod.default ?? mod;
    const StoreClient = mod.ExecutionEnvironment?.StoreClient;
    expoGoCached =
      !!StoreClient && ConstantsMod?.executionEnvironment === StoreClient;
  } catch {
    expoGoCached = false;
  }
  return expoGoCached;
}

// Background location updates + the Android foreground service require a
// development or standalone build. In Expo Go / the preview client (and on
// web) they are unavailable, and invoking them can crash the app. Detect that
// environment so callers can fall back to a foreground watch instead.
export function supportsBackgroundLocation(): boolean {
  if (Platform.OS === 'web') return false;
  return !isExpoGoClient();
}

// --- Permissions ---------------------------------------------------------

export async function requestForegroundPermission(): Promise<boolean> {
  // On web, requestForegroundPermissionsAsync only reads the Permissions API
  // state and never shows a prompt. The browser prompt is triggered ONLY by a
  // live position read, so on web we do that instead.
  if (Platform.OS === 'web') {
    const Location = getLocation();
    try {
      const current = await Location.getForegroundPermissionsAsync();
      if (current.status === 'granted') return true;
    } catch {
      // fall through to a live read
    }
    try {
      await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      return true;
    } catch {
      return false;
    }
  }
  try {
    const { status } = await getLocation().requestForegroundPermissionsAsync();
    return status === 'granted';
  } catch {
    return false;
  }
}

export async function requestBackgroundPermission(): Promise<boolean> {
  if (!supportsBackgroundLocation()) return false;
  try {
    const { status } = await getLocation().requestBackgroundPermissionsAsync();
    return status === 'granted';
  } catch {
    return false;
  }
}

export async function hasForegroundPermission(): Promise<boolean> {
  try {
    const { status } = await getLocation().getForegroundPermissionsAsync();
    return status === 'granted';
  } catch {
    return false;
  }
}

export async function hasBackgroundPermission(): Promise<boolean> {
  if (!supportsBackgroundLocation()) return false;
  try {
    const { status } = await getLocation().getBackgroundPermissionsAsync();
    return status === 'granted';
  } catch {
    return false;
  }
}

// Backward-compatible alias (foreground permission).
export async function requestPermission(): Promise<boolean> {
  return requestForegroundPermission();
}

// --- Geocoding -----------------------------------------------------------

// Race a promise against a timeout. Reverse-geocoding is a NETWORK call, and a
// slow/hanging response inside the background location handler can blow past the
// OS background-execution budget and cause iOS to throttle or stop delivering
// updates — which shows up as "not recording in the background". Capping it lets
// distance keep accumulating (miles just fall under "Unknown" until the next
// successful lookup) instead of ever stalling the handler.
function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      },
    );
  });
}

export async function getCurrentStateCode(
  latitude: number,
  longitude: number,
): Promise<string | null> {
  try {
    const results = await withTimeout(
      getLocation().reverseGeocodeAsync({ latitude, longitude }),
      6000,
    );
    if (!results || results.length === 0) return null;
    // The state is not always in results[0].region: it can be null there and
    // present in a later result, in subregion, or embedded in the formatted
    // address. Check every field of every returned result before giving up.
    for (const result of results) {
      const code = resolveStateFromAddress(result as Record<string, any>);
      if (code) return code;
    }
    return null;
  } catch {
    return null;
  }
}

export type DetectedLocation = {
  latitude: number;
  longitude: number;
  stateCode: string | null;
};

// One-shot read: resolve the device's CURRENT position to coordinates + a US
// state code from a SINGLE GPS fix. Used by the fuel-entry screen to auto-fill
// both the purchase jurisdiction and the nearest truck stop. Ensures foreground
// permission first (prompting only if needed), takes one fix, then reverse-
// geocodes it. Returns null on any failure so callers can fall back to manual
// entry.
export async function detectCurrentLocation(): Promise<DetectedLocation | null> {
  try {
    const granted = await hasForegroundPermission();
    if (!granted) {
      const ok = await requestForegroundPermission();
      if (!ok) return null;
    }
    const Location = getLocation();
    const pos = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.Balanced,
    });
    const stateCode = await getCurrentStateCode(
      pos.coords.latitude,
      pos.coords.longitude,
    );
    return {
      latitude: pos.coords.latitude,
      longitude: pos.coords.longitude,
      stateCode,
    };
  } catch {
    return null;
  }
}

// One-shot read: resolve the device's CURRENT position to a US state code.
// Thin wrapper over detectCurrentLocation for callers that only need the state.
export async function detectCurrentStateCode(): Promise<string | null> {
  const loc = await detectCurrentLocation();
  return loc?.stateCode ?? null;
}

// --- Foreground watch (used on web + as a fallback) ----------------------

export async function startWatch(
  onSample: (sample: Sample) => void,
): Promise<LocationNS.LocationSubscription> {
  const Location = getLocation();
  return Location.watchPositionAsync(
    {
      accuracy: Location.Accuracy.BestForNavigation,
      // Sample often / at short spacing so the straight-line chords between
      // fixes hug curves closely and undercount less (see PATH_CORRECTION).
      timeInterval: 1000,
      distanceInterval: 4,
    },
    (loc) =>
      onSample({
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
        speed: loc.coords.speed,
        accuracy: loc.coords.accuracy,
        timestamp: loc.timestamp,
      }),
  );
}

// --- Background updates ---------------------------------------------------

export async function hasBackgroundStarted(): Promise<boolean> {
  if (!supportsBackgroundLocation()) return false;
  try {
    return await getLocation().hasStartedLocationUpdatesAsync(BG_LOCATION_TASK);
  } catch {
    return false;
  }
}

export async function startBackgroundUpdates(): Promise<void> {
  if (!supportsBackgroundLocation()) throw new Error('background-unsupported');
  // Register the headless task lazily (guarded) so expo-task-manager is never
  // evaluated during app boot — only here, in a build that actually supports it.
  const registered: boolean =
    require('./backgroundLocationTask').registerBackgroundLocationTask();
  if (!registered) throw new Error('background-unsupported');
  if (await hasBackgroundStarted()) return;
  const Location = getLocation();
  await Location.startLocationUpdatesAsync(BG_LOCATION_TASK, {
    accuracy: Location.Accuracy.BestForNavigation,
    // Tighter spacing than before (was 3000ms / 8m) so background chords also
    // track curves closely and lose less distance to sampling gaps.
    timeInterval: 2000,
    distanceInterval: 5,
    // Never let the OS batch/defer background fixes: deferral delays delivery
    // and lets long straight-line gaps form between fixes, which undercounts
    // miles. Deliver each fix as it arrives so accumulation stays continuous
    // while the app is minimized.
    deferredUpdatesInterval: 0,
    deferredUpdatesDistance: 0,
    pausesUpdatesAutomatically: false,
    activityType: Location.ActivityType.AutomotiveNavigation,
    showsBackgroundLocationIndicator: true,
    foregroundService: {
      notificationTitle: 'IFTA-Track is recording',
      notificationBody: 'Recording mileage by state while you drive.',
      notificationColor: '#F5A623',
    },
  });
}

export async function stopBackgroundUpdates(): Promise<void> {
  if (!supportsBackgroundLocation()) return;
  try {
    if (await hasBackgroundStarted()) {
      await getLocation().stopLocationUpdatesAsync(BG_LOCATION_TASK);
    }
  } catch {
    // ignore
  }
}
