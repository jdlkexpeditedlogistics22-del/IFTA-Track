// Local persistence for trips and fuel purchases (on-device only)

import AsyncStorage from '@react-native-async-storage/async-storage';
import { DefPurchase, FuelPurchase, Trip } from '@/services/types';

const KEY = '@miletrack/trips';
const FUEL_KEY = '@miletrack/fuel';
const DEF_KEY = '@miletrack/def';

export async function loadTrips(): Promise<Trip[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Trip[]) : [];
  } catch {
    return [];
  }
}

export async function saveTrips(trips: Trip[]): Promise<void> {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(trips));
  } catch {
    // ignore write errors silently
  }
}

export async function loadFuel(): Promise<FuelPurchase[]> {
  try {
    const raw = await AsyncStorage.getItem(FUEL_KEY);
    return raw ? (JSON.parse(raw) as FuelPurchase[]) : [];
  } catch {
    return [];
  }
}

export async function saveFuel(fuel: FuelPurchase[]): Promise<void> {
  try {
    await AsyncStorage.setItem(FUEL_KEY, JSON.stringify(fuel));
  } catch {
    // ignore write errors silently
  }
}

// --- Diesel Exhaust Fluid (DEF) purchases (tracked separately from fuel) ---

export async function loadDef(): Promise<DefPurchase[]> {
  try {
    const raw = await AsyncStorage.getItem(DEF_KEY);
    return raw ? (JSON.parse(raw) as DefPurchase[]) : [];
  } catch {
    return [];
  }
}

export async function saveDef(def: DefPurchase[]): Promise<void> {
  try {
    await AsyncStorage.setItem(DEF_KEY, JSON.stringify(def));
  } catch {
    // ignore write errors silently
  }
}

// --- Backup schedule metadata (for the automatic 45-day backup) ----------

const BACKUP_META_KEY = '@miletrack/backupMeta';

export type BackupMeta = {
  firstBackupAt: number | null; // when the first manual backup happened
  lastBackupAt: number | null; // most recent successful backup (any method)
  lastMethod: 'manual' | 'auto' | null;
};

const EMPTY_BACKUP_META: BackupMeta = {
  firstBackupAt: null,
  lastBackupAt: null,
  lastMethod: null,
};

export async function loadBackupMeta(): Promise<BackupMeta> {
  try {
    const raw = await AsyncStorage.getItem(BACKUP_META_KEY);
    if (!raw) return { ...EMPTY_BACKUP_META };
    const parsed = JSON.parse(raw) as Partial<BackupMeta>;
    return {
      firstBackupAt:
        typeof parsed.firstBackupAt === 'number' ? parsed.firstBackupAt : null,
      lastBackupAt:
        typeof parsed.lastBackupAt === 'number' ? parsed.lastBackupAt : null,
      lastMethod:
        parsed.lastMethod === 'manual' || parsed.lastMethod === 'auto'
          ? parsed.lastMethod
          : null,
    };
  } catch {
    return { ...EMPTY_BACKUP_META };
  }
}

export async function saveBackupMeta(meta: BackupMeta): Promise<void> {
  try {
    await AsyncStorage.setItem(BACKUP_META_KEY, JSON.stringify(meta));
  } catch {
    // ignore write errors silently
  }
}

// --- Recording activity (foreground vs background last-recorded times) ----
//
// Records WHEN mileage was last actually banked from each feed so the driver
// can confirm on the Settings screen that locked-drive (background) recording
// is working, distinct from foreground (app-open) recording.

const RECORD_ACTIVITY_KEY = '@miletrack/recordActivity';

export type RecordActivity = {
  foregroundAt: number | null; // last time miles banked while the app was open
  backgroundAt: number | null; // last time miles banked while the screen locked
};

const EMPTY_RECORD_ACTIVITY: RecordActivity = {
  foregroundAt: null,
  backgroundAt: null,
};

export async function loadRecordActivity(): Promise<RecordActivity> {
  try {
    const raw = await AsyncStorage.getItem(RECORD_ACTIVITY_KEY);
    if (!raw) return { ...EMPTY_RECORD_ACTIVITY };
    const parsed = JSON.parse(raw) as Partial<RecordActivity>;
    return {
      foregroundAt:
        typeof parsed.foregroundAt === 'number' ? parsed.foregroundAt : null,
      backgroundAt:
        typeof parsed.backgroundAt === 'number' ? parsed.backgroundAt : null,
    };
  } catch {
    return { ...EMPTY_RECORD_ACTIVITY };
  }
}

export async function saveRecordActivity(
  activity: RecordActivity,
): Promise<void> {
  try {
    await AsyncStorage.setItem(RECORD_ACTIVITY_KEY, JSON.stringify(activity));
  } catch {
    // ignore write errors silently
  }
}

// --- Recent vendor / station names (MRU for the fuel-entry quick picks) ---

const RECENT_VENDORS_KEY = '@miletrack/recentVendors';
export const MAX_RECENT_VENDORS = 5;

export async function loadRecentVendors(): Promise<string[]> {
  try {
    const raw = await AsyncStorage.getItem(RECENT_VENDORS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((v): v is string => typeof v === 'string' && v.trim() !== '')
      .slice(0, MAX_RECENT_VENDORS);
  } catch {
    return [];
  }
}

export async function saveRecentVendors(vendors: string[]): Promise<void> {
  try {
    await AsyncStorage.setItem(RECENT_VENDORS_KEY, JSON.stringify(vendors));
  } catch {
    // ignore write errors silently
  }
}

// --- Keep-screen-awake preference (prevent auto-lock while using the app) ---

const KEEP_AWAKE_KEY = '@miletrack/keepAwake';

export async function loadKeepAwake(): Promise<boolean> {
  try {
    const raw = await AsyncStorage.getItem(KEEP_AWAKE_KEY);
    return raw === 'true';
  } catch {
    return false;
  }
}

export async function saveKeepAwake(enabled: boolean): Promise<void> {
  try {
    await AsyncStorage.setItem(KEEP_AWAKE_KEY, enabled ? 'true' : 'false');
  } catch {
    // ignore write errors silently
  }
}

// Move a vendor to the front of the most-recently-used list (case-insensitive
// dedupe, keeping the newest label/casing) and cap at MAX_RECENT_VENDORS.
// Pure helper — safe to reuse anywhere the list needs updating.
export function mergeRecentVendor(
  existing: string[],
  vendor: string,
): string[] {
  const trimmed = vendor.trim();
  if (!trimmed) return existing;
  const lower = trimmed.toLowerCase();
  const rest = existing.filter((v) => v.trim().toLowerCase() !== lower);
  return [trimmed, ...rest].slice(0, MAX_RECENT_VENDORS);
}
