// Defines the background location task so mileage keeps recording while the app
// is minimized, on builds that support background location.
//
// REGISTRATION IS LAZY — NEVER at app boot. Importing / evaluating
// expo-task-manager on the boot path crashes the app on launch: the Expo Router
// route tree build fails ("Cannot read property 'prototype'/'ErrorBoundary' of
// undefined" on Android) and the app fails to load on iOS. So
// TaskManager.defineTask runs only the first time background updates actually
// start (locationService.startBackgroundUpdates), which happens in the
// foreground after boot. Expo Go / the preview client and web never reach it.
//
// GUARDS: skipped on web (expo-task-manager throws at load there) and wrapped in
// try/catch so any native incompatibility falls back to a foreground watch
// instead of crashing.

import { Platform } from 'react-native';
import type * as LocationTypes from 'expo-location';
import { BG_LOCATION_TASK, Sample } from '@/services/locationService';
import { ingestSamples } from '@/services/sessionService';

let ready = false;

function register(): boolean {
  if (Platform.OS === 'web') return false;
  if (ready) return true;
  try {
    const TaskManager: typeof import('expo-task-manager') = require('expo-task-manager');

    TaskManager.defineTask(BG_LOCATION_TASK, async ({ data, error }) => {
      if (error) return;
      const locations = (
        data as { locations?: LocationTypes.LocationObject[] } | undefined
      )?.locations;
      if (!locations || locations.length === 0) return;

      const samples: Sample[] = locations.map((l) => ({
        latitude: l.coords.latitude,
        longitude: l.coords.longitude,
        speed: l.coords.speed,
        accuracy: l.coords.accuracy,
        timestamp: l.timestamp,
      }));

      try {
        await ingestSamples(samples, 'background');
      } catch {
        // Never throw from a background task.
      }
    });

    ready = true;
    return true;
  } catch {
    // expo-task-manager is unavailable/incompatible in this environment.
    return false;
  }
}

// Idempotent, LAZY accessor. Called by locationService.startBackgroundUpdates on
// first use (in the foreground, after boot) — NOT as a boot-time side effect —
// so expo-task-manager is never evaluated during the route-tree build.
export function registerBackgroundLocationTask(): boolean {
  return register();
}

export function isBackgroundTaskReady(): boolean {
  return ready;
}
