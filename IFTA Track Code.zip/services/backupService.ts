// Powered by OnSpace.AI
// Backup & restore of on-device app data (trips + fuel purchases).
// A backup is a single JSON file the user can save/share and later re-import.
// Native uses expo-file-system + expo-sharing (write/share) and
// expo-document-picker (pick to restore); web falls back to a Blob download
// and a fetch() read of the picked file.
//
// IMPORTANT: expo-file-system / expo-sharing / expo-document-picker are loaded
// LAZILY and are NEVER evaluated at module / route-load time. A top-level
// `import * as X from 'expo-...'` pulls these native modules (and
// expo-modules-core) into the route graph; when a mismatched expo-modules-core
// / New Architecture build resolves an undefined native binding, evaluating
// them throws "undefined is not a function" and crashes the whole screen while
// the router lazily loads the Settings tab. Requiring them on first use keeps
// route loading crash-free and only touches the native module when backup or
// restore actually runs.

import { Platform } from 'react-native';
import {
  BackupMeta,
  loadBackupMeta,
  loadFuel,
  loadTrips,
  saveBackupMeta,
  saveFuel,
  saveTrips,
} from '@/services/storageService';
import { FuelPurchase, Trip } from '@/services/types';

// --- Lazy native-module accessors (required only on backup/restore) ------

let _fs: typeof import('expo-file-system') | null = null;
function fs(): typeof import('expo-file-system') {
  if (!_fs) _fs = require('expo-file-system');
  return _fs;
}

let _sharing: typeof import('expo-sharing') | null = null;
function sharing(): typeof import('expo-sharing') {
  if (!_sharing) _sharing = require('expo-sharing');
  return _sharing;
}

let _picker: typeof import('expo-document-picker') | null = null;
function picker(): typeof import('expo-document-picker') {
  if (!_picker) _picker = require('expo-document-picker');
  return _picker;
}

const APP_NAME = 'IFTA-Track';
const BACKUP_TYPE = 'ifta-track-backup';
const BACKUP_VERSION = 2;

export type BackupData = {
  app: string;
  type: string;
  version: number;
  createdAt: number;
  trips: Trip[];
  fuel: FuelPurchase[];
};

export type RestoreMode = 'replace' | 'merge';

export type BackupResult = {
  ok: boolean;
  shared?: boolean;
  reason?: 'empty' | 'unavailable' | 'error';
  counts?: { trips: number; fuel: number };
  // Real underlying failure message (native write / directory error). Surfaced
  // to the user so a silent "nothing saved" no longer hides the actual cause.
  error?: string;
};

export type PickResult =
  | { status: 'ok'; text: string }
  | { status: 'canceled' }
  | { status: 'error' };

// --- Validation ----------------------------------------------------------

function isValidTrip(t: any): t is Trip {
  return (
    !!t &&
    typeof t.id === 'string' &&
    typeof t.startedAt === 'number' &&
    typeof t.miles === 'number' &&
    !!t.stateMiles &&
    typeof t.stateMiles === 'object'
  );
}

function isValidFuel(f: any): f is FuelPurchase {
  return (
    !!f &&
    typeof f.id === 'string' &&
    typeof f.date === 'number' &&
    typeof f.stateCode === 'string' &&
    typeof f.gallons === 'number' &&
    typeof f.amount === 'number'
  );
}

// --- Build / serialize ---------------------------------------------------

export async function buildBackup(): Promise<BackupData> {
  const [trips, fuel] = await Promise.all([loadTrips(), loadFuel()]);
  return {
    app: APP_NAME,
    type: BACKUP_TYPE,
    version: BACKUP_VERSION,
    createdAt: Date.now(),
    trips,
    fuel,
  };
}

export const BACKUP_FOLDER_NAME = 'IFTA Backup';

// Ensure the persistent "IFTA Backup" folder (and every parent directory in its
// path) exists, CREATING it if missing, and return the folder URI. Native only.
//
// WHY THIS EXISTS
// ---------------
// Backups previously called makeDirectoryAsync wrapped in a bare try/catch that
// swallowed EVERY error — so a genuine failure (missing parent directory, no
// document dir yet on a fresh install) was hidden and the following
// writeAsStringAsync then failed because the folder did not exist. This checks
// the folder with getInfoAsync first, creates it (with intermediates so parent
// directories are made too) only when absent, and verifies it exists before
// returning — throwing a clear error if the directory could not be created so
// the caller reports a real failure instead of silently losing the backup.
async function ensureBackupFolder(): Promise<string> {
  const FileSystem = fs();
  const base = FileSystem.documentDirectory || FileSystem.cacheDirectory;
  if (!base) throw new Error('no-writable-directory');
  const folder = `${base}${BACKUP_FOLDER_NAME}/`;

  let info = await FileSystem.getInfoAsync(folder);
  if (!info.exists) {
    // intermediates: true creates the full path, so any missing parent
    // directory is created as well, not just the leaf folder.
    await FileSystem.makeDirectoryAsync(folder, { intermediates: true });
    info = await FileSystem.getInfoAsync(folder);
  }
  if (!info.exists || !info.isDirectory) {
    throw new Error('backup-folder-unavailable');
  }
  return folder;
}

// Report whether the persistent "IFTA Backup" folder already exists, WITHOUT
// creating it. Lets the UI prompt the user to create it on the very first
// folder backup. Native only; web has no persistent named folder.
export async function backupFolderStatus(): Promise<{
  folder: string | null;
  exists: boolean;
}> {
  if (Platform.OS === 'web') return { folder: null, exists: false };
  try {
    const FileSystem = fs();
    const base = FileSystem.documentDirectory || FileSystem.cacheDirectory;
    if (!base) return { folder: null, exists: false };
    const folder = `${base}${BACKUP_FOLDER_NAME}/`;
    const info = await FileSystem.getInfoAsync(folder);
    return { folder, exists: !!info.exists && !!info.isDirectory };
  } catch {
    return { folder: null, exists: false };
  }
}

// Build a file URI inside `folder` that does NOT collide with an existing
// backup, so a new backup NEVER overwrites an earlier one. The name carries the
// full date+time; if two backups somehow land in the same second, a numeric
// suffix is appended until the name is free.
async function uniqueBackupUri(folder: string, ts: number): Promise<string> {
  const FileSystem = fs();
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  const stem = `ifta-track-backup-${y}-${m}-${day}-${hh}${mm}${ss}`;
  let uri = `${folder}${stem}.json`;
  let n = 1;
  // Guard against an unbounded loop while still finding a free name.
  while (n < 1000 && (await FileSystem.getInfoAsync(uri)).exists) {
    uri = `${folder}${stem}-${n}.json`;
    n += 1;
  }
  return uri;
}

// Keep only this many backup files in the persistent "IFTA Backup" folder.
// Older files beyond this count are pruned to save device space; the newest
// files are NEVER touched.
export const MAX_KEPT_BACKUPS = 10;

// Delete the oldest backups so only the `keep` most recent remain in the
// "IFTA Backup" folder. Newest-first ordering is by file modification time,
// with the timestamped filename as a stable tiebreaker (names sort
// chronologically). Never deletes anything when the folder holds `keep` or
// fewer backups, so the newest files are always safe. Native only; returns the
// number of files removed. Best-effort: any file that cannot be removed is
// skipped rather than aborting the prune.
export async function pruneOldBackups(keep = MAX_KEPT_BACKUPS): Promise<number> {
  if (Platform.OS === 'web') return 0;
  try {
    const FileSystem = fs();
    const status = await backupFolderStatus();
    if (!status.exists || !status.folder) return 0;
    const folder = status.folder;
    const names = (await FileSystem.readDirectoryAsync(folder)).filter(
      (n) => n.startsWith('ifta-track-backup-') && n.endsWith('.json'),
    );
    if (names.length <= keep) return 0;

    const withInfo = await Promise.all(
      names.map(async (name) => {
        const uri = `${folder}${name}`;
        const info = await FileSystem.getInfoAsync(uri);
        return {
          name,
          uri,
          mtime: info.exists ? info.modificationTime ?? 0 : 0,
        };
      }),
    );
    // Newest first: modification time, then filename (timestamped, so a later
    // name is a later backup) as a deterministic tiebreaker.
    withInfo.sort((a, b) => b.mtime - a.mtime || (a.name < b.name ? 1 : -1));

    const stale = withInfo.slice(keep);
    let deleted = 0;
    for (const f of stale) {
      try {
        await FileSystem.deleteAsync(f.uri, { idempotent: true });
        deleted += 1;
      } catch {
        // Leave a file that cannot be removed; never fail the whole prune.
      }
    }
    return deleted;
  } catch {
    return 0;
  }
}

function backupFileName(ts: number): string {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `ifta-track-backup-${y}-${m}-${day}.json`;
}

// Web-only: trigger a file download without touching DOM types directly.
function downloadOnWeb(content: string, fileName: string, mimeType: string): void {
  try {
    const g = globalThis as any;
    if (!g?.document || !g?.Blob || !g?.URL) return;
    const blob = new g.Blob([content], { type: mimeType });
    const url = g.URL.createObjectURL(blob);
    const a = g.document.createElement('a');
    a.href = url;
    a.download = fileName;
    g.document.body.appendChild(a);
    a.click();
    g.document.body.removeChild(a);
    g.URL.revokeObjectURL(url);
  } catch {
    // ignore
  }
}

// Create a backup file and hand it to the OS share sheet (native) or trigger a
// browser download (web).
export async function createBackup(): Promise<BackupResult> {
  const data = await buildBackup();
  const counts = {
    trips: data.trips.length,
    fuel: data.fuel.length,
  };
  if (counts.trips === 0 && counts.fuel === 0) {
    return { ok: false, reason: 'empty', counts };
  }

  const content = JSON.stringify(data, null, 2);
  const fileName = backupFileName(data.createdAt);
  const mimeType = 'application/json';

  if (Platform.OS === 'web') {
    downloadOnWeb(content, fileName, mimeType);
    return { ok: true, shared: true, counts };
  }

  try {
    const FileSystem = fs();
    const Sharing = sharing();
    const dir = FileSystem.cacheDirectory || FileSystem.documentDirectory;
    const fileUri = `${dir}${fileName}`;
    await FileSystem.writeAsStringAsync(fileUri, content);

    const available = await Sharing.isAvailableAsync();
    if (!available) {
      return { ok: true, shared: false, reason: 'unavailable', counts };
    }
    await Sharing.shareAsync(fileUri, {
      mimeType,
      dialogTitle: 'Save IFTA-Track backup',
      UTI: 'public.json',
    });
    return { ok: true, shared: true, counts };
  } catch {
    return { ok: false, reason: 'error', counts };
  }
}

// Save a backup file into a persistent "IFTA Backup" folder in the app's
// document directory (created on first use). Unlike createBackup this does not
// open the share sheet - the file stays on-device in a predictable folder. Web
// cannot create a persistent named folder, so it falls back to a download.
export async function saveBackupToFolder(): Promise<
  BackupResult & { path?: string }
> {
  const data = await buildBackup();
  const counts = { trips: data.trips.length, fuel: data.fuel.length };
  if (counts.trips === 0 && counts.fuel === 0) {
    return { ok: false, reason: 'empty', counts };
  }

  const content = JSON.stringify(data, null, 2);
  const fileName = backupFileName(data.createdAt);

  if (Platform.OS === 'web') {
    downloadOnWeb(content, fileName, 'application/json');
    return { ok: true, shared: true, counts };
  }

  try {
    const FileSystem = fs();
    const folder = await ensureBackupFolder();
    // Unique name so an existing backup in the folder is never overwritten.
    const fileUri = await uniqueBackupUri(folder, data.createdAt);
    await FileSystem.writeAsStringAsync(fileUri, content);
    // Verify the file actually landed on disk, so a silent no-op write is
    // reported as a failure instead of a false success.
    const verify = await FileSystem.getInfoAsync(fileUri);
    if (!verify.exists) throw new Error('write-verify-failed');
    // Keep the folder trimmed to the newest MAX_KEPT_BACKUPS files. The just-
    // written backup is the newest, so it is always retained.
    await pruneOldBackups();
    return { ok: true, shared: false, counts, path: fileUri };
  } catch (e: any) {
    return { ok: false, reason: 'error', counts, error: e?.message ?? String(e) };
  }
}

// --- Restore -------------------------------------------------------------

async function readFileText(uri: string): Promise<string> {
  if (Platform.OS === 'web') {
    const res = await fetch(uri);
    return res.text();
  }
  return fs().readAsStringAsync(uri);
}

// Prompt the user to pick a backup file and return its raw text.
export async function pickBackupText(): Promise<PickResult> {
  try {
    const res = await picker().getDocumentAsync({
      type: ['application/json', 'text/plain'],
      copyToCacheDirectory: true,
      multiple: false,
    });
    if (res.canceled) return { status: 'canceled' };
    const asset = res.assets?.[0];
    if (!asset?.uri) return { status: 'error' };

    const webFile = (asset as any).file;
    if (Platform.OS === 'web' && webFile?.text) {
      return { status: 'ok', text: await webFile.text() };
    }
    const text = await readFileText(asset.uri);
    return { status: 'ok', text };
  } catch {
    return { status: 'error' };
  }
}

// Validate + normalize raw backup text. Throws on unrecognized content.
export function parseBackup(text: string): BackupData {
  let raw: any;
  try {
    raw = JSON.parse(text);
  } catch {
    throw new Error('invalid-json');
  }
  if (!raw || typeof raw !== 'object') throw new Error('invalid-shape');
  if (!Array.isArray(raw.trips) && !Array.isArray(raw.fuel)) {
    throw new Error('not-a-backup');
  }
  const trips = Array.isArray(raw.trips) ? raw.trips.filter(isValidTrip) : [];
  const fuel = Array.isArray(raw.fuel) ? raw.fuel.filter(isValidFuel) : [];
  return {
    app: typeof raw.app === 'string' ? raw.app : APP_NAME,
    type: BACKUP_TYPE,
    version: typeof raw.version === 'number' ? raw.version : BACKUP_VERSION,
    createdAt: typeof raw.createdAt === 'number' ? raw.createdAt : Date.now(),
    trips,
    fuel,
  };
}

function mergeById<T extends { id: string }>(existing: T[], incoming: T[]): T[] {
  const map = new Map<string, T>();
  existing.forEach((e) => map.set(e.id, e));
  incoming.forEach((i) => {
    if (!map.has(i.id)) map.set(i.id, i);
  });
  return Array.from(map.values());
}

// Write restored data to storage. 'replace' overwrites everything; 'merge'
// keeps existing entries and adds any new ones from the backup (deduped by id).
export async function applyRestore(
  data: BackupData,
  mode: RestoreMode,
): Promise<{ trips: number; fuel: number }> {
  let trips = data.trips;
  let fuel = data.fuel;

  if (mode === 'merge') {
    const [curTrips, curFuel] = await Promise.all([loadTrips(), loadFuel()]);
    trips = mergeById(curTrips, data.trips);
    fuel = mergeById(curFuel, data.fuel);
  }

  trips = [...trips].sort((a, b) => b.startedAt - a.startedAt);
  fuel = [...fuel].sort((a, b) => b.date - a.date);

  await Promise.all([saveTrips(trips), saveFuel(fuel)]);
  return {
    trips: trips.length,
    fuel: fuel.length,
  };
}

// --- Automatic 45-day backup --------------------------------------------
// A copy of all data is written silently to the device every 45 days, anchored
// to the user's FIRST manual backup. This keeps an on-device safety net without
// the user having to remember. Schedule metadata is tracked in storage.

const DAY_MS = 24 * 60 * 60 * 1000;
export const AUTO_BACKUP_INTERVAL_DAYS = 45;
export const AUTO_BACKUP_INTERVAL_MS = AUTO_BACKUP_INTERVAL_DAYS * DAY_MS;

// The moment the next automatic backup should run, or null until the user has
// made their first manual backup. Recurs every 45 days from the most recent
// backup (manual or automatic).
export function nextAutoBackupAt(meta: BackupMeta): number | null {
  if (!meta.firstBackupAt) return null;
  const anchor = meta.lastBackupAt ?? meta.firstBackupAt;
  return anchor + AUTO_BACKUP_INTERVAL_MS;
}

export function isAutoBackupDue(meta: BackupMeta, now = Date.now()): boolean {
  const next = nextAutoBackupAt(meta);
  return next != null && now >= next;
}

// Record a successful backup. The first MANUAL backup seeds firstBackupAt,
// which arms the automatic schedule; automatic backups only advance lastBackupAt.
export async function recordBackup(
  method: 'manual' | 'auto',
  at = Date.now(),
): Promise<BackupMeta> {
  const meta = await loadBackupMeta();
  const next: BackupMeta = {
    firstBackupAt: meta.firstBackupAt ?? (method === 'manual' ? at : null),
    lastBackupAt: at,
    lastMethod: method,
  };
  await saveBackupMeta(next);
  return next;
}

// Silently write a dated backup file to the app's document directory. Unlike
// createBackup this never opens the share sheet - it is the on-device copy made
// by the automatic schedule. It writes into the SAME persistent "IFTA Backup"
// folder used by manual folder saves, so automatic and manual backups live
// together in one predictable location. Web cannot persist silently, so it
// reports unavailable and no backup is recorded.
export async function writeAutoBackup(): Promise<BackupResult> {
  const data = await buildBackup();
  const counts = { trips: data.trips.length, fuel: data.fuel.length };
  if (counts.trips === 0 && counts.fuel === 0) {
    return { ok: false, reason: 'empty', counts };
  }
  if (Platform.OS === 'web') {
    return { ok: false, reason: 'unavailable', counts };
  }
  try {
    const FileSystem = fs();
    // Same persistent "IFTA Backup" folder as manual saves, created if missing.
    const folder = await ensureBackupFolder();
    // Unique name so automatic backups never overwrite earlier (manual or auto)
    // backups sitting in the folder.
    const fileUri = await uniqueBackupUri(folder, data.createdAt);
    await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(data, null, 2));
    const verify = await FileSystem.getInfoAsync(fileUri);
    if (!verify.exists) throw new Error('write-verify-failed');
    // Trim to the newest MAX_KEPT_BACKUPS so automatic backups never let the
    // folder grow unbounded; the file just written is the newest and is kept.
    await pruneOldBackups();
    return { ok: true, shared: false, counts };
  } catch (e: any) {
    return { ok: false, reason: 'error', counts, error: e?.message ?? String(e) };
  }
}

// Check the schedule and, if due, write an automatic backup and record it.
// Safe to call on every launch/resume - it no-ops until the 45-day mark.
export async function maybeRunAutoBackup(
  now = Date.now(),
): Promise<{ ran: boolean; meta: BackupMeta; result?: BackupResult }> {
  const meta = await loadBackupMeta();
  if (!isAutoBackupDue(meta, now)) return { ran: false, meta };
  const result = await writeAutoBackup();
  if (!result.ok) return { ran: false, meta, result };
  const updated = await recordBackup('auto', now);
  return { ran: true, meta: updated, result };
}
