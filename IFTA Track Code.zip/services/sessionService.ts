// Single source of truth for the in-progress trip.
//
// Both the foreground UI and the background location task call ingestSamples()
// against the SAME persisted ActiveSession, so mileage keeps accumulating
// whether the app is open or minimized — with no double counting.
//
// TRIP LIFECYCLE: one trip == one calendar day of driving. A session auto-
// starts on the first movement of the day and keeps accumulating across stops,
// fuel/rest breaks and deliveries. It is finalized into a saved daily trip
// ONLY at the midnight (00:00) day boundary — never on idle. See the day-
// rollover handling in ingestSamples() and rolloverIfNewDay().

import AsyncStorage from '@react-native-async-storage/async-storage';
import { haversineMiles } from '@/services/distance';
import { getCurrentStateCode, Sample } from '@/services/locationService';
import {
  loadRecordActivity,
  loadTrips,
  saveRecordActivity,
  saveTrips,
} from '@/services/storageService';
import { ActiveSession, StateMiles, Trip } from '@/services/types';
import { UNKNOWN_STATE } from '@/constants/states';

const SESSION_KEY = '@miletrack/session';
const AUTO_KEY = '@miletrack/auto';
// Temporary suspend flag. When true, movement is neither auto-started nor
// banked, so personal / off-duty driving is excluded without ending the day.
const SUSPEND_KEY = '@miletrack/suspended';
// Pre-trip GPS anchor: the last fix seen while NOT yet recording. Used to detect
// real movement (see START_MOVE_MILES) and to seed the opening stretch of the
// drive so it is not dropped when recording starts.
const PENDING_KEY = '@miletrack/pendingFix';

const MS_PER_HOUR = 3600000;
const MPS_TO_MPH = 2.23694; // m/s -> mph
// Vehicle-speed floor. Movement at or below this is treated as walking/idling
// and is NEVER recorded: it neither auto-starts the day's trip nor banks any
// distance. This keeps IFTA miles to actual driving and eliminates the strolls
// around a truck stop, fuel island or yard that a bare GPS tracker would log.
const MIN_MOVING_MPH = 5; // must be moving faster than this to record
const START_SPEED_MPH = MIN_MOVING_MPH; // auto-start only above walking speed
const MIN_TRIP_MILES = 0.1;
const ACCURACY_LIMIT_M = 80;
// Before a trip may AUTO-START, the GPS must have a confident lock. The first
// fixes after acquiring satellites are coarse (accuracy of hundreds of meters)
// and wander, so they can fabricate "movement" and open a trip while the truck
// is still parked. Requiring the fix to be accurate to within this threshold
// means recording only begins once the position is genuinely locked in. This is
// intentionally stricter than ACCURACY_LIMIT_M (which merely gates whether an
// already-recording segment banks distance).
export const START_ACCURACY_LIMIT_M = 5;
// The strict 5 m foreground lock is unrealistic for the BACKGROUND feed: while
// the screen is locked the OS BATCHES location fixes and delivers them coarser
// (commonly 10-40 m), so a 5 m gate would NEVER pass with the screen off and a
// trip could never auto-start once the phone was locked/pocketed — the exact
// "only records while the app is open" symptom. Background auto-start therefore
// uses a realistic lock threshold so recording begins in ANY device state; a
// fix with no reported accuracy is still rejected as not-yet-locked, and the
// movement test (START_MOVE_MILES at driving speed) still gates the real start.
export const BACKGROUND_START_ACCURACY_LIMIT_M = 100;
const MIN_SEGMENT_MILES = 0.0009; // reject GPS jitter
const MAX_IMPLIED_MPH = 200; // reject impossible jumps
// Position-derived auto-start. GPS `speed` is frequently null/0 (first fixes,
// many Android devices, web), which used to leave the day's trip un-started so
// NO miles recorded even while clearly driving. So movement is also detected
// from how far the truck travels between fixes: once it has moved
// START_MOVE_MILES from a recent anchor at >= START_SLOW_MPH, recording starts,
// with no reliance on the GPS speed field.
const START_MOVE_MILES = 0.03; // ~48 m of real travel from the anchor...
const START_SLOW_MPH = MIN_MOVING_MPH; // ...covered faster than walking, not drift
// A segment spanning longer than this means tracking was suspended (app killed,
// GPS lost, permission off). The straight line across that gap is unreliable,
// so we re-anchor instead of inventing distance, and never trust such a gap to
// auto-start a trip. Used for auto-start trust and launch/resume recovery.
const MAX_GAP_MS = 120000; // 2 minutes
// While ACTIVELY recording, the OS BATCHES background location fixes once the
// screen is locked (it delivers several fixes at once, minutes apart, to save
// power) even with deferred updates disabled. The old code reused the 2-minute
// MAX_GAP_MS here and DROPPED every segment longer than that, so each batched
// highway stretch while the screen was off was thrown away — the direct cause
// of large background undercounts (e.g. reading ~55 miles low on a locked
// drive). A straight-line chord across a batched gap is a conservative
// UNDER-estimate of the real road distance, so counting it is far better than
// discarding it. We therefore tolerate a much longer gap while recording and
// rely on the MAX_IMPLIED_MPH guard below to reject teleports / GPS glitches;
// only a truly stale gap (app killed for a long stretch, parked overnight) is
// still dropped and re-anchored.
const MAX_RECORD_GAP_MS = 900000; // 15 minutes
// GPS fixes are joined by straight-line (great-circle) chords, which UNDERCOUNT
// real road distance: they cut across curves, cloverleaf interchanges and lane
// changes, and skip detail lost during brief signal gaps. A truck odometer
// measures true wheel rotation, so it always reads a little higher. Every
// accepted segment (total AND per-state, to keep IFTA jurisdiction splits
// correct) is scaled by this factor to line up with the odometer.
//
// CALIBRATION: a field odometer comparison showed the app reading ~12.2 miles
// LOW on a sub-200-mile run — an ~8% shortfall, well above the original 1.5%
// assumption. Curvy / interchange-heavy driving and brief signal gaps make the
// chord undercount larger than open-highway tests suggested. A later full-day
// comparison still read ~4.7 miles LOW, so the factor was nudged from 1.08 to
// 1.095 to close that residual chord loss. A follow-up comparison then read a
// small ~0.4 mile OVERcount (the 1.095 bump slightly over-corrected), so the
// factor is trimmed to 1.091 to land on the odometer. Tune this one value if
// your own odometer comparison differs.
const PATH_CORRECTION = 1.091;
// When the screen locks, the OS BATCHES background fixes and delivers them
// seconds-to-minutes apart. A single straight-line chord across such a gap skips
// far more curves/lane changes than a normal ~2s chord, so 1.08 under-corrects
// it and leaves a small residual undercount on locked drives (~0.5 mi). Any
// segment whose gap exceeds this threshold is treated as batched and scaled by
// the larger BATCH_PATH_CORRECTION below to close that gap.
const BATCH_GAP_MS = 15000; // fixes normally arrive ~2s apart
// Tracks PATH_CORRECTION: batched locked-screen chords skip the most road
// detail, so they keep a proportionally larger bump than the normal path. Was
// 1.125 alongside PATH_CORRECTION 1.095; trimmed to 1.121 with the same 0.4%
// step that removed the small full-day overcount on the normal path.
const BATCH_PATH_CORRECTION = 1.121;
const GEOCODE_MOVE_MILES = 0.3; // re-geocode after moving this far
const GEOCODE_MAX_AGE_MS = 20000; // or after this long

// --- Serialized session access ------------------------------------------
// The SAME persisted session is mutated from THREE places: the foreground
// watch (onWatchSample -> ingestSamples), the background location task
// (-> ingestSamples), and launch/resume recovery (rolloverIfNewDay /
// recoverSession / finalizeSessionNow). Each does an async load -> mutate ->
// save. Without serialization these overlap: concurrent callers read the SAME
// snapshot and the last writer wins, silently DROPPING banked miles and
// corrupting the distance anchor (lastLat/lastLon/lastTs). In the field this
// pinned the odometer after roughly the first mile — the app kept showing
// "Recording" but the running total stopped climbing. It was made far worse by
// awaiting a rate-limited reverse-geocode INSIDE that read-modify-write window
// (see resolveStateInBackground below): once the geocode started throttling,
// several ingestSamples calls stacked up in parallel and each wrote back a
// stale total. runExclusive forces every session read-modify-write to run one
// at a time, so each call sees the latest saved state and no update is lost.
let _chain: Promise<unknown> = Promise.resolve();
function runExclusive<T>(task: () => Promise<T>): Promise<T> {
  const result = _chain.then(task, task);
  // Keep the chain alive even if a task rejects, so one failure never wedges
  // the queue for every later caller.
  _chain = result.then(
    () => undefined,
    () => undefined,
  );
  return result;
}

// --- Recording activity -------------------------------------------------
// Which feed a batch of samples came from, so the Settings screen can show that
// mileage is being banked both while the app is open (foreground) and while the
// phone is locked (background).
export type RecordSource = 'foreground' | 'background';

// The foreground watch calls ingestSamples ~once per second, so persisting the
// last-recorded time on every banked sample would hammer AsyncStorage. Throttle
// the write to at most once per this interval per source — plenty fresh for a
// "time ago" indicator without the I/O churn.
const ACTIVITY_MIN_WRITE_MS = 8000;
let lastFgActivityWrite = 0;
let lastBgActivityWrite = 0;

async function noteRecordingActivity(source: RecordSource): Promise<void> {
  const now = Date.now();
  if (source === 'foreground') {
    if (now - lastFgActivityWrite < ACTIVITY_MIN_WRITE_MS) return;
    lastFgActivityWrite = now;
  } else {
    if (now - lastBgActivityWrite < ACTIVITY_MIN_WRITE_MS) return;
    lastBgActivityWrite = now;
  }
  const activity = await loadRecordActivity();
  if (source === 'foreground') activity.foregroundAt = now;
  else activity.backgroundAt = now;
  await saveRecordActivity(activity);
}

// --- Session persistence -------------------------------------------------

export function createSession(auto: boolean): ActiveSession {
  return {
    startedAt: Date.now(),
    auto,
    miles: 0,
    stateMiles: {},
    lastLat: null,
    lastLon: null,
    lastTs: null,
    currentStateCode: null,
    geoT: null,
    geoLat: null,
    geoLon: null,
    speedMph: 0,
    accuracy: null,
    crossings: [],
  };
}

export async function loadSession(): Promise<ActiveSession | null> {
  try {
    const raw = await AsyncStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as ActiveSession) : null;
  } catch {
    return null;
  }
}

export async function saveSession(session: ActiveSession | null): Promise<void> {
  try {
    if (!session) {
      await AsyncStorage.removeItem(SESSION_KEY);
    } else {
      await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session));
    }
  } catch {
    // ignore write errors silently
  }
}

export async function getAutoEnabled(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(AUTO_KEY)) === 'true';
  } catch {
    return false;
  }
}

export async function setAutoEnabledFlag(value: boolean): Promise<void> {
  try {
    await AsyncStorage.setItem(AUTO_KEY, value ? 'true' : 'false');
  } catch {
    // ignore
  }
}

export async function getSuspended(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(SUSPEND_KEY)) === 'true';
  } catch {
    return false;
  }
}

export async function setSuspendedFlag(value: boolean): Promise<void> {
  try {
    await AsyncStorage.setItem(SUSPEND_KEY, value ? 'true' : 'false');
  } catch {
    // ignore
  }
}

// --- Pre-trip movement anchor -------------------------------------------

type PendingFix = {
  // Departure anchor: the position where the current continuous movement burst
  // began. Distance is measured FROM here to decide an auto-start, so it must
  // NOT be reset while the truck is actually moving.
  lat: number;
  lon: number;
  ts: number;
  // The most recent fix seen while not yet recording. Used to compute the
  // per-segment (fix-to-fix) speed that tells whether the truck is moving right
  // now, independent of the accumulated departure window.
  lastLat: number;
  lastLon: number;
  lastTs: number;
};

async function loadPendingFix(): Promise<PendingFix | null> {
  try {
    const raw = await AsyncStorage.getItem(PENDING_KEY);
    return raw ? (JSON.parse(raw) as PendingFix) : null;
  } catch {
    return null;
  }
}

async function savePendingFix(fix: PendingFix): Promise<void> {
  try {
    await AsyncStorage.setItem(PENDING_KEY, JSON.stringify(fix));
  } catch {
    // ignore
  }
}

async function clearPendingFix(): Promise<void> {
  try {
    await AsyncStorage.removeItem(PENDING_KEY);
  } catch {
    // ignore
  }
}

// --- Background state resolution -----------------------------------------

// Refresh the current state from a reverse-geocode WITHOUT blocking mileage.
// Reverse-geocoding is a rate-limited NETWORK call; awaiting it inside the
// serialized write path stalls sample processing, and when many lookups
// overlapped it was the direct cause of the odometer pinning after the first
// mile. So once a state is already known we resolve the next one in the
// background and fold the result back in through the SAME queue, so it can
// never delay or race the distance accumulation. A few seconds of state lag
// only mis-attributes a tiny sliver of miles at a border — negligible for IFTA.
function resolveStateInBackground(lat: number, lon: number): void {
  void (async () => {
    const code = await getCurrentStateCode(lat, lon);
    if (!code) return;
    await runExclusive(async () => {
      const s = await loadSession();
      if (!s) return;
      noteStateChange(s, code, Date.now());
      await saveSession(s);
    });
  })();
}

// --- Core processing -----------------------------------------------------

function sessionToTrip(session: ActiveSession): Trip | null {
  if (session.miles < MIN_TRIP_MILES) return null;
  return {
    id: String(Date.now()),
    startedAt: session.startedAt,
    endedAt: session.lastTs ?? Date.now(),
    miles: session.miles,
    stateMiles: { ...session.stateMiles },
    auto: session.auto,
    crossings: session.crossings ? [...session.crossings] : undefined,
  };
}

function isSameCalendarDay(a: number, b: number): boolean {
  const da = new Date(a);
  const db = new Date(b);
  return (
    da.getFullYear() === db.getFullYear() &&
    da.getMonth() === db.getMonth() &&
    da.getDate() === db.getDate()
  );
}

// Close out `session` as its day's trip and return a fresh session for the new
// day, carrying the last known position/state so distance stays continuous
// across the midnight boundary.
function rolloverSession(
  session: ActiveSession,
  at: number,
): { next: ActiveSession; trip: Trip | null } {
  const trip = sessionToTrip(session);
  const next = createSession(session.auto);
  next.startedAt = at;
  next.lastLat = session.lastLat;
  next.lastLon = session.lastLon;
  next.lastTs = session.lastTs;
  next.currentStateCode = session.currentStateCode;
  next.geoLat = session.geoLat;
  next.geoLon = session.geoLon;
  next.geoT = session.geoT;
  next.accuracy = session.accuracy;
  // Start the new day's crossing timeline at the state carried across midnight,
  // timestamped to the rollover moment, so each day's crossings stand alone.
  next.crossings = session.currentStateCode
    ? [{ stateCode: session.currentStateCode, at, miles: 0 }]
    : [];
  return { next, trip };
}

// Record a jurisdiction change with the moment it happened, so a trip carries a
// timestamped border-crossing timeline. Fires on the first detected state (the
// day's origin) and on every subsequent change to a DIFFERENT state. A repeat
// of the same code is ignored, so throttled/background re-geocodes never add
// duplicate entries. The running odometer at the crossing is captured too.
function noteStateChange(
  session: ActiveSession,
  code: string,
  at: number,
): void {
  if (!code) return;
  if (session.currentStateCode === code) return;
  session.currentStateCode = code;
  if (!session.crossings) session.crossings = [];
  session.crossings.push({
    stateCode: code,
    at,
    miles: Math.round(session.miles * 10) / 10,
  });
}

async function applySample(
  session: ActiveSession,
  sample: Sample,
): Promise<boolean> {
  // Whether this sample actually banked distance (used to timestamp the feed's
  // recording activity). Stays false for jitter / stale gaps / idle fixes.
  let banked = false;
  const gpsMph =
    sample.speed && sample.speed > 0 ? sample.speed * MPS_TO_MPH : 0;
  // Default the live readout to the GPS speed field, which is the most accurate
  // instantaneous ground speed. The position-derived (implied) speed below is
  // only used as a FALLBACK when the GPS speed field is missing. Using the
  // higher of the two inflated the readout by ~4-5 mph, because straight-line
  // jitter between fixes biases the implied speed high.
  session.speedMph = gpsMph;
  // Record the accuracy (in meters) of this fix so the GPS signal-quality
  // indicator can show Strong / Fair / Weak. Set on every fix — even one too
  // imprecise to bank distance — so a weakening signal is reflected immediately.
  session.accuracy = sample.accuracy ?? null;

  // Accumulate distance from the previous accepted sample.
  if (
    session.lastLat != null &&
    session.lastLon != null &&
    (!sample.accuracy || sample.accuracy <= ACCURACY_LIMIT_M)
  ) {
    const d = haversineMiles(
      { latitude: session.lastLat, longitude: session.lastLon },
      sample,
    );
    const dtMs = session.lastTs ? sample.timestamp - session.lastTs : 0;
    const dtH = dtMs / MS_PER_HOUR;
    const impliedMph = dtH > 0 ? d / dtH : 0;
    // Skip a segment only across a TRULY stale gap (app killed for a long
    // stretch / parked overnight): the straight line there is unreliable, so
    // re-anchor instead of inventing distance. A normal background-batched gap
    // (minutes, while the screen is locked) is KEPT — dropping it was the cause
    // of large background undercounts — and the MAX_IMPLIED_MPH check below
    // still rejects any implausibly fast segment.
    const longGap = dtMs > MAX_RECORD_GAP_MS;
    // True ground speed for this segment: prefer the GPS speed field, fall back
    // to the position-derived rate (GPS `speed` is often null while moving).
    const segmentMph = Math.max(gpsMph, impliedMph);
    if (
      !longGap &&
      d > MIN_SEGMENT_MILES &&
      impliedMph < MAX_IMPLIED_MPH &&
      segmentMph > MIN_MOVING_MPH
    ) {
      // Compensate the straight-line chord for real road distance (see
      // PATH_CORRECTION) so totals match the truck odometer for IFTA filing. A
      // batched (locked-screen) segment spans a longer gap and loses more to
      // chording, so it gets the larger BATCH_PATH_CORRECTION.
      const correction =
        dtMs > BATCH_GAP_MS ? BATCH_PATH_CORRECTION : PATH_CORRECTION;
      const corrected = d * correction;
      session.miles += corrected;
      const code = session.currentStateCode || UNKNOWN_STATE;
      session.stateMiles[code] = (session.stateMiles[code] || 0) + corrected;
      banked = true;
      // Only fall back to the position-derived speed when the GPS speed field
      // is unavailable (null / 0). When GPS speed is present, trust it — the
      // implied speed runs high from positional jitter and reads ~4-5 mph fast.
      if (gpsMph <= 0 && impliedMph > 0) session.speedMph = impliedMph;
    }
  }

  // Throttled reverse-geocode to resolve the current state.
  const moved =
    session.geoLat == null ||
    session.geoLon == null ||
    haversineMiles(
      { latitude: session.geoLat, longitude: session.geoLon },
      sample,
    ) > GEOCODE_MOVE_MILES;
  const aged =
    session.geoT == null || sample.timestamp - session.geoT > GEOCODE_MAX_AGE_MS;
  if (moved || aged) {
    session.geoT = sample.timestamp;
    session.geoLat = sample.latitude;
    session.geoLon = sample.longitude;
    if (session.currentStateCode == null) {
      // No state known yet (trip just started): resolve INLINE so the opening
      // miles are attributed to the right jurisdiction. Bounded by
      // getCurrentStateCode's own 6s timeout, and — because ingestSamples is
      // now serialized — this runs at most once per throttle window, so it can
      // no longer stack up and stall recording.
      const code = await getCurrentStateCode(sample.latitude, sample.longitude);
      if (code) noteStateChange(session, code, sample.timestamp);
    } else {
      // A state is already known: refresh it in the BACKGROUND so a slow or
      // rate-limited lookup can never block the write path and pin the odometer.
      resolveStateInBackground(sample.latitude, sample.longitude);
    }
  }

  session.lastLat = sample.latitude;
  session.lastLon = sample.longitude;
  session.lastTs = sample.timestamp;
  return banked;
}

// Process a batch of location samples against the persisted session.
// Auto-starts the day's trip when real movement is detected (if auto mode is
// on) — from GPS speed OR, when that field is missing, from how far the truck
// has actually travelled between fixes. The trip is finalized ONLY at the
// midnight day boundary, never on idle. Returns the resulting session snapshot.
//
// Serialized (runExclusive): the foreground watch and the background task both
// call this against the one on-disk session, so overlapping calls must not read
// a stale snapshot and clobber each other's banked miles.
export async function ingestSamples(
  samples: Sample[],
  source?: RecordSource,
): Promise<{ session: ActiveSession | null; finalized: boolean }> {
  return runExclusive(() => ingestSamplesInner(samples, source));
}

async function ingestSamplesInner(
  samples: Sample[],
  source?: RecordSource,
): Promise<{ session: ActiveSession | null; finalized: boolean }> {
  let session = await loadSession();
  const auto = await getAutoEnabled();
  const suspended = await getSuspended();
  let finalized = false;
  // Set once any sample in this batch banks distance, so we can stamp the
  // feed's (foreground/background) last-recorded time below.
  let banked = false;

  for (const sample of samples) {
    // Temporarily suspended (personal / off-duty driving): do NOT auto-start
    // and do NOT bank any miles. Keep the position anchor current so resuming
    // measures distance from where the truck is now, never banking the
    // suspended gap. Any open day session is left intact with its total frozen
    // so on-duty mileage simply continues when the driver resumes.
    if (suspended) {
      if (session) {
        session.lastLat = sample.latitude;
        session.lastLon = sample.longitude;
        session.lastTs = sample.timestamp;
        session.speedMph = 0;
        session.accuracy = sample.accuracy ?? null;
      } else {
        await savePendingFix({
          lat: sample.latitude,
          lon: sample.longitude,
          ts: sample.timestamp,
          lastLat: sample.latitude,
          lastLon: sample.longitude,
          lastTs: sample.timestamp,
        });
      }
      continue;
    }

    if (!session) {
      // Not recording yet. Decide whether the truck is actually moving WITHOUT
      // trusting the (often null) GPS speed field: measure travel from a recent
      // anchor fix.
      if (!auto) continue;

      // GPS-LOCK GATE: in addition to detecting movement, never auto-start (nor
      // even anchor a departure) from an unlocked / coarse fix. A fix with no
      // reported accuracy, or one worse than START_ACCURACY_LIMIT_M, is skipped
      // entirely so the early, wandering fixes that arrive before the GPS truly
      // locks can neither seed a movement anchor nor open a trip while parked.
      // Once a confident lock lands, movement detection proceeds as normal.
      // The threshold is relaxed for background (locked-screen) fixes so a trip
      // can auto-start while the phone is locked, not only with the app open.
      const startLimit =
        source === 'background'
          ? BACKGROUND_START_ACCURACY_LIMIT_M
          : START_ACCURACY_LIMIT_M;
      if (source === 'background') {
        // FORCE background recording to begin even from coarse, batched locked-
        // screen fixes: reject ONLY a fix whose reported accuracy is KNOWN and
        // worse than the (relaxed) background limit. A fix with NO accuracy
        // field is accepted here — batched background fixes sometimes omit it —
        // because the movement test below (real travel at driving speed) is what
        // actually gates the start, so a missing accuracy can no longer block
        // screen-off recording.
        if (sample.accuracy != null && sample.accuracy > startLimit) {
          continue;
        }
      } else if (sample.accuracy == null || sample.accuracy > startLimit) {
        continue;
      }

      const gpsMph =
        sample.speed && sample.speed > 0 ? sample.speed * MPS_TO_MPH : 0;
      const anchor = await loadPendingFix();

      // No anchor yet, or the previous fix is too old to trust across a
      // tracking gap: (re)seed BOTH the departure anchor and the last-fix
      // reference at this position and wait for the next fix.
      if (!anchor || sample.timestamp - anchor.lastTs > MAX_GAP_MS) {
        await savePendingFix({
          lat: sample.latitude,
          lon: sample.longitude,
          ts: sample.timestamp,
          lastLat: sample.latitude,
          lastLon: sample.longitude,
          lastTs: sample.timestamp,
        });
        continue;
      }

      // Per-segment speed between the PREVIOUS fix and this one — a short,
      // ~1-second window that says whether the truck is moving right now.
      const segMoved = haversineMiles(
        { latitude: anchor.lastLat, longitude: anchor.lastLon },
        sample,
      );
      const segDtH = (sample.timestamp - anchor.lastTs) / MS_PER_HOUR;
      const segMph = segDtH > 0 ? segMoved / segDtH : 0;
      const movingSegment =
        segMph < MAX_IMPLIED_MPH && Math.max(gpsMph, segMph) > START_SLOW_MPH;

      // The anchor marks the START of the current continuous movement burst.
      // While the truck is stationary (idling/parked, GPS only jittering), reset
      // it to here so parked time can NEVER dilute the departure speed. While it
      // IS moving, KEEP the anchor so distance accumulates across consecutive
      // fixes toward START_MOVE_MILES. This is what lets a real departure be
      // detected from position alone when the GPS `speed` field is null.
      //
      // (The previous logic reset the anchor on EVERY non-start sample, so the
      // window was a single ~1s fix that could never cover the 0.03 mi jitter
      // floor unless doing ~108 mph — so on devices with a null speed field the
      // trip never auto-started and no miles were ever recorded.)
      const anchorLat = movingSegment ? anchor.lat : sample.latitude;
      const anchorLon = movingSegment ? anchor.lon : sample.longitude;
      const anchorTs = movingSegment ? anchor.ts : sample.timestamp;

      const movedFromAnchor = haversineMiles(
        { latitude: anchorLat, longitude: anchorLon },
        sample,
      );
      const dtH = (sample.timestamp - anchorTs) / MS_PER_HOUR;
      const impliedMph = dtH > 0 ? movedFromAnchor / dtH : 0;
      const movingNow =
        impliedMph < MAX_IMPLIED_MPH &&
        (gpsMph > START_SPEED_MPH ||
          (movedFromAnchor >= START_MOVE_MILES && impliedMph > START_SLOW_MPH));

      if (!movingNow) {
        // Persist the (possibly reset) departure anchor and advance the
        // last-fix reference so the next sample measures against this one.
        await savePendingFix({
          lat: anchorLat,
          lon: anchorLon,
          ts: anchorTs,
          lastLat: sample.latitude,
          lastLon: sample.longitude,
          lastTs: sample.timestamp,
        });
        continue;
      }

      // Real movement: open the day's trip and seed it from the departure
      // anchor so the opening stretch of the drive is counted, not dropped.
      session = createSession(true);
      session.lastLat = anchorLat;
      session.lastLon = anchorLon;
      session.lastTs = anchorTs;
      await clearPendingFix();
    }

    // Day boundary: never let a new calendar day's miles pile onto the day the
    // session started. Close out the current day's trip and carry on with a
    // fresh session so day / month / quarter reports separate correctly.
    if (!isSameCalendarDay(session.startedAt, sample.timestamp)) {
      const { next, trip } = rolloverSession(session, sample.timestamp);
      if (trip) {
        const priorTrips = await loadTrips();
        await saveTrips([trip, ...priorTrips]);
        finalized = true;
      }
      session = next;
    }

    if (await applySample(session, sample)) banked = true;
  }

  // NOTE: the day's trip is intentionally NOT finalized on idle/stop. A parked
  // truck (fuel stop, rest break, delivery) keeps the same daily session open,
  // so the running odometer holds its total and simply resumes when driving
  // continues. The ONLY automatic reset is the midnight (00:00) day-rollover
  // handled in the loop above and in rolloverIfNewDay().

  if (session !== null || finalized) {
    await saveSession(session);
  }
  // Stamp the last-recorded time for this feed so the Settings screen can
  // confirm foreground vs background (locked-drive) recording is working.
  if (banked && source) {
    await noteRecordingActivity(source);
  }
  return { session, finalized };
}

// Overwrite the CURRENT day's in-progress miles WITHOUT ending the day, so a
// driver can correct the running odometer (e.g. to match their dash) and keep
// recording. Serialized so it cannot clobber (or be clobbered by) an in-flight
// ingestSamples write. If no session exists yet (armed but not driving), one is
// opened so the entered miles persist as today's session and keep accumulating
// from the next GPS fix. The position anchor is left untouched, so any distance
// driven after saving is added on top of the corrected total.
export async function updateSessionMiles(
  stateMiles: StateMiles,
): Promise<ActiveSession | null> {
  return runExclusive(async () => {
    let session = await loadSession();
    if (!session) session = createSession(false);
    const cleaned: StateMiles = {};
    for (const [code, value] of Object.entries(stateMiles)) {
      const v = Math.max(0, Math.round((value || 0) * 10) / 10);
      if (v > 0) cleaned[code] = v;
    }
    session.stateMiles = cleaned;
    session.miles = Object.values(cleaned).reduce((a, b) => a + b, 0);
    await saveSession(session);
    return session;
  });
}

// Finalize the current session immediately (manual Stop). Saves the trip if it
// meets the minimum distance, then clears the session. Serialized so it cannot
// clobber (or be clobbered by) an in-flight ingestSamples write.
export async function finalizeSessionNow(): Promise<boolean> {
  return runExclusive(async () => {
    const session = await loadSession();
    if (!session) return false;
    const trip = sessionToTrip(session);
    await saveSession(null);
    await clearPendingFix();
    if (trip) {
      const trips = await loadTrips();
      await saveTrips([trip, ...trips]);
      return true;
    }
    return false;
  });
}

// Called on launch/resume: if the in-progress session belongs to a previous
// day (e.g. the truck was parked overnight), finalize it as that day's trip
// and clear it so today's live odometer and day totals start at zero.
export async function rolloverIfNewDay(now = Date.now()): Promise<boolean> {
  return runExclusive(async () => {
    const session = await loadSession();
    if (!session) return false;
    if (isSameCalendarDay(session.startedAt, now)) return false;
    const trip = sessionToTrip(session);
    if (trip) {
      const trips = await loadTrips();
      await saveTrips([trip, ...trips]);
    }
    await saveSession(null);
    await clearPendingFix();
    return true;
  });
}

// Recover the session shown on launch/resume. Clears a "phantom" auto session —
// one that reports effectively no miles and has had no fix for a while (e.g.
// left armed while parked, or created by older, noisier auto-start) — so the UI
// shows an honest "Armed" instead of a stuck "Recording" with 0 miles. A
// genuinely active drive (recent fix, or real miles banked) is returned as-is.
export async function recoverSession(
  now = Date.now(),
): Promise<ActiveSession | null> {
  return runExclusive(async () => {
    const session = await loadSession();
    if (!session) return null;
    const stale = session.lastTs == null || now - session.lastTs > MAX_GAP_MS;
    if (session.auto && session.miles < MIN_TRIP_MILES && stale) {
      await saveSession(null);
      await clearPendingFix();
      return null;
    }
    return session;
  });
}
