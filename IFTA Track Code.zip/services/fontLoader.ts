// Powered by OnSpace.AI
// Preloads the icon fonts used across the app and hardens expo-font against a
// native/JS version skew.
//
// CRASH FIXED: "TypeError: undefined is not a function" thrown from expo-font's
// isLoadedNative() on the FIRST <Icon> (@expo/vector-icons) that renders.
//
// Why it happens (verified against expo-font source):
//   * @expo/vector-icons' <Icon> constructor runs `Font.isLoaded(fontName)`.
//   * expo-font's isLoaded() -> isLoadedNative() calls the native method
//     `ExpoFontLoader.getLoadedFonts()`.
//   * This app's compiled native ExpoFontLoader module predates getLoadedFonts,
//     so the call target is undefined and the synchronous render throws,
//     crashing the whole screen.
//   * Every font path funnels through the same check - even Font.loadAsync()
//     calls isLoaded() first - so simply preloading the font is not enough:
//     the preload itself throws before it can seed expo-font's JS cache.
//
// The only reliable fix is to make `ExpoFontLoader.getLoadedFonts` resolve to a
// function. requireNativeModule('ExpoFontLoader') returns
// globalThis.expo.modules.ExpoFontLoader, and that object is a JSI host object
// that is usually NON-EXTENSIBLE (which is why a plain `obj.getLoadedFonts = ...`
// assignment silently fails). So we try, in order:
//   1. direct assignment,
//   2. Object.defineProperty on the instance,
//   3. patching the prototype (a regular, extensible JS object) so the missing
//      method resolves through the prototype chain,
//   4. as a last resort, swapping the module-registry entry for a Proxy that
//      fills in getLoadedFonts and delegates everything else to the real module.
//
// Once getLoadedFonts() returns [] instead of throwing, isLoadedNative() safely
// returns false, MaterialIcons.loadFont() (a thin wrapper over Font.loadAsync)
// actually registers the glyph font, and expo-font's JS cache is seeded so later
// isLoaded() checks short-circuit before touching native at all.

import { Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

let hardened = false;

const stubGetLoadedFonts = (): string[] => [];

function hasFn(obj: any, key: string): boolean {
  return !!obj && typeof obj[key] === 'function';
}

// Try every available mechanism to make `getLoadedFonts` callable on `target`.
// Returns true once it resolves to a function.
function ensureGetLoadedFonts(target: any): boolean {
  if (!target) return false;
  if (hasFn(target, 'getLoadedFonts')) return true;

  // 1) Direct assignment - works when the module object is extensible.
  try {
    target.getLoadedFonts = stubGetLoadedFonts;
  } catch {
    // non-extensible / frozen host object - fall through
  }
  if (hasFn(target, 'getLoadedFonts')) return true;

  // 2) defineProperty on the instance.
  try {
    Object.defineProperty(target, 'getLoadedFonts', {
      value: stubGetLoadedFonts,
      writable: true,
      configurable: true,
      enumerable: false,
    });
  } catch {
    // still not writable - fall through
  }
  if (hasFn(target, 'getLoadedFonts')) return true;

  // 3) Patch the prototype. JSI-backed native module instances are commonly
  //    non-extensible, but their prototype is a regular JS object we can extend,
  //    so the missing method resolves through the prototype chain.
  try {
    const proto = Object.getPrototypeOf(target);
    if (proto && proto !== Object.prototype && proto !== Function.prototype) {
      try {
        proto.getLoadedFonts = stubGetLoadedFonts;
      } catch {
        // fall through to defineProperty
      }
      if (!hasFn(proto, 'getLoadedFonts')) {
        try {
          Object.defineProperty(proto, 'getLoadedFonts', {
            value: stubGetLoadedFonts,
            writable: true,
            configurable: true,
            enumerable: false,
          });
        } catch {
          // prototype is locked too
        }
      }
    }
  } catch {
    // no usable prototype
  }

  return hasFn(target, 'getLoadedFonts');
}

function hardenExpoFontLoader(): void {
  if (hardened) return;
  hardened = true;
  if (Platform.OS === 'web') return;

  try {
    const g: any = globalThis as any;
    const registry = g?.expo?.modules;

    // The exact object expo-font captures via requireNativeModule.
    const targets: any[] = [];
    if (registry?.ExpoFontLoader) targets.push(registry.ExpoFontLoader);

    // Same object again through the public helper, just in case the registry is
    // not reachable on this runtime.
    try {
      const core = require('expo-modules-core');
      const req = core?.requireOptionalNativeModule ?? core?.requireNativeModule;
      if (typeof req === 'function') {
        let mod: any = null;
        try {
          mod = req.call(core, 'ExpoFontLoader');
        } catch {
          mod = null;
        }
        if (mod && !targets.includes(mod)) targets.push(mod);
      }
    } catch {
      // expo-modules-core unavailable - registry path above still applies
    }

    let ok = false;
    targets.forEach((t) => {
      if (ensureGetLoadedFonts(t)) ok = true;
    });

    // Last resort: if the native object rejected every in-place patch, swap the
    // registry entry for a Proxy that supplies the missing method and delegates
    // everything else to the real module.
    if (!ok && registry?.ExpoFontLoader) {
      const original = registry.ExpoFontLoader;
      try {
        registry.ExpoFontLoader = new Proxy(original, {
          get(t: any, prop: string | symbol) {
            try {
              if (prop === 'getLoadedFonts' && !hasFn(t, 'getLoadedFonts')) {
                return stubGetLoadedFonts;
              }
              const value = t[prop];
              if (typeof value === 'function') {
                return (...args: any[]) => value.apply(t, args);
              }
              return value;
            } catch {
              return prop === 'getLoadedFonts' ? stubGetLoadedFonts : undefined;
            }
          },
        });
      } catch {
        // registry is frozen - nothing more we can do here
      }
    }
  } catch {
    // Never let hardening throw; the preload below is the secondary safeguard.
  }
}

// Public, synchronous crash guard. Makes Font.isLoaded()/getLoadedFonts() safe
// to call during render BEFORE any <Icon> mounts. Safe to call at module scope
// on any platform - it is a no-op on web and never throws. Call this as early as
// possible (module scope of the root layout) so the tab bar's icons can never
// hit the expo-font isLoadedNative() TypeError on their first render, WITHOUT
// having to gate/delay the navigator behind an async font load.
export function hardenIconFonts(): void {
  hardenExpoFontLoader();
}

export async function preloadIconFonts(): Promise<void> {
  // Make Font.isLoaded()/getLoadedFonts() safe BEFORE anything renders an icon.
  hardenExpoFontLoader();

  try {
    // MaterialIcons.loadFont() === Font.loadAsync({ MaterialIcons: <ttf> }).
    // With getLoadedFonts() now safe, this registers the glyph font and seeds
    // expo-font's JS cache so every later Font.isLoaded('MaterialIcons') check
    // short-circuits and never reaches the native path.
    await MaterialIcons.loadFont();
  } catch {
    // Best effort: even if the preload fails, hardenExpoFontLoader() has already
    // made Font.isLoaded() safe to call during render, so icons cannot crash the
    // app (they simply render once componentDidMount finishes loading).
  }
}
