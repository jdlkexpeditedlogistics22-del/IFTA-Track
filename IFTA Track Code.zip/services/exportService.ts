// Builds CSV / plain-text IFTA reports from aggregated state mileage and
// shares them. Native uses expo-file-system + expo-sharing; web falls back to
// a Blob download. Pure builders are exported for reuse/testing.
//
// IMPORTANT: expo-file-system / expo-sharing / expo-mail-composer are loaded
// LAZILY and are NEVER evaluated at module / route-load time. A top-level
// `import * as X from 'expo-...'` pulls these native modules (and
// expo-modules-core) into the route graph; when a mismatched expo-modules-core
// / New Architecture build resolves an undefined native binding, evaluating
// them throws "undefined is not a function" and crashes the whole screen while
// the router lazily loads this tab. Requiring them on first use keeps route
// loading crash-free and only touches the native module when an export runs.

import { Platform } from 'react-native';
import {
  formatCurrency,
  formatDate,
  formatGallons,
  formatPricePerGallon,
  formatSignedGallons,
} from '@/constants/format';
import { stateLabel } from '@/constants/states';

// --- Lazy native-module accessors (required only when a share/export runs) ---

let _fs: typeof import('expo-file-system') | null = null;
function fs(): typeof import('expo-file-system') {
  if (!_fs) _fs = require('expo-file-system');
  return _fs;
}

let _sharing: typeof import('expo-sharing') | null = null;
function sharing(): typeof import('expo-sharing') {
  if (!_sharing) _sharing = require('expo-sharing');
  return _sharing;
}

let _mail: typeof import('expo-mail-composer') | null = null;
function mail(): typeof import('expo-mail-composer') {
  if (!_mail) _mail = require('expo-mail-composer');
  return _mail;
}

let _print: typeof import('expo-print') | null = null;
function print(): typeof import('expo-print') {
  if (!_print) _print = require('expo-print');
  return _print;
}

export type ExportFormat = 'csv' | 'text';

export type ExportRow = {
  code: string;
  miles: number;
  // Optional per-jurisdiction gallons reconciliation. Present in the Summary
  // tab export; absent for a miles-only report.
  taxableGallons?: number; // miles / fleet mpg
  taxPaidGallons?: number; // gallons purchased in the state
  netTaxableGallons?: number; // taxable - tax-paid (+ owed, - credit)
};

export type ReportMeta = {
  periodName: string; // e.g. "Quarter"
  periodLabel: string; // e.g. "Q2 2026"
  total: number;
  tripCount: number;
  generatedAt: number;
  // IFTA fuel context for reporting (optional).
  totalGallons?: number;
  totalFuelCost?: number;
  mpg?: number; // fleet MPG (0 when no gallons recorded)
  // Fuel purchases grouped by the jurisdiction where they were bought, so the
  // report shows miles, fuel, AND the states where fuel was purchased.
  fuelByState?: { code: string; gallons: number; amount: number }[];
};

export type ExportResult = {
  ok: boolean;
  shared: boolean;
  reason?: 'empty' | 'unavailable' | 'error';
};

const APP_NAME = 'IFTA-Track';

function escapeCsv(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

function escapeHtml(value: string): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// --- Plain-text table renderer -------------------------------------------
// Renders rows as a fixed-width, aligned column table so text reports read
// cleanly in any monospaced viewer / email body. Each column is padded to its
// widest cell; numeric columns are right-aligned, text columns left-aligned.
type TextColumn = { header: string; align?: 'left' | 'right' };

function renderTextTable(columns: TextColumn[], rows: string[][]): string[] {
  const widths = columns.map((col, i) => {
    let w = col.header.length;
    rows.forEach((r) => {
      const cell = r[i] ?? '';
      if (cell.length > w) w = cell.length;
    });
    return w;
  });

  const pad = (text: string, i: number): string => {
    const w = widths[i];
    const cell = text ?? '';
    if (columns[i].align === 'right') return cell.padStart(w);
    return cell.padEnd(w);
  };

  const gap = '  ';
  const headerLine = columns.map((c, i) => pad(c.header, i)).join(gap);
  const dividerLine = widths.map((w) => '-'.repeat(w)).join(gap);
  const body = rows.map((r) => r.map((cell, i) => pad(cell, i)).join(gap));
  return [headerLine, dividerLine, ...body];
}

export function buildCsv(rows: ExportRow[], meta: ReportMeta): string {
  const lines: string[] = [];
  lines.push(`${APP_NAME} IFTA Mileage Report`);
  lines.push(`Period,${escapeCsv(meta.periodName)}`);
  lines.push(`Range,${escapeCsv(meta.periodLabel)}`);
  lines.push(`Generated,${escapeCsv(formatDate(meta.generatedAt))}`);
  lines.push(`Trips,${meta.tripCount}`);
  if (meta.totalGallons != null) {
    lines.push(`Fuel Gallons,${meta.totalGallons.toFixed(1)}`);
  }
  if (meta.mpg != null) {
    lines.push(`Fleet MPG,${meta.mpg > 0 ? meta.mpg.toFixed(2) : 'n/a'}`);
  }
  lines.push('');

  const hasGallons = rows.some(
    (r) => r.taxableGallons != null || r.taxPaidGallons != null,
  );
  if (hasGallons) {
    // Mileage + per-jurisdiction gallons reconciliation.
    lines.push(
      'State Code,Jurisdiction,Miles,Taxable Gallons,Tax-Paid Gallons,Net Taxable Gallons',
    );
    rows.forEach((r) => {
      lines.push(
        [
          escapeCsv(r.code),
          escapeCsv(stateLabel(r.code)),
          r.miles.toFixed(1),
          (r.taxableGallons ?? 0).toFixed(1),
          (r.taxPaidGallons ?? 0).toFixed(1),
          (r.netTaxableGallons ?? 0).toFixed(1),
        ].join(','),
      );
    });
    lines.push(['Total', '', meta.total.toFixed(1), '', '', ''].join(','));
    lines.push('');
    lines.push(
      `Note,${escapeCsv(
        'Net taxable gallons = miles / fleet MPG - gallons purchased',
      )}`,
    );
  } else {
    // Mileage-only fallback (no fuel context supplied).
    lines.push('State Code,Jurisdiction,Miles');
    rows.forEach((r) => {
      lines.push(
        `${escapeCsv(r.code)},${escapeCsv(stateLabel(r.code))},${r.miles.toFixed(1)}`,
      );
    });
    lines.push(`Total,,${meta.total.toFixed(1)}`);
  }

  if (meta.fuelByState && meta.fuelByState.length > 0) {
    const fg = meta.fuelByState.reduce((s, f) => s + f.gallons, 0);
    const fa = meta.fuelByState.reduce((s, f) => s + f.amount, 0);
    lines.push('');
    lines.push('Fuel Purchased By Jurisdiction');
    lines.push('State Code,Jurisdiction,Gallons,Amount');
    meta.fuelByState.forEach((f) => {
      lines.push(
        [
          escapeCsv(f.code),
          escapeCsv(stateLabel(f.code)),
          f.gallons.toFixed(1),
          f.amount.toFixed(2),
        ].join(','),
      );
    });
    lines.push(['Total', '', fg.toFixed(1), fa.toFixed(2)].join(','));
  }

  return lines.join('\n');
}

export function buildText(rows: ExportRow[], meta: ReportMeta): string {
  const lines: string[] = [];
  lines.push(`${APP_NAME} — IFTA Mileage Report`);
  lines.push(`Period: ${meta.periodName} (${meta.periodLabel})`);
  lines.push(`Generated: ${formatDate(meta.generatedAt)}`);
  lines.push('');

  const hasGallons = rows.some(
    (r) => r.taxableGallons != null || r.taxPaidGallons != null,
  );

  if (rows.length === 0) {
    lines.push('Mileage by jurisdiction:');
    lines.push('  No miles recorded.');
  } else if (hasGallons) {
    // Mileage + per-jurisdiction gallons reconciliation, as an aligned table.
    const columns: TextColumn[] = [
      { header: 'Jurisdiction' },
      { header: 'Code' },
      { header: 'Miles', align: 'right' },
      { header: 'Taxable Gal', align: 'right' },
      { header: 'Paid Gal', align: 'right' },
      { header: 'Net Gal', align: 'right' },
    ];
    const tableRows = rows.map((r) => [
      stateLabel(r.code),
      r.code,
      r.miles.toFixed(1),
      formatGallons(r.taxableGallons ?? 0),
      formatGallons(r.taxPaidGallons ?? 0),
      formatSignedGallons(r.netTaxableGallons ?? 0),
    ]);
    tableRows.push([
      'TOTAL',
      '',
      meta.total.toFixed(1),
      '',
      '',
      '',
    ]);
    lines.push(...renderTextTable(columns, tableRows));
  } else {
    // Mileage-only aligned table.
    const columns: TextColumn[] = [
      { header: 'Jurisdiction' },
      { header: 'Code' },
      { header: 'Miles', align: 'right' },
    ];
    const tableRows = rows.map((r) => [
      stateLabel(r.code),
      r.code,
      r.miles.toFixed(1),
    ]);
    tableRows.push(['TOTAL', '', meta.total.toFixed(1)]);
    lines.push(...renderTextTable(columns, tableRows));
  }

  lines.push('');
  const stateWord = rows.length === 1 ? 'state' : 'states';
  const tripWord = meta.tripCount === 1 ? 'trip' : 'trips';
  lines.push(
    `Total: ${meta.total.toFixed(1)} mi · ${rows.length} ${stateWord} · ${meta.tripCount} ${tripWord}`,
  );

  if (hasGallons) {
    lines.push('');
    if (meta.mpg != null) {
      lines.push(`Fleet MPG: ${meta.mpg > 0 ? meta.mpg.toFixed(1) : 'n/a'}`);
    }
    if (meta.totalGallons != null) {
      lines.push(`Fuel purchased: ${formatGallons(meta.totalGallons)} gal`);
    }
    lines.push('');
    lines.push(
      'Net Gal = miles / fleet MPG - gallons purchased (+ owed, - credit).',
    );
  }

  if (meta.fuelByState && meta.fuelByState.length > 0) {
    lines.push('');
    lines.push('Fuel purchased by jurisdiction:');
    const columns: TextColumn[] = [
      { header: 'Jurisdiction' },
      { header: 'Code' },
      { header: 'Gallons', align: 'right' },
      { header: 'Amount', align: 'right' },
    ];
    const fg = meta.fuelByState.reduce((s, f) => s + f.gallons, 0);
    const fa = meta.fuelByState.reduce((s, f) => s + f.amount, 0);
    const tableRows = meta.fuelByState.map((f) => [
      stateLabel(f.code),
      f.code,
      f.gallons.toFixed(1),
      formatCurrency(f.amount),
    ]);
    tableRows.push(['TOTAL', '', fg.toFixed(1), formatCurrency(fa)]);
    lines.push(...renderTextTable(columns, tableRows));
  }

  return lines.join('\n');
}

// Renders the mileage report as a styled HTML document with clean, aligned
// rows/columns — used for printing and for the PDF attached to emailed reports.
export function buildHtml(rows: ExportRow[], meta: ReportMeta): string {
  const hasGallons = rows.some(
    (r) => r.taxableGallons != null || r.taxPaidGallons != null,
  );

  const columns = hasGallons
    ? ['Jurisdiction', 'Code', 'Miles', 'Taxable Gal', 'Paid Gal', 'Net Gal']
    : ['Jurisdiction', 'Code', 'Miles'];

  const headCells = columns
    .map((c, i) => `<th class="${i >= 2 ? 'num' : ''}">${escapeHtml(c)}</th>`)
    .join('');

  const bodyRows =
    rows.length === 0
      ? `<tr><td colspan="${columns.length}" class="empty">No miles recorded for this period.</td></tr>`
      : rows
          .map((r, i) => {
            const cells = hasGallons
              ? [
                  stateLabel(r.code),
                  r.code,
                  r.miles.toFixed(1),
                  formatGallons(r.taxableGallons ?? 0),
                  formatGallons(r.taxPaidGallons ?? 0),
                  formatSignedGallons(r.netTaxableGallons ?? 0),
                ]
              : [stateLabel(r.code), r.code, r.miles.toFixed(1)];
            const tds = cells
              .map(
                (c, ci) =>
                  `<td class="${ci >= 2 ? 'num' : ''}">${escapeHtml(c)}</td>`,
              )
              .join('');
            return `<tr class="${i % 2 ? 'alt' : ''}">${tds}</tr>`;
          })
          .join('');

  const totalCells = hasGallons
    ? ['TOTAL', '', meta.total.toFixed(1), '', '', '']
    : ['TOTAL', '', meta.total.toFixed(1)];
  const totalRow = totalCells
    .map((c, ci) => `<td class="${ci >= 2 ? 'num' : ''}">${escapeHtml(c)}</td>`)
    .join('');

  const metaItems: string[] = [
    `<div class="meta-item"><span>Period</span><strong>${escapeHtml(meta.periodName)}</strong></div>`,
    `<div class="meta-item"><span>Range</span><strong>${escapeHtml(meta.periodLabel)}</strong></div>`,
    `<div class="meta-item"><span>Generated</span><strong>${escapeHtml(formatDate(meta.generatedAt))}</strong></div>`,
    `<div class="meta-item"><span>Trips</span><strong>${meta.tripCount}</strong></div>`,
  ];
  if (meta.totalGallons != null) {
    metaItems.push(
      `<div class="meta-item"><span>Fuel gallons</span><strong>${formatGallons(
        meta.totalGallons,
      )}</strong></div>`,
    );
  }
  if (meta.mpg != null) {
    metaItems.push(
      `<div class="meta-item"><span>Fleet MPG</span><strong>${
        meta.mpg > 0 ? meta.mpg.toFixed(2) : 'n/a'
      }</strong></div>`,
    );
  }
  if (meta.totalFuelCost != null) {
    metaItems.push(
      `<div class="meta-item"><span>Fuel cost</span><strong>${escapeHtml(
        formatCurrency(meta.totalFuelCost),
      )}</strong></div>`,
    );
  }

  // Fuel purchased grouped by the jurisdiction where it was bought.
  let fuelSection = '';
  if (meta.fuelByState && meta.fuelByState.length > 0) {
    const fg = meta.fuelByState.reduce((s, f) => s + f.gallons, 0);
    const fa = meta.fuelByState.reduce((s, f) => s + f.amount, 0);
    const fuelBody = meta.fuelByState
      .map((f, i) => {
        const cells = [
          stateLabel(f.code),
          f.code,
          formatGallons(f.gallons),
          formatCurrency(f.amount),
        ];
        const tds = cells
          .map(
            (c, ci) =>
              `<td class="${ci >= 2 ? 'num' : ''}">${escapeHtml(c)}</td>`,
          )
          .join('');
        return `<tr class="${i % 2 ? 'alt' : ''}">${tds}</tr>`;
      })
      .join('');
    const fuelTotal = ['TOTAL', '', formatGallons(fg), formatCurrency(fa)]
      .map(
        (c, ci) => `<td class="${ci >= 2 ? 'num' : ''}">${escapeHtml(c)}</td>`,
      )
      .join('');
    fuelSection = `
  <h2 class="subhead">Fuel Purchased by Jurisdiction</h2>
  <table>
    <thead><tr><th>Jurisdiction</th><th>Code</th><th class="num">Gallons</th><th class="num">Amount</th></tr></thead>
    <tbody>${fuelBody}</tbody>
    <tfoot><tr>${fuelTotal}</tr></tfoot>
  </table>`;
  }

  const note = hasGallons
    ? '<p class="note">Net taxable gallons = miles \u00f7 fleet MPG \u2212 gallons purchased (positive = owed, negative = credit).</p>'
    : '';

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, Roboto, "Helvetica Neue", Arial, sans-serif; color: #1a1a1a; margin: 0; padding: 28px; }
  .head { border-bottom: 3px solid #F5A623; padding-bottom: 14px; margin-bottom: 18px; }
  .brand { font-size: 13px; letter-spacing: 1px; text-transform: uppercase; color: #F5A623; font-weight: 700; }
  h1 { font-size: 22px; margin: 4px 0 0; }
  .meta { display: flex; flex-wrap: wrap; gap: 14px 28px; margin-bottom: 20px; }
  .meta-item { display: flex; flex-direction: column; }
  .meta-item span { font-size: 11px; text-transform: uppercase; letter-spacing: .5px; color: #8a8a8a; }
  .meta-item strong { font-size: 15px; margin-top: 2px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { text-align: left; background: #2b2b2b; color: #fff; padding: 9px 12px; font-size: 11px; text-transform: uppercase; letter-spacing: .5px; }
  th.num, td.num { text-align: right; }
  td { padding: 9px 12px; border-bottom: 1px solid #ececec; }
  tr.alt td { background: #faf7f0; }
  td.empty { text-align: center; color: #8a8a8a; padding: 20px; }
  tfoot td { font-weight: 700; border-top: 2px solid #2b2b2b; background: #fff4e0; }
  .note { font-size: 11px; color: #8a8a8a; margin-top: 16px; line-height: 1.5; }
  .subhead { font-size: 15px; margin: 26px 0 10px; padding-bottom: 6px; border-bottom: 2px solid #F5A623; }
  .footer { margin-top: 24px; font-size: 11px; color: #b0b0b0; text-align: center; }
</style>
</head>
<body>
  <div class="head">
    <div class="brand">${escapeHtml(APP_NAME)}</div>
    <h1>IFTA Mileage Report</h1>
  </div>
  <div class="meta">${metaItems.join('')}</div>
  <table>
    <thead><tr>${headCells}</tr></thead>
    <tbody>${bodyRows}</tbody>
    <tfoot><tr>${totalRow}</tr></tfoot>
  </table>
  ${note}
  ${fuelSection}
  <div class="footer">Generated by ${escapeHtml(APP_NAME)} \u00b7 ${escapeHtml(
    formatDate(meta.generatedAt),
  )}</div>
</body>
</html>`;
}

function fileBaseName(meta: ReportMeta): string {
  const safe = meta.periodLabel
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return ['ifta-track-mileage', safe || 'report'].filter(Boolean).join('-');
}

// Web-only: trigger a file download without touching DOM types directly.
function downloadOnWeb(content: string, fileName: string, mimeType: string): void {
  try {
    const g = globalThis as any;
    if (!g?.document || !g?.Blob || !g?.URL) return;
    const blob = new g.Blob([content], { type: mimeType });
    const url = g.URL.createObjectURL(blob);
    const a = g.document.createElement('a');
    a.href = url;
    a.download = fileName;
    g.document.body.appendChild(a);
    a.click();
    g.document.body.removeChild(a);
    g.URL.revokeObjectURL(url);
  } catch {
    // ignore
  }
}

export async function exportReport(
  format: ExportFormat,
  rows: ExportRow[],
  meta: ReportMeta,
): Promise<ExportResult> {
  if (rows.length === 0) return { ok: false, shared: false, reason: 'empty' };

  const content = format === 'csv' ? buildCsv(rows, meta) : buildText(rows, meta);
  const ext = format === 'csv' ? 'csv' : 'txt';
  const mimeType = format === 'csv' ? 'text/csv' : 'text/plain';
  const fileName = `${fileBaseName(meta)}.${ext}`;

  if (Platform.OS === 'web') {
    downloadOnWeb(content, fileName, mimeType);
    return { ok: true, shared: true };
  }

  try {
    const FileSystem = fs();
    const Sharing = sharing();
    const dir = FileSystem.cacheDirectory || FileSystem.documentDirectory;
    const fileUri = `${dir}${fileName}`;
    await FileSystem.writeAsStringAsync(fileUri, content);

    const available = await Sharing.isAvailableAsync();
    if (!available) return { ok: true, shared: false, reason: 'unavailable' };

    await Sharing.shareAsync(fileUri, {
      mimeType,
      dialogTitle: 'Export IFTA Mileage Report',
      UTI:
        format === 'csv'
          ? 'public.comma-separated-values-text'
          : 'public.plain-text',
    });
    return { ok: true, shared: true };
  } catch {
    return { ok: false, shared: false, reason: 'error' };
  }
}

// Generates the mileage report as a PDF file (clean HTML table) and opens the
// share sheet so the driver can save it to Files/Drive or send it anywhere.
// Web falls back to opening the print dialog (which offers "Save to PDF").
export async function savePdfReport(
  rows: ExportRow[],
  meta: ReportMeta,
): Promise<ExportResult> {
  if (rows.length === 0) return { ok: false, shared: false, reason: 'empty' };

  const html = buildHtml(rows, meta);

  if (Platform.OS === 'web') {
    try {
      const Print = print();
      await Print.printAsync({ html });
      return { ok: true, shared: true };
    } catch {
      return { ok: false, shared: false, reason: 'error' };
    }
  }

  try {
    const Print = print();
    const { uri } = await Print.printToFileAsync({ html });

    const Sharing = sharing();
    const available = await Sharing.isAvailableAsync();
    if (!available) return { ok: true, shared: false, reason: 'unavailable' };

    await Sharing.shareAsync(uri, {
      mimeType: 'application/pdf',
      dialogTitle: 'Save IFTA Mileage Report (PDF)',
      UTI: 'com.adobe.pdf',
    });
    return { ok: true, shared: true };
  } catch {
    return { ok: false, shared: false, reason: 'error' };
  }
}

// Prints the mileage report (clean HTML table) via the OS print dialog, which
// also allows "Save to PDF" on both iOS and Android.
export async function printReport(
  rows: ExportRow[],
  meta: ReportMeta,
): Promise<ExportResult> {
  if (rows.length === 0) return { ok: false, shared: false, reason: 'empty' };
  try {
    const Print = print();
    const html = buildHtml(rows, meta);
    await Print.printAsync({ html });
    return { ok: true, shared: true };
  } catch {
    return { ok: false, shared: false, reason: 'error' };
  }
}

// Opens the native mail composer addressed to `recipient` (when supplied), with
// a prefilled subject and the text report in the body, plus a clean PDF and the
// CSV attached. Web falls back to a mailto: link (subject + body only).
export async function emailReport(
  rows: ExportRow[],
  meta: ReportMeta,
  recipient?: string,
): Promise<ExportResult> {
  if (rows.length === 0) return { ok: false, shared: false, reason: 'empty' };

  const subject = `${APP_NAME} IFTA Mileage Report \u2014 ${meta.periodLabel}`;
  const body = buildText(rows, meta);

  if (Platform.OS === 'web') {
    try {
      const g = globalThis as any;
      if (!g?.window?.location) {
        return { ok: false, shared: false, reason: 'unavailable' };
      }
      const to = recipient ? encodeURIComponent(recipient) : '';
      const href = `mailto:${to}?subject=${encodeURIComponent(
        subject,
      )}&body=${encodeURIComponent(body)}`;
      g.window.location.href = href;
      return { ok: true, shared: true };
    } catch {
      return { ok: false, shared: false, reason: 'error' };
    }
  }

  try {
    const MailComposer = mail();
    const available = await MailComposer.isAvailableAsync();
    if (!available) return { ok: false, shared: false, reason: 'unavailable' };

    const FileSystem = fs();
    const attachments: string[] = [];

    // Clean, aligned PDF for reading/printing.
    try {
      const Print = print();
      const html = buildHtml(rows, meta);
      const { uri } = await Print.printToFileAsync({ html });
      attachments.push(uri);
    } catch {
      // PDF generation failed — still attach the CSV below.
    }

    // CSV for spreadsheet use.
    const csv = buildCsv(rows, meta);
    const fileName = `${fileBaseName(meta)}.csv`;
    const dir = FileSystem.cacheDirectory || FileSystem.documentDirectory;
    const fileUri = `${dir}${fileName}`;
    await FileSystem.writeAsStringAsync(fileUri, csv);
    attachments.push(fileUri);

    await MailComposer.composeAsync({
      recipients: recipient ? [recipient] : undefined,
      subject,
      body,
      attachments,
    });
    return { ok: true, shared: true };
  } catch {
    return { ok: false, shared: false, reason: 'error' };
  }
}

// ---- Fuel purchase report (gallons, cost, odometer per purchase) ----------

export type FuelExportRow = {
  date: number;
  code: string;
  gallons: number;
  amount: number;
  odometer?: number;
  vendor?: string;
};

// A single Diesel Exhaust Fluid purchase for the fuel report's DEF section.
export type FuelDefRow = {
  date: number;
  gallons: number;
  pricePerGallon: number;
};

export type FuelReportMeta = {
  periodName: string; // e.g. "Quarter"
  periodLabel: string; // e.g. "Q2 2026"
  totalGallons: number;
  totalCost: number;
  purchaseCount: number;
  generatedAt: number;
  // Diesel Exhaust Fluid purchases for the same period, tracked separately from
  // diesel fuel (not part of IFTA fuel-tax gallons). Included in the PDF report.
  defRows?: FuelDefRow[];
  defTotalGallons?: number;
  defTotalCost?: number;
};

export function buildFuelCsv(
  rows: FuelExportRow[],
  meta: FuelReportMeta,
): string {
  const lines: string[] = [];
  lines.push(`${APP_NAME} IFTA Fuel Report`);
  lines.push(`Period,${escapeCsv(meta.periodName)}`);
  lines.push(`Range,${escapeCsv(meta.periodLabel)}`);
  lines.push(`Generated,${escapeCsv(formatDate(meta.generatedAt))}`);
  lines.push(`Purchases,${meta.purchaseCount}`);
  lines.push('');
  lines.push('Date,State Code,Jurisdiction,Gallons,Amount,Odometer,Vendor');
  rows.forEach((r) => {
    lines.push(
      [
        escapeCsv(formatDate(r.date)),
        escapeCsv(r.code),
        escapeCsv(stateLabel(r.code)),
        r.gallons.toFixed(1),
        r.amount.toFixed(2),
        r.odometer != null ? String(Math.round(r.odometer)) : '',
        escapeCsv(r.vendor || ''),
      ].join(','),
    );
  });
  lines.push(
    `Total,,,${meta.totalGallons.toFixed(1)},${meta.totalCost.toFixed(2)},,`,
  );
  return lines.join('\n');
}

export function buildFuelText(
  rows: FuelExportRow[],
  meta: FuelReportMeta,
): string {
  const lines: string[] = [];
  lines.push(`${APP_NAME} \u2014 IFTA Fuel Report`);
  lines.push(`Period: ${meta.periodName} (${meta.periodLabel})`);
  lines.push(`Generated: ${formatDate(meta.generatedAt)}`);
  lines.push('');
  if (rows.length === 0) {
    lines.push('Fuel purchases:');
    lines.push('  No fuel purchases recorded.');
  } else {
    const columns: TextColumn[] = [
      { header: 'Date' },
      { header: 'Jurisdiction' },
      { header: 'Code' },
      { header: 'Gallons', align: 'right' },
      { header: 'Amount', align: 'right' },
      { header: 'Odometer', align: 'right' },
      { header: 'Vendor' },
    ];
    const tableRows = rows.map((r) => [
      formatDate(r.date),
      stateLabel(r.code),
      r.code,
      r.gallons.toFixed(1),
      formatCurrency(r.amount),
      r.odometer != null ? Math.round(r.odometer).toLocaleString() : '',
      r.vendor || '',
    ]);
    tableRows.push([
      'TOTAL',
      '',
      '',
      meta.totalGallons.toFixed(1),
      formatCurrency(meta.totalCost),
      '',
      '',
    ]);
    lines.push(...renderTextTable(columns, tableRows));
  }
  lines.push('');
  const purchaseWord = meta.purchaseCount === 1 ? 'purchase' : 'purchases';
  lines.push(
    `Total: ${meta.totalGallons.toFixed(1)} gal \u00b7 ${formatCurrency(
      meta.totalCost,
    )} \u00b7 ${meta.purchaseCount} ${purchaseWord}`,
  );
  return lines.join('\n');
}

// Renders the fuel + DEF report as a styled HTML document (clean, aligned
// table) used for the "Save PDF" option on the Fuel tab. Mirrors buildHtml.
export function buildFuelHtml(
  rows: FuelExportRow[],
  meta: FuelReportMeta,
): string {
  const columns = ['Date', 'Jurisdiction', 'Gallons', 'Amount', 'Odometer', 'Vendor'];
  const headCells = columns
    .map(
      (c, i) =>
        `<th class="${i >= 2 && i <= 4 ? 'num' : ''}">${escapeHtml(c)}</th>`,
    )
    .join('');

  const bodyRows =
    rows.length === 0
      ? `<tr><td colspan="${columns.length}" class="empty">No fuel purchases recorded for this period.</td></tr>`
      : rows
          .map((r, i) => {
            const cells = [
              formatDate(r.date),
              `${stateLabel(r.code)} (${r.code})`,
              formatGallons(r.gallons),
              formatCurrency(r.amount),
              r.odometer != null
                ? Math.round(r.odometer).toLocaleString()
                : '\u2014',
              r.vendor || '\u2014',
            ];
            const tds = cells
              .map(
                (c, ci) =>
                  `<td class="${ci >= 2 && ci <= 4 ? 'num' : ''}">${escapeHtml(c)}</td>`,
              )
              .join('');
            return `<tr class="${i % 2 ? 'alt' : ''}">${tds}</tr>`;
          })
          .join('');

  const totalRow = [
    'TOTAL',
    '',
    formatGallons(meta.totalGallons),
    formatCurrency(meta.totalCost),
    '',
    '',
  ]
    .map(
      (c, ci) =>
        `<td class="${ci >= 2 && ci <= 4 ? 'num' : ''}">${escapeHtml(c)}</td>`,
    )
    .join('');

  const metaItems: string[] = [
    `<div class="meta-item"><span>Period</span><strong>${escapeHtml(meta.periodName)}</strong></div>`,
    `<div class="meta-item"><span>Range</span><strong>${escapeHtml(meta.periodLabel)}</strong></div>`,
    `<div class="meta-item"><span>Generated</span><strong>${escapeHtml(formatDate(meta.generatedAt))}</strong></div>`,
    `<div class="meta-item"><span>Purchases</span><strong>${meta.purchaseCount}</strong></div>`,
    `<div class="meta-item"><span>Fuel gallons</span><strong>${formatGallons(meta.totalGallons)}</strong></div>`,
    `<div class="meta-item"><span>Fuel cost</span><strong>${escapeHtml(formatCurrency(meta.totalCost))}</strong></div>`,
  ];
  if (meta.defTotalGallons != null && meta.defTotalGallons > 0) {
    metaItems.push(
      `<div class="meta-item"><span>DEF gallons</span><strong>${formatGallons(meta.defTotalGallons)}</strong></div>`,
    );
  }
  if (meta.defTotalCost != null && meta.defTotalCost > 0) {
    metaItems.push(
      `<div class="meta-item"><span>DEF cost</span><strong>${escapeHtml(formatCurrency(meta.defTotalCost))}</strong></div>`,
    );
  }

  let defSection = '';
  if (meta.defRows && meta.defRows.length > 0) {
    const dg = meta.defRows.reduce((s, d) => s + d.gallons, 0);
    const dc = meta.defRows.reduce(
      (s, d) => s + d.gallons * d.pricePerGallon,
      0,
    );
    const defBody = meta.defRows
      .map((d, i) => {
        const cells = [
          formatDate(d.date),
          formatGallons(d.gallons),
          `${formatPricePerGallon(d.pricePerGallon)}/gal`,
          formatCurrency(d.gallons * d.pricePerGallon),
        ];
        const tds = cells
          .map(
            (c, ci) => `<td class="${ci >= 1 ? 'num' : ''}">${escapeHtml(c)}</td>`,
          )
          .join('');
        return `<tr class="${i % 2 ? 'alt' : ''}">${tds}</tr>`;
      })
      .join('');
    const defTotal = ['TOTAL', formatGallons(dg), '', formatCurrency(dc)]
      .map((c, ci) => `<td class="${ci >= 1 ? 'num' : ''}">${escapeHtml(c)}</td>`)
      .join('');
    defSection = `
  <h2 class="subhead">Diesel Exhaust Fluid (DEF)</h2>
  <table>
    <thead><tr><th>Date</th><th class="num">Gallons</th><th class="num">Price / gal</th><th class="num">Amount</th></tr></thead>
    <tbody>${defBody}</tbody>
    <tfoot><tr>${defTotal}</tr></tfoot>
  </table>
  <p class="note">DEF is tracked separately from diesel fuel and is not included in IFTA fuel-tax gallons.</p>`;
  }

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, Roboto, "Helvetica Neue", Arial, sans-serif; color: #1a1a1a; margin: 0; padding: 28px; }
  .head { border-bottom: 3px solid #F5A623; padding-bottom: 14px; margin-bottom: 18px; }
  .brand { font-size: 13px; letter-spacing: 1px; text-transform: uppercase; color: #F5A623; font-weight: 700; }
  h1 { font-size: 22px; margin: 4px 0 0; }
  .meta { display: flex; flex-wrap: wrap; gap: 14px 28px; margin-bottom: 20px; }
  .meta-item { display: flex; flex-direction: column; }
  .meta-item span { font-size: 11px; text-transform: uppercase; letter-spacing: .5px; color: #8a8a8a; }
  .meta-item strong { font-size: 15px; margin-top: 2px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { text-align: left; background: #2b2b2b; color: #fff; padding: 9px 12px; font-size: 11px; text-transform: uppercase; letter-spacing: .5px; }
  th.num, td.num { text-align: right; }
  td { padding: 9px 12px; border-bottom: 1px solid #ececec; }
  tr.alt td { background: #faf7f0; }
  td.empty { text-align: center; color: #8a8a8a; padding: 20px; }
  tfoot td { font-weight: 700; border-top: 2px solid #2b2b2b; background: #fff4e0; }
  .note { font-size: 11px; color: #8a8a8a; margin-top: 16px; line-height: 1.5; }
  .subhead { font-size: 15px; margin: 26px 0 10px; padding-bottom: 6px; border-bottom: 2px solid #F5A623; }
  .footer { margin-top: 24px; font-size: 11px; color: #b0b0b0; text-align: center; }
</style>
</head>
<body>
  <div class="head">
    <div class="brand">${escapeHtml(APP_NAME)}</div>
    <h1>IFTA Fuel Report</h1>
  </div>
  <div class="meta">${metaItems.join('')}</div>
  <table>
    <thead><tr>${headCells}</tr></thead>
    <tbody>${bodyRows}</tbody>
    <tfoot><tr>${totalRow}</tr></tfoot>
  </table>
  ${defSection}
  <div class="footer">Generated by ${escapeHtml(APP_NAME)} \u00b7 ${escapeHtml(
    formatDate(meta.generatedAt),
  )}</div>
</body>
</html>`;
}

function fuelFileBaseName(meta: FuelReportMeta): string {
  const safe = meta.periodLabel
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return ['ifta-track-fuel', safe || 'report'].filter(Boolean).join('-');
}

export async function exportFuelReport(
  format: ExportFormat,
  rows: FuelExportRow[],
  meta: FuelReportMeta,
): Promise<ExportResult> {
  if (rows.length === 0) return { ok: false, shared: false, reason: 'empty' };

  const content =
    format === 'csv' ? buildFuelCsv(rows, meta) : buildFuelText(rows, meta);
  const ext = format === 'csv' ? 'csv' : 'txt';
  const mimeType = format === 'csv' ? 'text/csv' : 'text/plain';
  const fileName = `${fuelFileBaseName(meta)}.${ext}`;

  if (Platform.OS === 'web') {
    downloadOnWeb(content, fileName, mimeType);
    return { ok: true, shared: true };
  }

  try {
    const FileSystem = fs();
    const Sharing = sharing();
    const dir = FileSystem.cacheDirectory || FileSystem.documentDirectory;
    const fileUri = `${dir}${fileName}`;
    await FileSystem.writeAsStringAsync(fileUri, content);

    const available = await Sharing.isAvailableAsync();
    if (!available) return { ok: true, shared: false, reason: 'unavailable' };

    await Sharing.shareAsync(fileUri, {
      mimeType,
      dialogTitle: 'Export IFTA Fuel Report',
      UTI:
        format === 'csv'
          ? 'public.comma-separated-values-text'
          : 'public.plain-text',
    });
    return { ok: true, shared: true };
  } catch {
    return { ok: false, shared: false, reason: 'error' };
  }
}

// Generates the fuel + DEF report as a PDF file and opens the share sheet so
// the driver can save it to Files/Drive or send it anywhere. Web falls back to
// the print dialog (which offers "Save to PDF").
export async function saveFuelPdfReport(
  rows: FuelExportRow[],
  meta: FuelReportMeta,
): Promise<ExportResult> {
  const hasDef = !!(meta.defRows && meta.defRows.length > 0);
  if (rows.length === 0 && !hasDef) {
    return { ok: false, shared: false, reason: 'empty' };
  }

  const html = buildFuelHtml(rows, meta);

  if (Platform.OS === 'web') {
    try {
      const Print = print();
      await Print.printAsync({ html });
      return { ok: true, shared: true };
    } catch {
      return { ok: false, shared: false, reason: 'error' };
    }
  }

  try {
    const Print = print();
    const { uri } = await Print.printToFileAsync({ html });

    const Sharing = sharing();
    const available = await Sharing.isAvailableAsync();
    if (!available) return { ok: true, shared: false, reason: 'unavailable' };

    await Sharing.shareAsync(uri, {
      mimeType: 'application/pdf',
      dialogTitle: 'Save IFTA Fuel Report (PDF)',
      UTI: 'com.adobe.pdf',
    });
    return { ok: true, shared: true };
  } catch {
    return { ok: false, shared: false, reason: 'error' };
  }
}

export async function emailFuelReport(
  rows: FuelExportRow[],
  meta: FuelReportMeta,
): Promise<ExportResult> {
  if (rows.length === 0) return { ok: false, shared: false, reason: 'empty' };

  const subject = `${APP_NAME} IFTA Fuel Report \u2014 ${meta.periodLabel}`;
  const body = buildFuelText(rows, meta);

  if (Platform.OS === 'web') {
    try {
      const g = globalThis as any;
      if (!g?.window?.location) {
        return { ok: false, shared: false, reason: 'unavailable' };
      }
      const href = `mailto:?subject=${encodeURIComponent(
        subject,
      )}&body=${encodeURIComponent(body)}`;
      g.window.location.href = href;
      return { ok: true, shared: true };
    } catch {
      return { ok: false, shared: false, reason: 'error' };
    }
  }

  try {
    const MailComposer = mail();
    const available = await MailComposer.isAvailableAsync();
    if (!available) return { ok: false, shared: false, reason: 'unavailable' };

    const FileSystem = fs();
    const csv = buildFuelCsv(rows, meta);
    const fileName = `${fuelFileBaseName(meta)}.csv`;
    const dir = FileSystem.cacheDirectory || FileSystem.documentDirectory;
    const fileUri = `${dir}${fileName}`;
    await FileSystem.writeAsStringAsync(fileUri, csv);

    await MailComposer.composeAsync({
      subject,
      body,
      attachments: [fileUri],
    });
    return { ok: true, shared: true };
  } catch {
    return { ok: false, shared: false, reason: 'error' };
  }
}
