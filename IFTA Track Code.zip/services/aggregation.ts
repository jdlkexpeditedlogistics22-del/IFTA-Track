// Powered by OnSpace.AI
// Pure aggregation utilities for period-based mileage reporting

import { FuelPurchase, StateMiles, Trip } from './types';

export type Period = 'day' | 'month' | 'quarter' | 'year';

export const PERIOD_OPTIONS: { key: Period; label: string }[] = [
  { key: 'day', label: 'Day' },
  { key: 'month', label: 'Month' },
  { key: 'quarter', label: 'Quarter' },
  { key: 'year', label: 'Year' },
];

export function isInPeriod(ts: number, period: Period, now = new Date()): boolean {
  const d = new Date(ts);
  if (d.getFullYear() !== now.getFullYear()) return false;
  if (period === 'year') return true;
  if (period === 'quarter') {
    return Math.floor(d.getMonth() / 3) === Math.floor(now.getMonth() / 3);
  }
  if (period === 'month') return d.getMonth() === now.getMonth();
  return d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
}

export function filterTrips(trips: Trip[], period: Period, now = new Date()): Trip[] {
  return trips.filter((t) => isInPeriod(t.startedAt, period, now));
}

// Build a synthetic, in-progress "trip" from the live GPS session's per-state
// miles. The daily trip is only written to history at midnight, so without this
// today's driving would be missing from the current period's IFTA summary and
// tax estimate (fleet MPG needs BOTH miles and gallons in the same period, so a
// missing today's-miles makes the estimate uncomputable). Returns null when no
// live miles have accumulated yet.
export function liveTripFromState(
  stateMiles: StateMiles,
  startedAt: number = Date.now(),
): Trip | null {
  const miles = Object.values(stateMiles).reduce((a, b) => a + b, 0);
  if (miles <= 0) return null;
  return {
    id: 'live-session',
    startedAt,
    endedAt: Date.now(),
    miles,
    stateMiles: { ...stateMiles },
    auto: true,
  };
}

export function aggregateStateMiles(
  trips: Trip[],
): { code: string; miles: number }[] {
  const acc: StateMiles = {};
  trips.forEach((t) =>
    Object.entries(t.stateMiles).forEach(([code, miles]) => {
      acc[code] = (acc[code] || 0) + miles;
    }),
  );
  return Object.entries(acc)
    .map(([code, miles]) => ({ code, miles }))
    .sort((a, b) => b.miles - a.miles);
}

export function totalMiles(trips: Trip[]): number {
  return trips.reduce((s, t) => s + t.miles, 0);
}

export function periodLabel(period: Period, now = new Date()): string {
  if (period === 'year') return String(now.getFullYear());
  if (period === 'quarter') {
    return `Q${Math.floor(now.getMonth() / 3) + 1} ${now.getFullYear()}`;
  }
  if (period === 'month') {
    return now.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  }
  return now.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

// ---- Fuel purchase aggregation (IFTA fuel-tax side) ----

export type StateFuel = { code: string; gallons: number; amount: number };

export function filterFuel(
  fuel: FuelPurchase[],
  period: Period,
  now = new Date(),
): FuelPurchase[] {
  return fuel.filter((f) => isInPeriod(f.date, period, now));
}

export function aggregateStateFuel(fuel: FuelPurchase[]): StateFuel[] {
  const acc: Record<string, { gallons: number; amount: number }> = {};
  fuel.forEach((f) => {
    const cur = acc[f.stateCode] || { gallons: 0, amount: 0 };
    cur.gallons += f.gallons;
    cur.amount += f.amount;
    acc[f.stateCode] = cur;
  });
  return Object.entries(acc)
    .map(([code, v]) => ({ code, gallons: v.gallons, amount: v.amount }))
    .sort((a, b) => b.gallons - a.gallons);
}

export function totalGallons(fuel: FuelPurchase[]): number {
  return fuel.reduce((s, f) => s + f.gallons, 0);
}

export function totalFuelCost(fuel: FuelPurchase[]): number {
  return fuel.reduce((s, f) => s + f.amount, 0);
}

// ---- Per-fill fuel economy trend (MPG between odometer readings) ----

export type FillMpg = {
  id: string;
  date: number;
  miles: number; // distance since the previous fill (odometer delta)
  gallons: number; // gallons added at THIS fill
  mpg: number; // miles / gallons
};

// Compute a per-fill MPG series using the precise TANK-TO-TANK method. An MPG
// measurement is only valid between two points where the tank state is known to
// be identical — i.e. between two FULL-tank fills. So:
//   * Only full-tank fills (fullTank !== false) anchor a measurement. A partial
//     fill is never an endpoint; its gallons are carried forward and ADDED to
//     the denominator of the next full fill (all that fuel was burned over the
//     measured miles), keeping the MPG accurate.
//   * miles  = odometer(current full) - odometer(previous full)
//   * gallons = current full fill gallons + any carried partial-fill gallons
//     accumulated since the previous full fill.
// Only fills that carry an odometer reading can anchor a measurement, so entries
// without one are skipped. Fills are ordered by odometer (monotonic) so the
// series is chronological even if dates were typed out of order. Entries logged
// before the toggle existed have fullTank === undefined and are treated as full
// (preserving prior behavior). Returns one entry per full-to-full gap, oldest
// first.
export function computeFillMpgTrend(fuel: FuelPurchase[]): FillMpg[] {
  const withOdo = fuel
    .filter((f) => typeof f.odometer === 'number' && (f.odometer as number) > 0)
    .sort((a, b) => (a.odometer as number) - (b.odometer as number) || a.date - b.date);

  const out: FillMpg[] = [];
  let anchorOdo: number | null = null; // odometer at the last FULL fill
  let carriedGallons = 0; // partial-fill gallons since the last full fill

  for (const f of withOdo) {
    const isFull = f.fullTank !== false; // undefined -> treated as full
    if (!isFull) {
      // Partial fill: not a measurement endpoint. Carry its gallons forward to
      // add into the next full fill, but only once a full-tank anchor exists.
      if (anchorOdo !== null) carriedGallons += f.gallons;
      continue;
    }
    // Full fill: close the tank-to-tank gap from the previous full fill.
    if (anchorOdo !== null) {
      const miles = (f.odometer as number) - anchorOdo;
      const gallons = carriedGallons + f.gallons;
      if (miles > 0 && gallons > 0) {
        out.push({
          id: f.id,
          date: f.date,
          miles,
          gallons,
          mpg: miles / gallons,
        });
      }
    }
    // This full fill becomes the new anchor; reset carried partial gallons.
    anchorOdo = f.odometer as number;
    carriedGallons = 0;
  }
  return out;
}

// ---- Combined IFTA calculation (miles + fuel -> net taxable gallons) ----

export type IftaStateRow = {
  code: string;
  miles: number;
  taxableGallons: number; // miles / fleet mpg
  taxPaidGallons: number; // gallons purchased in the state
  netTaxableGallons: number; // taxable - tax-paid (+ owed, - credit)
  computable: boolean; // whether fleet mpg was available
};

export type IftaSummary = {
  totalMiles: number;
  totalGallons: number;
  mpg: number; // 0 when no gallons recorded
  rows: IftaStateRow[];
};

export function computeIfta(
  trips: Trip[],
  fuel: FuelPurchase[],
): IftaSummary {
  const milesRows = aggregateStateMiles(trips);
  const fuelRows = aggregateStateFuel(fuel);

  const totalMi = milesRows.reduce((s, r) => s + r.miles, 0);
  const totalGal = fuelRows.reduce((s, r) => s + r.gallons, 0);
  const mpg = totalGal > 0 ? totalMi / totalGal : 0;
  const computable = mpg > 0;

  const milesByState: Record<string, number> = {};
  milesRows.forEach((r) => {
    milesByState[r.code] = r.miles;
  });
  const gallonsByState: Record<string, number> = {};
  fuelRows.forEach((r) => {
    gallonsByState[r.code] = r.gallons;
  });

  const codes = new Set<string>([
    ...milesRows.map((r) => r.code),
    ...fuelRows.map((r) => r.code),
  ]);

  const rows: IftaStateRow[] = Array.from(codes).map((code) => {
    const miles = milesByState[code] || 0;
    const taxPaidGallons = gallonsByState[code] || 0;
    const taxableGallons = computable ? miles / mpg : 0;
    return {
      code,
      miles,
      taxableGallons,
      taxPaidGallons,
      netTaxableGallons: taxableGallons - taxPaidGallons,
      computable,
    };
  });

  rows.sort((a, b) => b.miles - a.miles);

  return { totalMiles: totalMi, totalGallons: totalGal, mpg, rows };
}
