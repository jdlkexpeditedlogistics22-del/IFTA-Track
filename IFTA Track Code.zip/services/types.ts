// Powered by OnSpace.AI

export type StateMiles = Record<string, number>;

// A single GPS vertex of the recorded travel path (the polyline shown on the
// live route map). Kept minimal so the persisted path stays small.
export type PathPoint = { latitude: number; longitude: number };

// A timestamped jurisdiction change during a drive: the moment (and running
// odometer) at which the vehicle entered `stateCode`. The first entry is the
// day's origin state; each later entry marks crossing a state line. Used to show
// a border-crossing timeline on the live Track tab and on a recorded trip.
export type BorderCrossing = {
  stateCode: string;
  at: number; // timestamp the state was entered
  miles: number; // session odometer (miles) when entered
};

export type Trip = {
  id: string;
  startedAt: number;
  endedAt: number;
  miles: number;
  stateMiles: StateMiles;
  auto: boolean;
  manual?: boolean;
  edited?: boolean; // true when the recorded miles were manually corrected
  // Timestamped state-line crossings captured while the trip was recorded.
  crossings?: BorderCrossing[];
};

// In-progress trip persisted to disk so background + foreground share one
// source of truth. The background task and the UI both read/write this.
export type ActiveSession = {
  startedAt: number;
  auto: boolean;
  miles: number;
  stateMiles: StateMiles;
  lastLat: number | null;
  lastLon: number | null;
  lastTs: number | null;
  currentStateCode: string | null;
  geoT: number | null;
  geoLat: number | null;
  geoLon: number | null;
  speedMph: number;
  accuracy: number | null; // meters, accuracy of the last GPS fix
  // Bounded trail of GPS vertices for the live route map. Downsampled and
  // capped in sessionService so it never grows unbounded during a long drive.
  path?: PathPoint[];
  // Timestamped jurisdiction changes for this day's drive, appended each time
  // the detected state changes (see sessionService.noteStateChange).
  crossings?: BorderCrossing[];
};

// A fuel purchase logged for IFTA fuel-tax reporting, attributed to the
// jurisdiction (state) where the fuel was bought.
export type FuelPurchase = {
  id: string;
  date: number;
  stateCode: string;
  gallons: number;
  amount: number; // total paid, in dollars
  odometer?: number; // optional odometer reading at time of purchase (miles)
  vendor?: string;
  // Whether the tank was filled to FULL at this purchase. Only full-tank fills
  // anchor a tank-to-tank MPG measurement; a partial fill (false) is not used as
  // an endpoint — its gallons are carried forward and added to the next full
  // fill so the MPG stays precise. Missing/undefined is treated as full for
  // backward compatibility with entries logged before this toggle existed.
  fullTank?: boolean;
};

// A Diesel Exhaust Fluid (DEF) purchase, tracked SEPARATELY from diesel fuel.
// DEF is not a taxable motor fuel for IFTA, so it is not attributed to a state
// or included in fuel-tax gallons — it is a simple cost/quantity record. The
// driver enters gallons and the price per gallon (kept unrounded); the total is
// derived from the two.
export type DefPurchase = {
  id: string;
  date: number;
  gallons: number;
  pricePerGallon: number; // $/gal, kept unrounded (e.g. 2.899)
};
