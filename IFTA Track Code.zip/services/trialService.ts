// 7-day trial gate anchored to the device.
//
// Trial start, unlock flag, and a stable device identifier are persisted in the
// OS secure store (expo-secure-store). On iOS the keychain survives an app
// uninstall, so reinstalling does NOT reset the trial. On Android the secure
// store is cleared on uninstall — a fully reinstall-proof lock there requires a
// server-side device registry (keyed by the device id below). Web falls back to
// AsyncStorage.
//
// The device identifier replaces IMEI/EMI, which is not readable on modern
// iOS/Android. It is the OS "identifier for vendor" (iOS) / ANDROID_ID
// (Android): stable per device, resets only on a factory reset.
//
// Native modules are required LAZILY (never at boot) to match the app pattern
// of keeping the route-tree build crash-free.

import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const TRIAL_DAYS = 7;
const TRIAL_MS = TRIAL_DAYS * 24 * 60 * 60 * 1000;

// Master unlock code reserved for the app author. Entering it on any device
// permanently unlocks the app past the trial. Keep this private.
export const MASTER_UNLOCK_CODE = 'JDLK-MASTER-7X24';

// Pool of distributable unlock codes. Each entry is unique (no duplicates) and
// was generated up front so the author can hand codes out individually. Any
// code here permanently unlocks the app on the device it is entered on. To grow
// the pool, append new unique codes below — a runtime guard rejects the whole
// list if a duplicate ever slips in, so uniqueness stays enforced.
export const UNLOCK_CODE_POOL: readonly string[] = [
  'JDLK-3F7A-K9QP',
  'JDLK-8M2X-R4WD',
  'JDLK-7QZE-1N6H',
  'JDLK-5C9V-T3BY',
  'JDLK-2H4K-P8LM',
  'JDLK-9X6R-D5FA',
  'JDLK-4B1N-W7QK',
  'JDLK-6T8P-Z2VE',
  'JDLK-1K5D-M9HR',
  'JDLK-3W7Y-C4XN',
  'JDLK-8F2A-Q6LP',
  'JDLK-5R9M-B3KD',
  'JDLK-7N4X-H8WV',
  'JDLK-2P6E-T5QA',
  'JDLK-9D1K-Z7FM',
  'JDLK-4Y8R-C2HN',
  'JDLK-6X3W-P9LK',
  'JDLK-1M5A-D4QV',
  'JDLK-8B7N-R6KE',
  'JDLK-3K2P-W8HM',
  'JDLK-7A9X-T1FD',
  'JDLK-5V4R-Q3LN',
  'JDLK-2E6K-Z9WP',
  'JDLK-9H1M-C7BA',
  'JDLK-4N8D-P5KR',
  'JDLK-6W3X-H2QV',
  'JDLK-1F5Y-T8LM',
  'JDLK-8R7A-D6KN',
  'JDLK-3P2K-Z4WE',
  'JDLK-7X9M-Q1HD',
  'JDLK-5K4N-B8FV',
  'JDLK-2A6R-C3LP',
  'JDLK-9M1X-W7KA',
  'JDLK-4D8P-T5QN',
  'JDLK-6N3W-Z9HR',
  'JDLK-1X5K-P2FM',
  'JDLK-8Y7R-D4LV',
  'JDLK-3M2A-Q6WK',
  'JDLK-7K9X-H1BN',
  'JDLK-5P4D-T3QE',
];

// Build a normalized redeemable set once (master + pool), guarding against any
// accidental duplicate code in the pool.
function normalizeCode(code: string): string {
  return code.trim().toUpperCase().replace(/\s+/g, '');
}

const VALID_CODES: Set<string> = (() => {
  const set = new Set<string>();
  set.add(normalizeCode(MASTER_UNLOCK_CODE));
  for (const code of UNLOCK_CODE_POOL) {
    const normalized = normalizeCode(code);
    if (set.has(normalized)) {
      // A duplicate would let two "different" codes collide. Surface it loudly
      // in development rather than silently accepting a non-unique pool.
      if (__DEV__) {
        console.warn(`Duplicate unlock code detected and ignored: ${normalized}`);
      }
      continue;
    }
    set.add(normalized);
  }
  return set;
})();

const START_KEY = 'iftatrack.trial.start';
const UNLOCK_KEY = 'iftatrack.trial.unlocked';
const DEVICE_KEY = 'iftatrack.device.id';

// --- Lazy native-module accessors ----------------------------------------

let _ss: typeof import('expo-secure-store') | null = null;
function secureStore(): typeof import('expo-secure-store') | null {
  if (Platform.OS === 'web') return null;
  if (_ss) return _ss;
  try {
    _ss = require('expo-secure-store');
    return _ss;
  } catch {
    return null;
  }
}

let _app: typeof import('expo-application') | null = null;
function application(): typeof import('expo-application') | null {
  if (_app) return _app;
  try {
    _app = require('expo-application');
    return _app;
  } catch {
    return null;
  }
}

// --- Persistence helpers (secure store with AsyncStorage fallback) --------

async function readValue(key: string): Promise<string | null> {
  const ss = secureStore();
  if (ss) {
    try {
      const v = await ss.getItemAsync(key);
      if (v != null) return v;
    } catch {
      // fall through to AsyncStorage
    }
  }
  try {
    return await AsyncStorage.getItem(key);
  } catch {
    return null;
  }
}

async function writeValue(key: string, value: string): Promise<void> {
  const ss = secureStore();
  if (ss) {
    try {
      await ss.setItemAsync(key, value);
      return;
    } catch {
      // fall through to AsyncStorage
    }
  }
  try {
    await AsyncStorage.setItem(key, value);
  } catch {
    // ignore write errors silently
  }
}

// --- Device identifier -----------------------------------------------------

export async function resolveDeviceId(): Promise<string | null> {
  const stored = await readValue(DEVICE_KEY);
  if (stored) return stored;

  let id: string | null = null;
  try {
    const App = application();
    if (App) {
      if (Platform.OS === 'android') {
        id = App.getAndroidId?.() ?? null;
      } else if (Platform.OS === 'ios') {
        id = (await App.getIosIdForVendorAsync?.()) ?? null;
      }
    }
  } catch {
    id = null;
  }

  if (id) await writeValue(DEVICE_KEY, id);
  return id;
}

// --- Trial status ----------------------------------------------------------

export type TrialStatus = {
  unlocked: boolean;
  startedAt: number | null;
  expiresAt: number | null;
  expired: boolean;
  daysLeft: number;
  deviceId: string | null;
};

function build(
  startedAt: number | null,
  unlocked: boolean,
  deviceId: string | null,
): TrialStatus {
  const now = Date.now();
  const expiresAt = startedAt != null ? startedAt + TRIAL_MS : null;
  const expired = !unlocked && expiresAt != null ? now >= expiresAt : false;
  const daysLeft =
    expiresAt != null
      ? Math.max(0, Math.ceil((expiresAt - now) / (24 * 60 * 60 * 1000)))
      : TRIAL_DAYS;
  return { unlocked, startedAt, expiresAt, expired, daysLeft, deviceId };
}

// Ensures the trial start is anchored on first run and returns current status.
export async function initTrial(): Promise<TrialStatus> {
  const deviceId = await resolveDeviceId();
  const unlocked = (await readValue(UNLOCK_KEY)) === '1';

  const startRaw = await readValue(START_KEY);
  let startedAt = startRaw ? parseInt(startRaw, 10) : NaN;
  if (!startRaw || Number.isNaN(startedAt) || startedAt <= 0) {
    startedAt = Date.now();
    await writeValue(START_KEY, String(startedAt));
  }

  return build(startedAt, unlocked, deviceId);
}

// Read-only status check (no writes) for periodic / resume re-evaluation.
export async function getTrialStatus(): Promise<TrialStatus> {
  const deviceId = await readValue(DEVICE_KEY);
  const unlocked = (await readValue(UNLOCK_KEY)) === '1';
  const startRaw = await readValue(START_KEY);
  const parsed = startRaw ? parseInt(startRaw, 10) : NaN;
  const startedAt = Number.isNaN(parsed) ? null : parsed;
  return build(startedAt, unlocked, deviceId);
}

// Validates an unlock code against the master code and the distributable code
// pool. Any valid code permanently unlocks the app on this device.
export async function redeemUnlockCode(code: string): Promise<boolean> {
  const normalized = normalizeCode(code);
  if (!VALID_CODES.has(normalized)) return false;
  await writeValue(UNLOCK_KEY, '1');
  return true;
}
